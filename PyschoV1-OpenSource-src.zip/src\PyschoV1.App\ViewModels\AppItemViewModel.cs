using System.Windows.Input;
using System.Windows.Media;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Apps;

namespace PyschoV1.App.ViewModels;

/// <summary>One application card: identity, detection state and the install flow.</summary>
public sealed class AppItemViewModel : ObservableObject
{
    private static readonly (Brush Bg, Brush Fg)[] Tints =
    {
        Soft("#337C5CFF", "#9E86FF"),
        Soft("#334CC38A", "#4CC38A"),
        Soft("#33E3B341", "#E3B341"),
        Soft("#334C9BC3", "#66B8E0"),
        Soft("#33E5484D", "#FF8A8F"),
        Soft("#33F28C6B", "#FFA98A")
    };

    private readonly AppsViewModel _owner;
    private readonly AppInstallerService _service;
    private CancellationTokenSource? _cts;

    private bool _isInstalled;
    private string _installedVersion = "";
    private bool _canOpen;
    private bool _isWorking;
    private double _progress;
    private bool _isIndeterminate = true;
    private string? _statusText;
    private string? _error;
    private InstalledApp? _match;

    public AppItemViewModel(AppsViewModel owner, AppInstallerService service, AppEntry entry)
    {
        _owner = owner;
        _service = service;
        Entry = entry;

        InstallCommand = new AsyncRelayCommand(RunInstallAsync);
        CancelCommand = new RelayCommand(() => _cts?.Cancel());
        OpenSiteCommand = new RelayCommand(() => SafeOpen(Entry.Homepage));
        OpenAppCommand = new RelayCommand(OpenInstalled);
    }

    public AppEntry Entry { get; }

    public string Name => Entry.Name;
    public string Publisher => Entry.Publisher;
    public string Category => Entry.Category;
    public string Summary => Entry.Summary;
    public string Homepage => Entry.Homepage;

    public string Letter => Entry.Name.Length == 0 ? "?" : char.ToUpperInvariant(Entry.Name[0]).ToString();

    public Brush AvatarBrush => Tints[Index].Bg;
    public Brush LetterBrush => Tints[Index].Fg;

    private int Index => (int)((uint)Entry.Id.GetHashCode() % (uint)Tints.Length);

    public ICommand InstallCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand OpenSiteCommand { get; }
    public ICommand OpenAppCommand { get; }

    /// <summary>How this entry installs right now: winget, a direct download, or the official site.</summary>
    public string MethodLabel
    {
        get
        {
            if (Entry.WingetId is not null && _owner.WingetAvailable) return "winget";
            if (Entry.DirectUrl is not null) return "download";
            return "site";
        }
    }

    public string InstallLabel => MethodLabel == "site" ? "Get" : "Install";

    internal void RaiseInstallMeta()
    {
        Raise(nameof(MethodLabel));
        Raise(nameof(InstallLabel));
    }

    public bool IsInstalled
    {
        get => _isInstalled;
        private set
        {
            if (!Set(ref _isInstalled, value)) return;
            Raise(nameof(ShowOpen));
        }
    }

    public string InstalledVersion
    {
        get => _installedVersion;
        private set => Set(ref _installedVersion, value);
    }

    public bool CanOpen
    {
        get => _canOpen;
        private set
        {
            if (!Set(ref _canOpen, value)) return;
            Raise(nameof(ShowOpen));
        }
    }

    /// <summary>The Open button appears only when there is an executable and no install is running.</summary>
    public bool ShowOpen => CanOpen && !IsWorking;

    public bool IsWorking
    {
        get => _isWorking;
        private set
        {
            if (!Set(ref _isWorking, value)) return;
            Raise(nameof(ShowOpen));
        }
    }

    public double Progress
    {
        get => _progress;
        private set => Set(ref _progress, value);
    }

    public bool IsIndeterminate
    {
        get => _isIndeterminate;
        private set => Set(ref _isIndeterminate, value);
    }

    public string? StatusText
    {
        get => _statusText;
        private set => Set(ref _statusText, value);
    }

    public string? Error
    {
        get => _error;
        private set => Set(ref _error, value);
    }

    /// <summary>Applies one detection result from the uninstall-registry scan.</summary>
    public void UpdateInstalled(InstalledApp? match)
    {
        _match = match;
        IsInstalled = match is not null;
        InstalledVersion = match?.Version ?? "";
        CanOpen = match is not null && !string.IsNullOrWhiteSpace(match.LaunchPath);
    }

    private async Task RunInstallAsync()
    {
        if (IsWorking || _owner.IsLoading) return;

        _cts = new CancellationTokenSource();
        Error = null;
        StatusText = MethodLabel == "site" ? "Opening the official download page…" : "Preparing…";
        IsWorking = true;
        Progress = 0;
        IsIndeterminate = true;

        // Progress<T> captures the UI context here, so every report lands on the dispatcher.
        var progress = new Progress<double>(value =>
        {
            if (value < 0)
            {
                IsIndeterminate = true;
            }
            else
            {
                IsIndeterminate = false;
                Progress = value;
            }
        });
        var status = new Progress<string>(text => StatusText = text);

        try
        {
            var outcome = await _service.InstallAsync(Entry, progress, status, _cts.Token);
            var cancelled = !outcome.Success &&
                            outcome.Message.Contains("cancel", StringComparison.OrdinalIgnoreCase);

            StatusText = cancelled ? "Cancelled." : outcome.Success ? outcome.Message : null;
            Error = cancelled || outcome.Success ? null : outcome.Message;

            if (cancelled)
            {
                // A deliberate cancel is not an error and needs no toast.
            }
            else
            {
                var kind = !outcome.Success
                    ? "error"
                    : outcome.Method == InstallMethod.PageOpened ? "info" : "success";
                AppServices.Shell?.ShowToast(outcome.Message, kind);
            }

            if (outcome.Success && outcome.Method != InstallMethod.PageOpened)
                await _owner.RefreshDetectionAsync();
        }
        catch (OperationCanceledException)
        {
            StatusText = "Cancelled.";
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
            StatusText = null;
            Error = "Install failed: " + ex.Message;
        }
        finally
        {
            IsWorking = false;
            _cts?.Dispose();
            _cts = null;
        }
    }

    private void OpenInstalled()
    {
        if (_match is null || string.IsNullOrWhiteSpace(_match.LaunchPath)) return;
        try
        {
            AppInstallerService.LaunchInstalled(_match);
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
            Error = "Could not start it: " + ex.Message;
        }
    }

    private static void SafeOpen(string url)
    {
        try
        {
            AppInstallerService.OpenUrl(url);
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
        }
    }

    private static (Brush Bg, Brush Fg) Soft(string bg, string fg)
    {
        var bgBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(bg));
        var fgBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(fg));
        bgBrush.Freeze();
        fgBrush.Freeze();
        return (bgBrush, fgBrush);
    }
}
