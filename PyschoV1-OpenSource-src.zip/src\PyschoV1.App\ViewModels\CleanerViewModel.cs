using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Modules;

namespace PyschoV1.App.ViewModels;

public sealed class CleanTargetViewModel : ObservableObject
{
    private bool _selected = true;
    private long _bytes;
    private int _files;
    private bool _scanned;

    public CleanTargetViewModel(CleanTarget target) => Target = target;

    public CleanTarget Target { get; }
    public string Name => Target.Name;
    public string Description => Target.Description;
    public bool IsRecycleBin => Target.IsRecycleBin;

    public bool IsSelected
    {
        get => _selected;
        set
        {
            if (!Set(ref _selected, value)) return;
            SelectionChanged?.Invoke();
        }
    }

    public long Bytes
    {
        get => _bytes;
        set
        {
            if (!Set(ref _bytes, value)) return;
            Raise(nameof(SizeText));
        }
    }

    public int Files
    {
        get => _files;
        set
        {
            if (!Set(ref _files, value)) return;
            Raise(nameof(DetailText));
        }
    }

    public bool Scanned
    {
        get => _scanned;
        set
        {
            if (!Set(ref _scanned, value)) return;
            Raise(nameof(SizeText));
        }
    }

    public string SizeText => !Scanned
        ? "—"
        : IsRecycleBin ? "ready" : CleanerService.FormatBytes(Bytes);

    public string DetailText => IsRecycleBin
        ? "Empties for every drive"
        : Scanned ? $"{Files:N0} files" : "Waiting for scan";

    public event Action? SelectionChanged;
}

public sealed class CleanerViewModel : ObservableObject
{
    private bool _busy;
    private bool _scanned;
    private string _status = "Scan first to see what can be removed.";
    private string _selectionSummary = "";

    public CleanerViewModel()
    {
        foreach (var target in AppServices.Cleaner.Targets)
        {
            var vm = new CleanTargetViewModel(target);
            vm.SelectionChanged += Recount;
            Items.Add(vm);
        }

        ScanCommand = new AsyncRelayCommand(ScanAsync);
        CleanCommand = new AsyncRelayCommand(CleanAsync, () => _scanned && Items.Any(i => i.IsSelected));
        SelectAllCommand = new RelayCommand(() =>
        {
            foreach (var item in Items) item.IsSelected = true;
        });
        SelectNoneCommand = new RelayCommand(() =>
        {
            foreach (var item in Items) item.IsSelected = false;
        });

        Recount();
    }

    public ObservableCollection<CleanTargetViewModel> Items { get; } = new();

    public ICommand ScanCommand { get; }
    public ICommand CleanCommand { get; }
    public ICommand SelectAllCommand { get; }
    public ICommand SelectNoneCommand { get; }

    public bool IsBusy
    {
        get => _busy;
        private set
        {
            if (Set(ref _busy, value)) (CleanCommand as AsyncRelayCommand)?.RaiseCanExecuteChanged();
        }
    }

    public string Status { get => _status; private set => Set(ref _status, value); }

    public string SelectionSummary
    {
        get => _selectionSummary;
        private set => Set(ref _selectionSummary, value);
    }

    public long SelectedBytes { get; private set; }

    private void Recount()
    {
        SelectedBytes = Items.Where(i => i.IsSelected && !i.IsRecycleBin).Sum(i => i.Bytes);
        var count = Items.Count(i => i.IsSelected);
        SelectionSummary = _scanned
            ? $"{CleanerService.FormatBytes(SelectedBytes)} reclaimable across {count} categories"
            : $"{count} categories selected";
        (CleanCommand as AsyncRelayCommand)?.RaiseCanExecuteChanged();
    }

    private async Task ScanAsync()
    {
        IsBusy = true;
        Status = "Measuring disk usage…";

        try
        {
            foreach (var item in Items)
            {
                item.Scanned = false;
                var result = await Task.Run(() => AppServices.Cleaner.Scan(item.Target));
                item.Bytes = result.Bytes;
                item.Files = result.Files;
                item.Scanned = true;
            }

            _scanned = true;
            var total = Items.Where(i => !i.IsRecycleBin).Sum(i => i.Bytes);
            Status = $"Found {CleanerService.FormatBytes(total)} that can be removed safely.";
            Recount();
        }
        catch (Exception ex)
        {
            Status = $"Scan failed: {ex.Message}";
            AppServices.ReportError(ex);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task CleanAsync()
    {
        var selected = Items.Where(i => i.IsSelected).ToList();
        if (selected.Count == 0) return;

        var reclaimable = CleanerService.FormatBytes(SelectedBytes);
        var confirm = MessageBox.Show(
            $"Remove {reclaimable} of cached and temporary data?\n\n" +
            "Windows rebuilds everything on this list. Browser history, logins and documents are never touched.",
            "Pyscho V1 — clean disk",
            MessageBoxButton.OKCancel, MessageBoxImage.Question);

        if (confirm != MessageBoxResult.OK) return;

        IsBusy = true;
        Status = "Removing files…";

        try
        {
            var report = await Task.Run(() => AppServices.Cleaner.Clean(selected.Select(s => s.Target)));
            Status = $"{CleanerService.FormatBytes(report.BytesFreed)} removed ({report.FilesRemoved:N0} files)" +
                     (report.Locked > 0 ? $", {report.Locked} in use were skipped." : ".");
            AppServices.Shell?.ShowToast(Status, "success");
            await ScanAsync();
        }
        catch (Exception ex)
        {
            Status = $"Cleanup failed: {ex.Message}";
            AppServices.ReportError(ex);
        }
        finally
        {
            IsBusy = false;
        }
    }
}
