using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace PyschoV1.App.Runtime;

/// <summary>
/// Hooks the CheckBox click, not the IsChecked property. That distinction matters: a toggle that is
/// already on when a page is built must show its final knob position immediately, while a real click
/// should still slide. Property-trigger animations run on page load too and can leave the offscreen
/// renderer (or a slow machine) at the first animation frame.
/// </summary>
public static class ToggleMotion
{
    private const double OffMargin = 3;
    private const double OnMargin = 23;
    private static readonly Duration Travel = TimeSpan.FromMilliseconds(170);

    public static readonly DependencyProperty EnabledProperty = DependencyProperty.RegisterAttached(
        "Enabled", typeof(bool), typeof(ToggleMotion), new PropertyMetadata(false, OnEnabledChanged));

    public static void SetEnabled(DependencyObject element, bool value) =>
        element.SetValue(EnabledProperty, value);

    public static bool GetEnabled(DependencyObject element) =>
        (bool)element.GetValue(EnabledProperty);

    private static void OnEnabledChanged(DependencyObject element, DependencyPropertyChangedEventArgs e)
    {
        if (element is not CheckBox checkBox) return;

        if (e.NewValue is true) checkBox.Click += OnClick;
        else checkBox.Click -= OnClick;
    }

    private static void OnClick(object sender, RoutedEventArgs e)
    {
        if (sender is not CheckBox checkBox) return;
        if (!Motion.Enabled) return;
        if (checkBox.Template.FindName("Knob", checkBox) is not FrameworkElement knob) return;

        // Click has already toggled IsChecked; the style's static setter is the final position.
        var on = checkBox.IsChecked == true;
        var animation = new ThicknessAnimation
        {
            From = new Thickness(on ? OffMargin : OnMargin, 0, 0, 0),
            To = new Thickness(on ? OnMargin : OffMargin, 0, 0, 0),
            Duration = Travel,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut },
            FillBehavior = FillBehavior.Stop
        };

        animation.Freeze();
        knob.BeginAnimation(FrameworkElement.MarginProperty, animation, HandoffBehavior.SnapshotAndReplace);
    }
}
