namespace PyschoV1.Core.Tweaks;

/// <summary>How much damage a tweak can do. Drives the badge colour and the confirmation flow.</summary>
public enum RiskLevel
{
    Safe,
    Caution,
    Advanced
}

/// <summary>Feature areas shown in the navigation rail.</summary>
public enum TweakModule
{
    Performance,
    Privacy
}

/// <summary>Registry hive, duplicated here so the catalog never touches Microsoft.Win32 directly.</summary>
public enum Hive
{
    LocalMachine,
    CurrentUser,
    Users
}

/// <summary>Service start modes as stored in HKLM\SYSTEM\CurrentControlSet\Services\&lt;name&gt;\Start.</summary>
public enum ServiceStart
{
    Boot = 0,
    System = 1,
    Automatic = 2,
    Manual = 3,
    Disabled = 4
}

/// <summary>A single reversible mutation. Every property is plain data so a plan can be shown before it runs.</summary>
public abstract record TweakOp
{
    /// <summary>Human readable one-liner used by Plan Preview.</summary>
    public abstract string Describe();
}

/// <summary>Set (or create) a registry value.</summary>
public sealed record RegistryValueOp(
    Hive Hive,
    string Path,
    string Name,
    object Value,
    RegistryKind Kind = RegistryKind.Dword) : TweakOp
{
    public override string Describe() => $"{HiveDisplay}.{Path}\\{Name} = {Value}";
    public string HiveDisplay => Hive switch
    {
        global::PyschoV1.Core.Tweaks.Hive.LocalMachine => "HKLM",
        global::PyschoV1.Core.Tweaks.Hive.CurrentUser => "HKCU",
        _ => "HKU"
    };
}

/// <summary>Remove a registry value entirely.</summary>
public sealed record RegistryDeleteOp(Hive Hive, string Path, string Name) : TweakOp
{
    public override string Describe() => $"delete {Hive}.{Path}\\{Name}";
}

/// <summary>Change how a Windows service starts.</summary>
public sealed record ServiceStartOp(string Service, ServiceStart Mode) : TweakOp
{
    public override string Describe() => $"service '{Service}' start = {Mode}";
}

/// <summary>Switch the active power scheme. Undo restores whatever was active before.</summary>
public sealed record PowerPlanOp(Guid Scheme, string Label) : TweakOp
{
    public override string Describe() => $"power plan '{Label}'";
}

public enum RegistryKind
{
    Dword,
    String,
    ExpandString,
    Binary,
    Qword
}

/// <summary>
/// One user-facing toggle. <see cref="TweakEngine"/> derives detection from the ops themselves,
/// so a tweak can never claim a state it did not actually set.
/// </summary>
public sealed class Tweak
{
    public required string Id { get; init; }
    public required string Title { get; init; }
    public required string Summary { get; init; }
    public required TweakModule Module { get; init; }
    public RiskLevel Risk { get; init; } = RiskLevel.Safe;
    public bool RequiresReboot { get; init; }
    public string? Category { get; init; }
    public required IReadOnlyList<TweakOp> Ops { get; init; }

    /// <summary>Empty means "every supported build". Otherwise a set of "10", "11" style tags.</summary>
    public IReadOnlyList<string> Platforms { get; init; } = Array.Empty<string>();

    /// <summary>Optional longer explanation shown under the title in the expanded card.</summary>
    public string? Detail { get; init; }

    public string RiskLabel => Risk switch
    {
        RiskLevel.Safe => "Safe",
        RiskLevel.Caution => "Caution",
        _ => "Advanced"
    };
}
