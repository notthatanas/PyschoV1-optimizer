using System.Collections.ObjectModel;
using System.Text.Json;
using System.Windows.Input;
using Microsoft.Win32;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Modules;

namespace PyschoV1.App.ViewModels;

public sealed class StartupItemViewModel : ObservableObject
{
    private bool _enabled;
    private bool _suppress;

    public StartupItemViewModel(StartupItem item)
    {
        Item = item;
        _enabled = item.IsEnabled;
    }

    public StartupItem Item { get; }
    public string Name => Item.Name;
    public string Command => Item.Command;
    public string Detail => Item.Detail;
    public string Location => $"{Item.Location} · {Item.Scope}";

    public bool IsEnabled
    {
        get => _enabled;
        set
        {
            if (_suppress) return;
            if (!Set(ref _enabled, value)) return;
            Apply(value);
        }
    }

    private void Apply(bool enabled)
    {
        if (!AppServices.IsElevated)
        {
            _suppress = true;
            _enabled = !enabled;
            _suppress = false;
            Raise(nameof(IsEnabled));
            AppServices.Shell?.ShowToast("Startup changes need administrator rights.", "error");
            return;
        }

        if (AppServices.Startup.SetEnabled(Item, enabled))
        {
            AppServices.Shell?.ShowToast($"{(enabled ? "Enabled" : "Disabled")}: {Name}", "info");
        }
        else
        {
            _suppress = true;
            _enabled = !enabled;
            _suppress = false;
            Raise(nameof(IsEnabled));
            AppServices.Shell?.ShowToast($"Windows refused the change for {Name}.", "error");
        }
    }

    public void Reload(StartupItem item)
    {
        _suppress = true;
        _enabled = item.IsEnabled;
        _suppress = false;
        Raise(nameof(IsEnabled));
    }
}

public sealed class StartupViewModel : ObservableObject
{
    private string _status = "";
    private int _enabledCount;
    private int _totalCount;

    public StartupViewModel()
    {
        RefreshCommand = new RelayCommand(Reload);
        BackupCommand = new RelayCommand(Backup);
        RestoreCommand = new RelayCommand(Restore);
        Reload();
    }

    public ObservableCollection<StartupItemViewModel> Items { get; } = new();

    public ICommand RefreshCommand { get; }
    public ICommand BackupCommand { get; }
    public ICommand RestoreCommand { get; }

    public string Status { get => _status; private set => Set(ref _status, value); }
    public int EnabledCount { get => _enabledCount; private set => Set(ref _enabledCount, value); }
    public int TotalCount { get => _totalCount; private set => Set(ref _totalCount, value); }
    public bool IsEmpty => Items.Count == 0;

    public string Summary => TotalCount == 0
        ? "No startup entries"
        : $"{EnabledCount} of {TotalCount} entries start with Windows";

    private void Reload()
    {
        var fresh = AppServices.Startup.Read();

        Items.Clear();
        foreach (var item in fresh)
        {
            var vm = new StartupItemViewModel(item);
            vm.PropertyChanged += (_, args) =>
            {
                if (args.PropertyName == nameof(StartupItemViewModel.IsEnabled)) Recount();
            };
            Items.Add(vm);
        }

        Recount();
        Raise(nameof(IsEmpty));
        Raise(nameof(Summary));
        Status = "Startup entries are toggled through the same flag Task Manager uses.";
    }

    private void Recount()
    {
        TotalCount = Items.Count;
        EnabledCount = Items.Count(i => i.IsEnabled);
        Raise(nameof(Summary));
    }

    private void Backup()
    {
        var dialog = new SaveFileDialog
        {
            Title = "Save startup backup",
            Filter = "Pyscho V1 backup (*.json)|*.json",
            FileName = $"pyscho-startup-{DateTime.Now:yyyyMMdd-HHmm}.json"
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            var backup = AppServices.Startup.CreateBackup();
            System.IO.File.WriteAllText(dialog.FileName,
                JsonSerializer.Serialize(backup, new JsonSerializerOptions { WriteIndented = true }));
            Status = $"Backup written to {System.IO.Path.GetFileName(dialog.FileName)}.";
            AppServices.Shell?.ShowToast("Startup backup saved.", "success");
        }
        catch (Exception ex)
        {
            Status = $"Backup failed: {ex.Message}";
        }
    }

    private void Restore()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Restore startup backup",
            Filter = "Pyscho V1 backup (*.json)|*.json|All files (*.*)|*.*"
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            var backup = JsonSerializer.Deserialize<StartupBackup>(System.IO.File.ReadAllText(dialog.FileName));
            if (backup is null)
            {
                Status = "That file is not a Pyscho V1 startup backup.";
                return;
            }

            var restored = AppServices.Startup.RestoreBackup(backup);
            Reload();
            Status = $"Restored {restored} entries from backup.";
            AppServices.Shell?.ShowToast(Status, "success");
        }
        catch (Exception ex)
        {
            Status = $"Restore failed: {ex.Message}";
        }
    }
}
