; Pyscho V1 Optimizer installer.
; Build from the repository root with:
;   powershell -ExecutionPolicy Bypass -File installer\build-installer.ps1
;
; Keep AppVersion in sync with src\PyschoV1.App\PyschoV1.App.csproj.
#define AppName "Pyscho V1 Optimizer"
#define AppShortName "Pyscho V1"
#define AppVersion "1.0.0"
#define AppPublisher "notThatanas"
#define AppExeName "PyschoV1.exe"
#define AppReleaseDir "..\release\" + AppVersion
#define AppId "{{8F4C2A71-3D6B-4E9A-B2C1-7E5D9A0F6B34}"

[Setup]
AppId={#AppId}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
AppComments=Performance and privacy configuration utility for Windows.
DefaultDirName={autopf}\{#AppShortName}
DefaultGroupName={#AppShortName}
DisableProgramGroupPage=yes
AllowNoIcons=yes
UninstallDisplayIcon={app}\{#AppExeName}
UninstallDisplayName={#AppName}
SetupIconFile=..\src\PyschoV1.App\Assets\app.ico
OutputDir=..\dist
OutputBaseFilename=PyschoV1-Setup-{#AppVersion}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ShowLanguageDialog=no
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
CloseApplications=yes
CloseApplicationsFilter={#AppExeName}
RestartApplications=no
VersionInfoVersion={#AppVersion}.0
VersionInfoCompany={#AppPublisher}
VersionInfoDescription={#AppName} Setup
VersionInfoProductName={#AppName}
VersionInfoProductVersion={#AppVersion}
VersionInfoProductTextVersion={#AppVersion}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "{#AppReleaseDir}\{#AppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "README-install.txt"; DestDir: "{app}"; DestName: "README.txt"; Flags: ignoreversion

[Dirs]
; Both the non-elevated and the elevated app must share one undo journal. The app prefers
; ProgramData, so give normal users write access to that folder and its journal subfolder.
Name: "{commonappdata}\PyschoV1"; Permissions: users-modify
Name: "{commonappdata}\PyschoV1\journal"; Permissions: users-modify

[Icons]
Name: "{group}\{#AppShortName}"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"
Name: "{group}\Uninstall {#AppShortName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppShortName}"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent runasoriginaluser
