using System.Diagnostics;
using System.Text.Json;

namespace PyschoV1.Core.Modules;

public sealed record AppxPackage(
    string Name,
    string PackageFullName,
    string Publisher,
    string Version,
    bool IsProtected)
{
    public string FriendlyName
    {
        get
        {
            var shortName = Name;
            var dot = shortName.LastIndexOf('.');
            if (dot > 0 && dot < shortName.Length - 1) shortName = shortName[(dot + 1)..];
            return Spaced(shortName);
        }
    }

    private static string Spaced(string value)
    {
        var result = new System.Text.StringBuilder(value.Length + 4);
        for (var i = 0; i < value.Length; i++)
        {
            if (i > 0 && char.IsUpper(value[i]) && !char.IsUpper(value[i - 1])) result.Append(' ');
            result.Append(value[i]);
        }
        return result.ToString();
    }
}

public sealed record DebloatResult(bool Success, int Removed, IReadOnlyList<string> Errors);

/// <summary>
/// AppX work is done by PowerShell because the WinRT projection needs the Windows SDK
/// projections, and shipping that for one page is not worth the startup cost.
/// </summary>
public sealed class DebloatService
{
    /// <summary>Packages the OS or the Store needs. Removing these breaks search, shell or updates.</summary>
    private static readonly string[] Protected =
    {
        "Microsoft.WindowsStore", "Microsoft.DesktopAppInstaller", "Microsoft.VCLibs",
        "Microsoft.NET.Native", "Microsoft.UI.Xaml", "Microsoft.WindowsAppRuntime",
        "Microsoft.Services.Store.Engagement", "Microsoft.Windows.ShellExperienceHost",
        "Microsoft.Windows.StartMenuExperienceHost", "Microsoft.Windows.Search",
        "Microsoft.AAD.BrokerPlugin", "Microsoft.AccountsControl", "Microsoft.LockApp",
        "Microsoft.Windows.ContentDeliveryManager", "Microsoft.SecHealthUI",
        "Microsoft.Windows.Client.WebExperience", "Microsoft.UI.Xaml.CBS",
        "MicrosoftWindows.Client.CBS", "MicrosoftWindows.Client.Core",
        "Microsoft.HEIFImageExtension", "Microsoft.VP9VideoExtensions",
        "Microsoft.WebMediaExtensions", "Microsoft.WebpImageExtension"
    };

    public async Task<IReadOnlyList<AppxPackage>> ListAsync(CancellationToken token = default)
    {
        const string script =
            "Get-AppxPackage | Where-Object { -not $_.IsFramework -and -not $_.NonRemovable } | " +
            "Select-Object Name,PackageFullName,PublisherDisplayName,Version | ConvertTo-Json -Compress -Depth 3";

        var (exit, output, error) = await RunPowerShellAsync(script, token);
        if (exit != 0 && string.IsNullOrWhiteSpace(output))
        {
            if (!string.IsNullOrWhiteSpace(error)) throw new InvalidOperationException(error.Trim());
            return Array.Empty<AppxPackage>();
        }

        var trimmed = output.Trim();
        if (trimmed.Length == 0) return Array.Empty<AppxPackage>();

        var list = new List<AppxPackage>();
        try
        {
            if (trimmed.StartsWith('['))
            {
                using var doc = JsonDocument.Parse(trimmed);
                foreach (var element in doc.RootElement.EnumerateArray())
                    Add(element, list);
            }
            else
            {
                using var doc = JsonDocument.Parse(trimmed);
                Add(doc.RootElement, list);
            }
        }
        catch (JsonException)
        {
            throw new InvalidOperationException("Windows returned an unreadable package list.");
        }

        return list.OrderBy(p => p.FriendlyName, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private static void Add(JsonElement element, List<AppxPackage> list)
    {
        var name = element.TryGetProperty("Name", out var n) ? n.GetString() ?? "" : "";
        var full = element.TryGetProperty("PackageFullName", out var f) ? f.GetString() ?? "" : "";
        var publisher = element.TryGetProperty("PublisherDisplayName", out var p) ? p.GetString() ?? "" : "";
        var version = element.TryGetProperty("Version", out var v) ? v.ToString() : "";
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(full)) return;

        var isProtected = Protected.Any(entry =>
            name.StartsWith(entry, StringComparison.OrdinalIgnoreCase));

        list.Add(new AppxPackage(name, full, publisher, version, isProtected));
    }

    public async Task<DebloatResult> RemoveAsync(IEnumerable<AppxPackage> packages, CancellationToken token = default)
    {
        var targets = packages.Where(p => !p.IsProtected).ToList();
        if (targets.Count == 0) return new DebloatResult(true, 0, Array.Empty<string>());

        var errors = new List<string>();
        var removed = 0;

        foreach (var package in targets)
        {
            token.ThrowIfCancellationRequested();
            var escaped = package.PackageFullName.Replace("'", "''");
            var script = $"try {{ Remove-AppxPackage -Package '{escaped}' -ErrorAction Stop; 'OK' }} catch {{ 'ERR:' + $_.Exception.Message }}";
            var (_, output, _) = await RunPowerShellAsync(script, token);
            if (output.Contains("OK", StringComparison.Ordinal)) removed++;
            else errors.Add($"{package.FriendlyName}: {output.Trim()}");
        }

        return new DebloatResult(errors.Count == 0, removed, errors);
    }

    private static Task<(int ExitCode, string Output, string Error)> RunPowerShellAsync(string script, CancellationToken token)
    {
        var tcs = new TaskCompletionSource<(int, string, string)>(TaskCreationOptions.RunContinuationsAsynchronously);

        // -EncodedCommand sidesteps every quoting difference between cmd, PowerShell and our script text.
        var encoded = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(script));
        var info = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand {encoded}",
            CreateNoWindow = true,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = System.Text.Encoding.UTF8,
            StandardErrorEncoding = System.Text.Encoding.UTF8
        };

        var process = new Process { StartInfo = info, EnableRaisingEvents = true };
        var stdout = new System.Text.StringBuilder();
        var stderr = new System.Text.StringBuilder();

        process.OutputDataReceived += (_, e) => { if (e.Data is not null) stdout.AppendLine(e.Data); };
        process.ErrorDataReceived += (_, e) => { if (e.Data is not null) stderr.AppendLine(e.Data); };

        // The process is disposed in the exit handler: disposing it earlier (a `using` scope around
        // the returned task) tears down the handle before Exited can fire and the caller hangs forever.
        process.Exited += (_, _) =>
        {
            try { tcs.TrySetResult((process.ExitCode, stdout.ToString(), stderr.ToString())); }
            finally { process.Dispose(); }
        };

        try
        {
            if (!process.Start())
            {
                process.Dispose();
                tcs.TrySetResult((-1, "", "PowerShell could not be started."));
                return tcs.Task;
            }

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            token.Register(() =>
            {
                try { if (!process.HasExited) process.Kill(true); } catch { }
            });

            // Hard ceiling so a wedged AppX service cannot freeze the page forever.
            _ = Task.Delay(TimeSpan.FromSeconds(120)).ContinueWith(_ =>
            {
                if (!tcs.TrySetResult((-1, stdout.ToString(), "PowerShell timed out."))) return;
                try { if (!process.HasExited) process.Kill(true); } catch { }
            }, TaskScheduler.Default);

            return tcs.Task;
        }
        catch (Exception ex)
        {
            process.Dispose();
            tcs.TrySetResult((-1, "", ex.Message));
            return tcs.Task;
        }
    }
}
