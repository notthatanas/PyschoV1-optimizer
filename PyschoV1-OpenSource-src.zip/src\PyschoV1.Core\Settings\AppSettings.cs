using System.Text.Json;

namespace PyschoV1.Core.Settings;

public sealed class AppSettings
{
    public bool CreateRestorePoint { get; set; } = true;
    public bool DryRun { get; set; }
    public bool ConfirmAdvanced { get; set; } = true;
    public bool ReduceMotion { get; set; }
    public string LastPage { get; set; } = "dashboard";

    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static string? _resolvedPath;

    /// <summary>Portable when a `PyschoV1.portable` marker sits next to the executable.</summary>
    public static bool IsPortable { get; private set; }

    public static string SettingsPath
    {
        get
        {
            if (_resolvedPath is not null) return _resolvedPath;

            var exeDir = AppContext.BaseDirectory;
            var portableMarker = Path.Combine(exeDir, "PyschoV1.portable");
            if (File.Exists(portableMarker) || Directory.Exists(Path.Combine(exeDir, "portable")))
            {
                IsPortable = true;
                _resolvedPath = Path.Combine(exeDir, "settings.json");
                return _resolvedPath;
            }

            _resolvedPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "PyschoV1", "settings.json");
            return _resolvedPath;
        }
    }

    public static AppSettings Load()
    {
        try
        {
            var path = SettingsPath;
            if (!File.Exists(path)) return new AppSettings();
            return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(path), JsonOptions) ?? new AppSettings();
        }
        catch
        {
            return new AppSettings();
        }
    }

    public void Save()
    {
        try
        {
            var path = SettingsPath;
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, JsonSerializer.Serialize(this, JsonOptions));
        }
        catch
        {
            // Settings are a convenience; a read-only install must still work.
        }
    }
}
