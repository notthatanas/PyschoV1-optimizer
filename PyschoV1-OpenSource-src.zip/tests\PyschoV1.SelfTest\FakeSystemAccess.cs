using PyschoV1.Core.Engine;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.SelfTest;

/// <summary>In-memory machine. The whole apply/detect/undo cycle runs without touching Windows.</summary>
internal sealed class FakeSystemAccess : ISystemAccess
{
    private readonly Dictionary<string, (string Value, string Kind)> _registry = new();
    private readonly Dictionary<string, string> _services = new(StringComparer.OrdinalIgnoreCase);
    private string? _plan = "381b4222-f694-41f0-9685-ff5bb260df2e";

    public bool IsElevated { get; set; } = true;
    public int WriteCount { get; private set; }
    public bool FailNextWrite { get; set; }

    private static string Key(Hive hive, string path, string name) => $"{hive}|{path}|{name}";

    public void SeedRegistry(Hive hive, string path, string name, string value, string kind = "Dword")
        => _registry[Key(hive, path, name)] = (value, kind);

    public void SeedService(string name, int start) => _services[name] = start.ToString();

    public void SeedPowerPlan(string guid) => _plan = guid;

    public RegistrySnapshot ReadRegistry(Hive hive, string path, string name)
    {
        var key = Key(hive, path, name);
        return _registry.TryGetValue(key, out var entry)
            ? new RegistrySnapshot(true, entry.Value, entry.Kind)
            : RegistrySnapshot.Missing;
    }

    public void WriteRegistry(Hive hive, string path, string name, string value, RegistryKind kind)
    {
        if (FailNextWrite) throw new UnauthorizedAccessException("Access is denied.");
        WriteCount++;
        _registry[Key(hive, path, name)] = (value, kind.ToString());
    }

    public void DeleteRegistry(Hive hive, string path, string name)
    {
        if (FailNextWrite) throw new UnauthorizedAccessException("Access is denied.");
        WriteCount++;
        _registry.Remove(Key(hive, path, name));
    }

    public string? ReadServiceStart(string service)
        => _services.TryGetValue(service, out var value) ? value : null;

    public void WriteServiceStart(string service, ServiceStart mode)
    {
        if (FailNextWrite) throw new UnauthorizedAccessException("Access is denied.");
        WriteCount++;
        _services[service] = ((int)mode).ToString();
    }

    public void StopService(string service) { }

    public string? ReadActivePowerPlan() => _plan;

    public void WriteActivePowerPlan(string guid)
    {
        if (FailNextWrite) throw new UnauthorizedAccessException("Access is denied.");
        WriteCount++;
        _plan = guid.ToLowerInvariant();
    }

    public int RegistryCount => _registry.Count;
}
