using PyschoV1.Core.Apps;
using PyschoV1.Core.Catalog;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Modules;
using PyschoV1.Core.Safety;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.SelfTest;

internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static int Main(string[] args)
    {
        if (args.Contains("--live")) return LiveChecks();

        Console.WriteLine("Pyscho V1 — engine self-test");
        Console.WriteLine(new string('-', 58));

        ApplyAndRevert_RegistryRoundTrip();
        ApplyAndRevert_DeleteOp();
        ApplyAndRevert_ServiceStart();
        ApplyAndRevert_PowerPlan();
        Detect_PartialState();
        DryRun_WritesNothing();
        Journal_PersistsAndReloads();
        Journal_WriteFailureRollsBack();
        Preset_ApplyAndRevertAll();
        Failure_RollsBackEarlierOps();
        NotElevated_SurfacesFriendlyError();
        Platform_Gating();
        Catalog_AllTweaksRoundTrip();
        MissingService_IsUnavailableAndFails();
        Cleaner_PathGuard();
        AppCatalog_IsSound();

        Console.WriteLine(new string('-', 58));
        Console.WriteLine($"passed {_passed}, failed {_failed}");
        return _failed == 0 ? 0 : 1;
    }

    // ---- cases ----

    private static void ApplyAndRevert_RegistryRoundTrip()
    {
        var sys = new FakeSystemAccess();
        var engine = NewEngine(sys);
        var tweak = new Tweak
        {
            Id = "test.reg",
            Title = "Registry round trip",
            Summary = "",
            Module = TweakModule.Performance,
            Ops = new TweakOp[] { new RegistryValueOp(Hive.CurrentUser, @"Software\Test", "Flag", 1) }
        };

        Check("registry: starts off", engine.GetState(tweak) == TweakState.Off);
        var applied = engine.Apply(tweak);
        Check("registry: apply succeeds", applied.Success);
        Check("registry: detects on", engine.GetState(tweak) == TweakState.On);

        var entry = engine.Journal.ReadAll().Single();
        var reverted = engine.Revert(entry);
        Check("registry: revert succeeds", reverted.Success);
        Check("registry: value removed again", engine.GetState(tweak) == TweakState.Off);
        Check("registry: no leftover value", sys.ReadRegistry(Hive.CurrentUser, @"Software\Test", "Flag").Existed == false);
    }

    private static void ApplyAndRevert_DeleteOp()
    {
        var sys = new FakeSystemAccess();
        sys.SeedRegistry(Hive.CurrentUser, @"Software\Test", "Junk", "hello", "String");
        var engine = NewEngine(sys);
        var tweak = new Tweak
        {
            Id = "test.delete",
            Title = "Delete op",
            Summary = "",
            Module = TweakModule.Privacy,
            Ops = new TweakOp[] { new RegistryDeleteOp(Hive.CurrentUser, @"Software\Test", "Junk") }
        };

        Check("delete: value present before", engine.GetState(tweak) == TweakState.Off);
        engine.Apply(tweak);
        Check("delete: value gone", engine.GetState(tweak) == TweakState.On);

        engine.Revert(engine.Journal.ReadAll().Single());
        var restored = sys.ReadRegistry(Hive.CurrentUser, @"Software\Test", "Junk");
        Check("delete: original string restored", restored.Existed && restored.Value == "hello" && restored.Kind == "String");
    }

    private static void ApplyAndRevert_ServiceStart()
    {
        var sys = new FakeSystemAccess();
        sys.SeedService("DiagTrack", 2);
        var engine = NewEngine(sys);
        var tweak = new Tweak
        {
            Id = "test.service",
            Title = "Service op",
            Summary = "",
            Module = TweakModule.Privacy,
            Ops = new TweakOp[] { new ServiceStartOp("DiagTrack", ServiceStart.Disabled) }
        };

        engine.Apply(tweak);
        Check("service: disabled", engine.GetState(tweak) == TweakState.On);
        engine.Revert(engine.Journal.ReadAll().Single());
        Check("service: previous start restored", sys.ReadServiceStart("DiagTrack") == "2");
    }

    private static void ApplyAndRevert_PowerPlan()
    {
        var sys = new FakeSystemAccess();
        var engine = NewEngine(sys);
        var tweak = PerformancePlanTweak();

        engine.Apply(tweak);
        Check("power: high performance active",
            sys.ReadActivePowerPlan() == PerformanceTweaksPlan.ToString());

        engine.Revert(engine.Journal.ReadAll().Single());
        Check("power: balanced restored",
            sys.ReadActivePowerPlan() == "381b4222-f694-41f0-9685-ff5bb260df2e");
    }

    private static readonly Guid PerformanceTweaksPlan = new("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c");

    private static Tweak PerformancePlanTweak() => new()
    {
        Id = "test.power",
        Title = "Power plan",
        Summary = "",
        Module = TweakModule.Performance,
        Ops = new TweakOp[] { new PowerPlanOp(PerformanceTweaksPlan, "High performance") }
    };

    private static void Detect_PartialState()
    {
        var sys = new FakeSystemAccess();
        sys.SeedRegistry(Hive.CurrentUser, @"Software\Test", "A", "1");
        var engine = NewEngine(sys);
        var tweak = new Tweak
        {
            Id = "test.partial",
            Title = "Two ops",
            Summary = "",
            Module = TweakModule.Performance,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Test", "A", 1),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Test", "B", 1)
            }
        };
        Check("detect: partial when one of two matches", engine.GetState(tweak) == TweakState.Partial);

        engine.Apply(tweak);
        Check("detect: on after apply", engine.GetState(tweak) == TweakState.On);
    }

    private static void DryRun_WritesNothing()
    {
        var sys = new FakeSystemAccess();
        var engine = NewEngine(sys);
        var tweak = Catalog().First();
        var result = engine.Apply(tweak, dryRun: true);

        Check("dry run: reports success", result.Success && result.DryRun);
        Check("dry run: no writes performed", sys.WriteCount == 0);
        Check("dry run: no journal entry", engine.Journal.ReadAll().Count == 0);
        Check("dry run: plan is populated", result.Plan.Count == tweak.Ops.Count);
    }

    private static void Journal_PersistsAndReloads()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var sys = new FakeSystemAccess();
            var journal = new TweakJournal(dir);
            var engine = new TweakEngine(sys, journal);
            engine.Apply(Catalog().First());

            var reloaded = new TweakJournal(dir).ReadAll();
            Check("journal: entry survives reload", reloaded.Count == 1);
            Check("journal: patches preserved", reloaded[0].Patches.Count > 0);
            Check("journal: origin recorded", reloaded[0].Origin == "manual");
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void Journal_WriteFailureRollsBack()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var sys = new FakeSystemAccess();
            var journal = new TweakJournal(dir);

            // Replace the journal directory with a file so the next append cannot succeed.
            Directory.Delete(dir, true);
            File.WriteAllText(dir, "not a directory");

            var engine = new TweakEngine(sys, journal);
            var tweak = new Tweak
            {
                Id = "test.journal-failure",
                Title = "Journal failure",
                Summary = "",
                Module = TweakModule.Performance,
                Ops = new TweakOp[]
                {
                    new RegistryValueOp(Hive.CurrentUser, @"Software\Test", "Journaled", 1)
                }
            };

            var result = engine.Apply(tweak);
            Check("journal failure: apply reports failure", !result.Success);
            Check("journal failure: value rolled back",
                !sys.ReadRegistry(Hive.CurrentUser, @"Software\Test", "Journaled").Existed);
            Check("journal failure: error explains the rollback",
                result.Error?.Contains("undo journal", StringComparison.OrdinalIgnoreCase) == true);
        }
        finally
        {
            try { File.Delete(dir); } catch { }
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void Preset_ApplyAndRevertAll()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var sys = new FakeSystemAccess();
            // Seed every service the catalog can touch, so presets that disable services
            // (SysMain, WMPNetworkSvc, XboxNetApiSvc, ...) behave like a real machine.
            SeedCatalogServices(sys);
            var engine = new TweakEngine(sys, new TweakJournal(dir));

            var preset = TweakCatalog.FindPreset("quiet")!;
            foreach (var id in preset.TweakIds)
            {
                var tweak = TweakCatalog.Find(id)!;
                var result = engine.Apply(tweak, origin: "preset:quiet");
                if (!result.Success) Check($"preset: apply {id}", false, result.Error);
            }

            var allOn = preset.TweakIds.All(id => engine.GetState(TweakCatalog.Find(id)!) == TweakState.On);
            Check("preset: every tweak applied", allOn);
            Check("preset: one journal entry per tweak", engine.Journal.ReadAll().Count == preset.TweakIds.Count);

            foreach (var entry in engine.Journal.ReadAll()) engine.Revert(entry);
            Check("preset: revert restores services", sys.ReadServiceStart("SysMain") == "2" && sys.ReadServiceStart("WSearch") == "2");
            Check("preset: state off after revert",
                preset.TweakIds.All(id => engine.GetState(TweakCatalog.Find(id)!) == TweakState.Off));
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void Failure_RollsBackEarlierOps()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var tweak = new Tweak
            {
                Id = "test.rollback",
                Title = "Rollback",
                Summary = "",
                Module = TweakModule.Performance,
                Ops = new TweakOp[]
                {
                    new RegistryValueOp(Hive.CurrentUser, @"Software\Test", "First", 1),
                    new RegistryValueOp(Hive.CurrentUser, @"Software\Test", "Second", 1)
                }
            };

            // Fail on the second write only.
            var partial = new FailAfterOneWrite(new FakeSystemAccess());
            var failingEngine = new TweakEngine(partial, new TweakJournal(dir));
            var result = failingEngine.Apply(tweak);

            Check("rollback: apply reports failure", !result.Success);
            Check("rollback: first write undone", partial.ReadRegistry(Hive.CurrentUser, @"Software\Test", "First").Existed == false);
            Check("rollback: no journal entry", failingEngine.Journal.ReadAll().Count == 0);
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void NotElevated_SurfacesFriendlyError()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var sys = new FakeSystemAccess { FailNextWrite = true };
            var engine = new TweakEngine(sys, new TweakJournal(dir));
            var result = engine.Apply(Catalog().First());
            Check("elevation: failure detected", !result.Success);
            Check("elevation: flagged for the UI", result.NeedsElevation);
            Check("elevation: message mentions administrator",
                result.Error?.Contains("administrator", StringComparison.OrdinalIgnoreCase) == true);
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void Platform_Gating()
    {
        var copilot = TweakCatalog.Find("priv.copilot")!;
        Check("platform: win11 toggle hidden on win10 build", !TweakEngine.SupportsPlatform(copilot, 19045));
        Check("platform: win11 toggle shown on win11 build", TweakEngine.SupportsPlatform(copilot, 22631));

        var universal = TweakCatalog.Find("perf.gamemode")!;
        Check("platform: universal toggle always shown",
            TweakEngine.SupportsPlatform(universal, 19045) && TweakEngine.SupportsPlatform(universal, 26100));
    }

    private static void Catalog_AllTweaksRoundTrip()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var sys = new FakeSystemAccess();
            SeedCatalogServices(sys);
            var engine = new TweakEngine(sys, new TweakJournal(dir));
            var failures = new List<string>();

            foreach (var tweak in TweakCatalog.All)
            {
                var applied = engine.Apply(tweak);
                if (!applied.Success)
                {
                    failures.Add($"{tweak.Id} apply: {applied.Error}");
                    continue;
                }

                if (engine.GetState(tweak) != TweakState.On)
                    failures.Add($"{tweak.Id} state after apply: {engine.GetState(tweak)}");

                var entry = engine.Journal.ReadAll()
                    .FirstOrDefault(e => e.TweakId == tweak.Id && !e.Reverted);
                if (entry is null)
                {
                    failures.Add($"{tweak.Id} no journal entry");
                    continue;
                }

                var reverted = engine.Revert(entry);
                if (!reverted.Success)
                    failures.Add($"{tweak.Id} revert: {reverted.Error}");
                else if (engine.GetState(tweak) != TweakState.Off)
                    failures.Add($"{tweak.Id} state after revert: {engine.GetState(tweak)}");
            }

            Check($"catalog: all {TweakCatalog.All.Count} tweaks apply, detect and revert",
                failures.Count == 0, string.Join(" | ", failures.Take(6)));
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void MissingService_IsUnavailableAndFails()
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        try
        {
            var sys = new FakeSystemAccess(); // DiagTrack is deliberately absent.
            var tweak = TweakCatalog.Find("priv.diagtrack")!;
            var engine = new TweakEngine(sys, new TweakJournal(dir));

            Check("service: absent service reports unavailable",
                engine.GetState(tweak) == TweakState.Unavailable);

            var result = engine.Apply(tweak);
            Check("service: absent service refuses to apply", !result.Success);
            Check("service: absent service writes nothing",
                result.Entry is null && engine.Journal.ReadAll().Count == 0);
            Check("service: error names the missing service",
                result.Error?.Contains("DiagTrack", StringComparison.OrdinalIgnoreCase) == true);
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    private static void SeedCatalogServices(FakeSystemAccess sys)
    {
        foreach (var service in TweakCatalog.All
                     .SelectMany(t => t.Ops)
                     .OfType<ServiceStartOp>()
                     .Select(op => op.Service)
                     .Distinct(StringComparer.OrdinalIgnoreCase))
        {
            sys.SeedService(service, 2);
        }
    }

    private static void Cleaner_PathGuard()
    {
        Check("cleaner: refuses drive root", !CleanerService.IsSafePath(@"C:\"));
        Check("cleaner: refuses windows folder", !CleanerService.IsSafePath(Environment.GetFolderPath(Environment.SpecialFolder.Windows)));
        Check("cleaner: allows user temp",
            CleanerService.IsSafePath(Path.Combine(Path.GetTempPath(), "something")));
        Check("cleaner: refuses sibling escape",
            !CleanerService.IsSafePath(@"C:\Windows..\..\Users\Public"));

        var profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            .TrimEnd(Path.DirectorySeparatorChar);
        Check("cleaner: refuses a sibling with the same prefix",
            !CleanerService.IsSafePath(profile + "2" + Path.DirectorySeparatorChar + "evil"));
    }

    private static void AppCatalog_IsSound()
    {
        var apps = AppCatalog.All;
        var ids = apps.Select(a => a.Id).ToList();

        Check("apps: catalog has the expected size", apps.Count >= 40, apps.Count.ToString());
        Check("apps: ids are unique",
            ids.Distinct(StringComparer.OrdinalIgnoreCase).Count() == ids.Count);
        Check("apps: categories are known",
            apps.All(a => AppCatalog.Categories.Contains(a.Category)),
            string.Join(", ", apps.Where(a => !AppCatalog.Categories.Contains(a.Category)).Select(a => a.Id)));
        Check("apps: homepages are https",
            apps.All(a => a.Homepage.StartsWith("https://", StringComparison.OrdinalIgnoreCase)),
            string.Join(", ", apps.Where(a => !a.Homepage.StartsWith("https://")).Select(a => a.Id)));
        Check("apps: direct links are https",
            apps.All(a => a.DirectUrl is null ||
                          a.DirectUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase)));
        Check("apps: winget ids contain no spaces",
            apps.All(a => a.WingetId is null || (a.WingetId.Length > 2 && !a.WingetId.Contains(' '))),
            string.Join(", ", apps.Where(a => a.WingetId is not null &&
                                              (a.WingetId.Length <= 2 || a.WingetId.Contains(' '))).Select(a => a.Id)));
        Check("apps: every entry has installed-name hints",
            apps.All(a => a.InstalledNameHints.Count > 0 &&
                          a.InstalledNameHints.All(h => !string.IsNullOrWhiteSpace(h))));

        var git = apps.First(a => a.Id == "git");
        var withGit = new List<InstalledApp> { new("Git", "2.45", null), new("GitHub Desktop", "3.3", null) };
        Check("apps: git hint matches Git", AppInstallerService.FindInstalled(git, withGit)?.Name == "Git");
        Check("apps: git hint does not match GitHub Desktop",
            AppInstallerService.FindInstalled(git, new List<InstalledApp> { new("GitHub Desktop", "3.3", null) }) is null);

        var vscode = apps.First(a => a.Id == "vscode");
        Check("apps: matches Microsoft Visual Studio Code",
            AppInstallerService.FindInstalled(vscode,
                new List<InstalledApp> { new("Microsoft Visual Studio Code", "1.96", null) }) is not null);

        var sevenZip = apps.First(a => a.Id == "sevenzip");
        Check("apps: matches a versioned 7-Zip entry",
            AppInstallerService.FindInstalled(sevenZip,
                new List<InstalledApp> { new("7-Zip 24.09 (x64)", "24.09", null) }) is not null);
    }

    /// <summary>
    /// Read-only checks against the real machine: every module is exercised, nothing is written.
    /// This is how the live integrations are verified without touching system state.
    /// </summary>
    private static int LiveChecks()
    {
        Console.WriteLine("Pyscho V1 — live read-only checks");
        Console.WriteLine(new string('-', 58));

        var monitor = new PyschoV1.Core.SysInfo.HardwareMonitor();
        monitor.Sample();
        Thread.Sleep(1100);
        var sample = monitor.Sample();
        Console.WriteLine($"cpu        {sample.CpuPercent:0.0} %");
        Console.WriteLine($"memory     {sample.RamUsedGb:0.0} / {sample.RamTotalGb:0.0} GB ({sample.RamPercent:0.0} %)");
        Console.WriteLine($"disk busy  {sample.DiskBusyPercent:0.0} %");
        Console.WriteLine($"network    {sample.NetworkMbps:0.000} Mb/s");
        Check("hardware: cpu sample in range", sample.CpuPercent is >= 0 and <= 100, sample.CpuPercent.ToString());
        Check("hardware: memory total detected", sample.RamTotalGb > 1, sample.RamTotalGb.ToString());
        monitor.Dispose();

        var specs = PyschoV1.Core.SysInfo.HardwareMonitor.ReadSpecs();
        Console.WriteLine($"cpu name   {specs.CpuName}");
        Console.WriteLine($"gpu name   {specs.GpuName}");
        Console.WriteLine($"os         {specs.OsName} ({specs.OsBuild})");
        Check("hardware: cpu name resolved", specs.CpuName != "Unknown CPU");

        var drives = PyschoV1.Core.SysInfo.HardwareMonitor.ReadDrives();
        Check("hardware: at least one drive", drives.Count > 0);
        foreach (var drive in drives.Take(4))
            Console.WriteLine($"drive      {drive.Name} {drive.FreeGb:0.0} free of {drive.TotalGb:0.0} GB");

        var startup = new PyschoV1.Core.Modules.StartupService().Read();
        Check("startup: entries read", startup.Count > 0, startup.Count.ToString());
        Check("startup: no desktop.ini noise", startup.All(s => !s.Name.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)));
        foreach (var item in startup.Take(6))
            Console.WriteLine($"startup    {(item.IsEnabled ? "on " : "off")} {item.Name} [{item.Scope}]");

        var adapters = new PyschoV1.Core.Modules.NetworkService().GetAdapters();
        Check("network: physical adapters only", adapters.Count is > 0 and < 6, adapters.Count.ToString());
        foreach (var adapter in adapters)
            Console.WriteLine($"adapter    {adapter.Name} ({adapter.Kind}, {adapter.StatusLabel}, dns {adapter.DnsSummary})");

        var cleaner = new PyschoV1.Core.Modules.CleanerService();
        Check("cleaner: targets defined", cleaner.Targets.Count >= 10, cleaner.Targets.Count.ToString());
        var tempTarget = cleaner.Targets.First(t => t.Id == "temp.user");
        var scan = cleaner.Scan(tempTarget);
        Console.WriteLine($"cleaner    user temp: {PyschoV1.Core.Modules.CleanerService.FormatBytes(scan.Bytes)} in {scan.Files:N0} files");
        Check("cleaner: temp scan read", scan.Accessible);

        try
        {
            var packages = new PyschoV1.Core.Modules.DebloatService().ListAsync().GetAwaiter().GetResult();
            Check("debloat: package list parsed", packages.Count > 0, packages.Count.ToString());
            foreach (var package in packages.Take(5))
                Console.WriteLine($"appx       {package.FriendlyName} ({package.Publisher})");
        }
        catch (Exception ex)
        {
            Check("debloat: package list parsed", false, ex.Message);
        }

        var engine = new PyschoV1.Core.Engine.TweakEngine(
            new PyschoV1.Core.Engine.WindowsSystemAccess(),
            new PyschoV1.Core.Safety.TweakJournal(Path.Combine(Path.GetTempPath(), "pyscho-live-journal")));

        Console.WriteLine();
        Console.WriteLine("tweak detection (read-only)");
        foreach (var tweak in TweakCatalog.All)
        {
            var state = engine.GetState(tweak);
            Console.WriteLine($"  {state,-11} {tweak.Id}");
        }

        Console.WriteLine(new string('-', 58));
        Console.WriteLine($"passed {_passed}, failed {_failed}");
        return _failed == 0 ? 0 : 1;
    }

    // ---- helpers ----

    private static TweakEngine NewEngine(FakeSystemAccess sys)
    {
        var dir = Path.Combine(Path.GetTempPath(), "pyscho-selftest-" + Guid.NewGuid().ToString("n"));
        Directory.CreateDirectory(dir);
        return new TweakEngine(sys, new TweakJournal(dir));
    }

    private static IReadOnlyList<Tweak> Catalog() => TweakCatalog.ForModule(TweakModule.Performance);

    private static void Check(string name, bool condition, string? detail = null)
    {
        if (condition)
        {
            _passed++;
            Console.WriteLine($"  PASS  {name}");
        }
        else
        {
            _failed++;
            Console.WriteLine($"  FAIL  {name}{(detail is null ? "" : $"  [{detail}]")}");
        }
    }

    /// <summary>Fails the second write, to prove the engine unwinds the first one.</summary>
    private sealed class FailAfterOneWrite : ISystemAccess
    {
        private readonly FakeSystemAccess _inner;
        private int _writes;

        public FailAfterOneWrite(FakeSystemAccess inner) => _inner = inner;

        public bool IsElevated => _inner.IsElevated;

        public RegistrySnapshot ReadRegistry(Hive hive, string path, string name) => _inner.ReadRegistry(hive, path, name);
        public void WriteRegistry(Hive hive, string path, string name, string value, RegistryKind kind)
        {
            if (_writes >= 1) throw new UnauthorizedAccessException("Access is denied.");
            _writes++;
            _inner.WriteRegistry(hive, path, name, value, kind);
        }
        public void DeleteRegistry(Hive hive, string path, string name) => _inner.DeleteRegistry(hive, path, name);
        public string? ReadServiceStart(string service) => _inner.ReadServiceStart(service);
        public void WriteServiceStart(string service, ServiceStart mode) => _inner.WriteServiceStart(service, mode);
        public void StopService(string service) { }
        public string? ReadActivePowerPlan() => _inner.ReadActivePowerPlan();
        public void WriteActivePowerPlan(string guid) => _inner.WriteActivePowerPlan(guid);
    }
}
