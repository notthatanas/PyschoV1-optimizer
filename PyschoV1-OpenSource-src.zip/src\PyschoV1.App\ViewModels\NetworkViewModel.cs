using System.Collections.ObjectModel;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Modules;

namespace PyschoV1.App.ViewModels;

public sealed class NetworkViewModel : ObservableObject
{
    private AdapterInfo? _selectedAdapter;
    private string _status = "";
    private string _pingHost = "1.1.1.1";
    private string _pingResult = "";
    private bool _pinging;
    private bool _pingOk;

    public NetworkViewModel()
    {
        ApplyPresetCommand = new RelayCommand<DnsPreset>(preset => ApplyPreset(preset));
        AutomaticCommand = new RelayCommand(() => ApplyPreset(null));
        FlushCommand = new AsyncRelayCommand(FlushAsync);
        PingCommand = new AsyncRelayCommand(PingAsync);
        RefreshCommand = new RelayCommand(() =>
        {
            LoadAdapters();
            Status = "Adapter list refreshed.";
        });

        LoadAdapters();
    }

    public ObservableCollection<AdapterInfo> Adapters { get; } = new();
    public ObservableCollection<DnsPreset> Presets { get; } = new(NetworkService.Presets);

    public ICommand ApplyPresetCommand { get; }
    public ICommand AutomaticCommand { get; }
    public ICommand FlushCommand { get; }
    public ICommand PingCommand { get; }
    public ICommand RefreshCommand { get; }

    public AdapterInfo? SelectedAdapter
    {
        get => _selectedAdapter;
        set
        {
            if (!Set(ref _selectedAdapter, value)) return;
            Raise(nameof(HasAdapter));
            Raise(nameof(AdapterDetail));
        }
    }

    public bool HasAdapter => _selectedAdapter is not null;

    public string AdapterDetail => _selectedAdapter is null
        ? "No adapter selected"
        : $"{_selectedAdapter.Description} · DNS {_selectedAdapter.DnsSummary}";

    public string Status { get => _status; private set => Set(ref _status, value); }

    public string PingHost { get => _pingHost; set => Set(ref _pingHost, value); }

    public string PingResult
    {
        get => _pingResult;
        private set => Set(ref _pingResult, value);
    }

    public bool PingOk { get => _pingOk; private set => Set(ref _pingOk, value); }

    public bool IsPinging
    {
        get => _pinging;
        private set
        {
            if (Set(ref _pinging, value)) (PingCommand as AsyncRelayCommand)?.RaiseCanExecuteChanged();
        }
    }

    private void LoadAdapters()
    {
        var previousId = _selectedAdapter?.Id;
        Adapters.Clear();
        foreach (var adapter in AppServices.Network.GetAdapters()) Adapters.Add(adapter);
        SelectedAdapter = Adapters.FirstOrDefault(a => a.Id == previousId) ?? Adapters.FirstOrDefault();
    }

    private void ApplyPreset(DnsPreset? preset)
    {
        if (_selectedAdapter is null)
        {
            Status = "Pick an adapter first.";
            return;
        }

        if (!AppServices.IsElevated)
        {
            AppServices.Shell?.ShowToast("Changing DNS needs administrator rights.", "error");
            Status = "Administrator rights required.";
            return;
        }

        if (AppServices.Network.ApplyDns(_selectedAdapter.Id, preset))
        {
            Status = preset is null
                ? $"{_selectedAdapter.Name}: DNS back to automatic."
                : $"{_selectedAdapter.Name}: DNS set to {preset.Name}.";
            AppServices.Shell?.ShowToast(Status, "success");
            LoadAdapters();
        }
        else
        {
            Status = "Windows refused the DNS change.";
        }
    }

    private async Task FlushAsync()
    {
        var ok = await Task.Run(() => AppServices.Network.FlushDns(out var output));
        Status = ok ? "DNS cache flushed." : "Could not flush the DNS cache.";
        AppServices.Shell?.ShowToast(Status, ok ? "success" : "error");
    }

    private async Task PingAsync()
    {
        if (string.IsNullOrWhiteSpace(_pingHost)) return;
        IsPinging = true;
        PingResult = $"Pinging {_pingHost}…";
        try
        {
            var summary = await AppServices.Network.PingAsync(_pingHost.Trim(), 5);
            PingOk = summary.Success;
            PingResult = summary.Success
                ? $"{summary.AverageMs:0.0} ms average · {summary.MinMs:0}/{summary.MaxMs:0} min/max · {summary.LossPercent:0}% loss"
                : summary.Error ?? "No reply.";
        }
        finally
        {
            IsPinging = false;
        }
    }
}
