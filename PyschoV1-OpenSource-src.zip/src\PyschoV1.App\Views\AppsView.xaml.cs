using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using PyschoV1.App.Runtime;
using PyschoV1.App.ViewModels;

namespace PyschoV1.App.Views;

public partial class AppsView : UserControl
{
    public AppsView()
    {
        InitializeComponent();
        IsVisibleChanged += (_, args) =>
        {
            // Coming back to the page re-reads installed apps so fresh installs show up.
            if (args.NewValue is true && DataContext is AppsViewModel vm) vm.Refresh();
        };
    }

    /// <summary>
    /// Card lift is a code animation so it can respect Reduce motion and so the transform is a
    /// mutable local instance (data-template freezables can be sealed).
    /// </summary>
    private void OnAppCardMouseEnter(object sender, MouseEventArgs e)
    {
        if (sender is not Border border) return;

        var translate = border.RenderTransform as TranslateTransform;
        if (translate is null || translate.IsFrozen)
        {
            translate = new TranslateTransform();
            border.RenderTransform = translate;
        }

        translate.BeginAnimation(TranslateTransform.YProperty, null);
        if (!Motion.Enabled)
        {
            translate.Y = 0;
            return;
        }

        translate.Y = -2;
        translate.BeginAnimation(TranslateTransform.YProperty, Motion.Tween(0, -2, 160));
    }

    private void OnAppCardMouseLeave(object sender, MouseEventArgs e)
    {
        if (sender is not Border border) return;
        if (border.RenderTransform is not TranslateTransform translate) return;

        translate.BeginAnimation(TranslateTransform.YProperty, null);
        translate.Y = 0;
        if (Motion.Enabled) translate.BeginAnimation(TranslateTransform.YProperty, Motion.Tween(-2, 0, 180));
    }
}
