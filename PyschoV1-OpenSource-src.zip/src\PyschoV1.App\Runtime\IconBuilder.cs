using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PyschoV1.App.Runtime;

/// <summary>
/// Draws the Pyscho V1 mark with WPF and writes a multi-resolution .ico (PNG-compressed entries,
/// supported since Vista). Vector at every size, so the 16px shell icon stays sharp.
/// </summary>
public static class IconBuilder
{
    private static readonly int[] Sizes = { 16, 20, 24, 32, 40, 48, 64, 128, 256 };

    public static void Write(string path)
    {
        var directory = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

        var images = Sizes.Select(size => (Size: size, Png: Encode(Render(size)))).ToList();

        // Write beside the target then swap it in: an indexer or scanner can hold the old file open.
        var temp = path + ".tmp";
        using (var stream = File.Create(temp))
        using (var writer = new BinaryWriter(stream))
        {

            writer.Write((ushort)0);              // reserved
            writer.Write((ushort)1);              // type: icon
            writer.Write((ushort)images.Count);

            var offset = 6 + images.Count * 16;
            foreach (var (size, png) in images)
            {
                writer.Write((byte)(size >= 256 ? 0 : size));
                writer.Write((byte)(size >= 256 ? 0 : size));
                writer.Write((byte)0);            // palette size
                writer.Write((byte)0);            // reserved
                writer.Write((ushort)1);          // colour planes
                writer.Write((ushort)32);         // bits per pixel
                writer.Write(png.Length);
                writer.Write(offset);
                offset += png.Length;
            }

            foreach (var (_, png) in images) writer.Write(png);
            writer.Flush();
        }

        File.Move(temp, path, overwrite: true);
        Verify(path);
    }

    /// <summary>Re-reads the written file through the WPF decoder and saves the largest frame as PNG.</summary>
    private static void Verify(string path)
    {
        using var memory = new MemoryStream(File.ReadAllBytes(path));
        var decoder = BitmapDecoder.Create(memory, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
        var frame = decoder.Frames.OrderByDescending(f => f.PixelWidth).First();

        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(frame));
        using var preview = File.Create(Path.ChangeExtension(path, ".preview.png"));
        encoder.Save(preview);
    }

    private static byte[] Encode(BitmapSource bitmap)
    {
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var memory = new MemoryStream();
        encoder.Save(memory);
        return memory.ToArray();
    }

    private static RenderTargetBitmap Render(int size)
    {
        var visual = new DrawingVisual();
        var s = (double)size;

        using (var dc = visual.RenderOpen())
        {
            var inset = s * 0.015;
            var bounds = new Rect(inset, inset, s - inset * 2, s - inset * 2);
            var radius = s * 0.23;

            var background = new LinearGradientBrush(
                Color.FromRgb(0x9E, 0x86, 0xFF),
                Color.FromRgb(0x55, 0x33, 0xD6),
                new Point(0, 0), new Point(1, 1));

            dc.DrawRoundedRectangle(background, null, bounds, radius, radius);

            var highlight = new LinearGradientBrush(
                Color.FromArgb(0x3C, 0xFF, 0xFF, 0xFF), Colors.Transparent,
                new Point(0.5, 0), new Point(0.5, 1));
            dc.DrawRoundedRectangle(highlight, null,
                new Rect(inset, inset, s - inset * 2, (s - inset * 2) * 0.52), radius, radius);

            // Parsed geometries are frozen; clone so the transform can be applied.
            var bolt = Geometry.Parse("M13 2 L5 13.5 H10.5 L9.8 22 L19 10 H13.4 Z").Clone();
            var scale = s * 0.62 / 24.0;
            var shift = (s - 24 * scale) / 2.0;
            var transform = new TransformGroup();
            transform.Children.Add(new ScaleTransform(scale, scale));
            transform.Children.Add(new TranslateTransform(shift, shift));
            bolt.Transform = transform;

            dc.DrawGeometry(Brushes.White, null, bolt);
        }

        var bitmap = new RenderTargetBitmap(size, size, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(visual);
        bitmap.Freeze();
        return bitmap;
    }
}
