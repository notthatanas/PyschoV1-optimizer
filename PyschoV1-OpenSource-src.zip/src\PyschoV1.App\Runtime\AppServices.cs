using System.Diagnostics;
using System.IO;
using System.Windows;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Apps;
using PyschoV1.Core.Modules;
using PyschoV1.Core.Safety;
using PyschoV1.Core.Settings;
using PyschoV1.Core.SysInfo;

namespace PyschoV1.App.Runtime;

/// <summary>
/// Small explicit composition root. A DI container would add startup cost and a package
/// dependency for ten singletons, so the wiring lives here.
/// </summary>
public static class AppServices
{
    public static TweakEngine Engine { get; private set; } = null!;
    public static AppSettings Settings { get; private set; } = null!;
    public static HardwareMonitor Monitor { get; private set; } = null!;
    public static CleanerService Cleaner { get; private set; } = null!;
    public static NetworkService Network { get; private set; } = null!;
    public static StartupService Startup { get; private set; } = null!;
    public static DebloatService Debloat { get; private set; } = null!;
    public static AppInstallerService Apps { get; private set; } = null!;
    public static JournalViewModelBridge Journal { get; } = new();

    /// <summary>Set once by the window; lets any page raise a toast through the shell.</summary>
    public static ViewModels.ShellViewModel? Shell { get; set; }

    public static bool IsElevated => Engine.IsElevated;
    public static int WindowsBuild { get; private set; }

    // WMI-free, but still several registry reads. Deferred until a page actually needs it so the
    // first window paints before any machine inventory work runs.
    private static readonly Lazy<SystemSpecs> LazySpecs = new(ReadSpecsSafe, LazyThreadSafetyMode.ExecutionAndPublication);
    public static SystemSpecs Specs => LazySpecs.Value;

    private static bool _restorePointTaken;
    private static string? _restorePointNote;

    public static void Initialize()
    {
        Settings = AppSettings.Load();
        Engine = new TweakEngine(new WindowsSystemAccess(), new TweakJournal());
        Monitor = new HardwareMonitor(TimeSpan.FromSeconds(1));
        Cleaner = new CleanerService();
        Network = new NetworkService();
        Startup = new StartupService();
        Debloat = new DebloatService();
        Apps = new AppInstallerService();
        WindowsBuild = Environment.OSVersion.Version.Build;
    }

    private static SystemSpecs ReadSpecsSafe()
    {
        try
        {
            return HardwareMonitor.ReadSpecs();
        }
        catch
        {
            // A locked-down machine can refuse one of the inventory reads. The dashboard should
            // still open with honest placeholders instead of taking the whole app down.
            var build = Environment.OSVersion.Version.Build;
            return new SystemSpecs(
                "Unknown CPU",
                Environment.ProcessorCount,
                Environment.ProcessorCount,
                "Unknown GPU",
                0,
                build >= 22000 ? "Windows 11" : "Windows 10",
                build.ToString(),
                Environment.MachineName);
        }
    }

    /// <summary>Takes at most one restore point per session, and only if the user asked for one.</summary>
    public static async Task<string?> EnsureRestorePointAsync()
    {
        if (!Settings.CreateRestorePoint) return null;
        if (_restorePointTaken) return _restorePointNote;
        _restorePointTaken = true;

        var result = await Task.Run(() => RestorePoint.Create("Pyscho V1 Optimizer"));
        _restorePointNote = result.Message;
        return _restorePointNote;
    }

    public static void RequestElevation()
    {
        try
        {
            var exe = Environment.ProcessPath;
            if (string.IsNullOrEmpty(exe))
            {
                Shell?.ShowToast("The executable path could not be resolved, so elevation cannot start.", "error");
                return;
            }

            var elevated = Process.Start(new ProcessStartInfo
            {
                FileName = exe,
                UseShellExecute = true,
                Verb = "runas",
                WorkingDirectory = AppContext.BaseDirectory
            });

            if (elevated is null) throw new InvalidOperationException("Windows did not start the elevated copy.");

            Application.Current.Shutdown();
        }
        catch (Exception ex)
        {
            // Cancelling UAC is a normal choice, not a crash: tell the user instead of closing silently.
            ReportError(ex);
            Shell?.ShowToast("Administrator launch was cancelled. Pyscho V1 is still running as a standard user.", "info");
        }
    }

    public static void ReportError(Exception ex)
    {
        try
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PyschoV1");
            Directory.CreateDirectory(dir);
            File.AppendAllText(Path.Combine(dir, "errors.log"),
                $"[{DateTime.Now:u}] {ex.GetType().Name}: {ex.Message}{Environment.NewLine}{ex.StackTrace}{Environment.NewLine}{Environment.NewLine}");
        }
        catch
        {
            // Logging must never mask the original failure.
        }
    }

    public static void ShowError(string title, string message)
    {
        MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}

/// <summary>Keeps the history view and the shell in sync without a message bus.</summary>
public sealed class JournalViewModelBridge
{
    public event EventHandler? Changed;
    public void Notify() => Changed?.Invoke(this, EventArgs.Empty);
}
