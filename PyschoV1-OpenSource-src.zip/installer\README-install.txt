Pyscho V1 Optimizer 1.0.0
=========================

Pyscho V1 is a local Windows performance and privacy utility by notThatanas.
It does not download anything, does not include telemetry, and does not bundle
third-party programs.

Requirements
------------
Windows 10 version 1809 or newer, or Windows 11, x64.
The application is self-contained; no .NET runtime installation is required.

Installing
----------
Run PyschoV1-Setup-1.0.0.exe and approve the Windows administrator
prompt. The setup installs for all users. For unattended deployment, run:

  PyschoV1-Setup-1.0.0.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART

First run
---------
Open Pyscho V1 from the Start menu or the desktop shortcut. The app starts as
your normal user so browsing, detection and plan previews work without a UAC
prompt.

Before applying system tweaks, click the "Standard user" chip in the title bar
and confirm the administrator prompt. The app relaunches elevated and can then
change services, system-wide policies and DNS settings.

What the setup installs
-----------------------
Program files:  C:\Program Files\Pyscho V1
Start menu:     Pyscho V1
Desktop:        Pyscho V1 (optional desktop icon)
Uninstaller:    Settings > Apps > Installed apps > Pyscho V1 Optimizer

The Apps page
------------
The Apps page installs common applications (browsers, editors, tools) through winget when it is
available on your PC, or downloads the publisher's own installer into Downloads\PyschoV1 and
starts it. Nothing is bundled with Pyscho V1: every file comes from Microsoft's package source or
the publisher directly.

Settings and history
--------------------
Settings:  %AppData%\PyschoV1\settings.json
Journal:   %ProgramData%\PyschoV1\journal

The setup gives normal users write access to the shared journal folder. This
keeps one undo history whether the app is running normally or elevated.

Uninstalling removes the program files, shortcuts and the uninstall entry. It
deliberately leaves settings and the change journal in place, so you can undo a
change later or reinstall without losing history. To remove them manually,
delete the two folders above after uninstalling.

Support
-------
Discord:    https://discord.gg/jVMShPrxa
Instagram:  https://www.instagram.com/yesthatanas

SmartScreen
-----------
This build may be unsigned. Windows may show "unknown publisher" or SmartScreen
may warn the first time. Choose More info > Run anyway. A build signed with a
trusted certificate shows notThatanas as the publisher. If antivirus blocks the
file, allow it and try again.

Unsupported
-----------
32-bit Windows and ARM-only Windows cannot run this x64 build.
