using System.IO;

namespace PyschoV1.App.Runtime;

/// <summary>
/// Writes a short breadcrumb trail before the main window exists. If a machine refuses to start
/// the app, this is the only evidence the user (or support) can read without a debugger.
/// </summary>
internal static class StartupTrace
{
    private static readonly object Gate = new();

    public static string LogPath { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "PyschoV1", "startup.log");

    public static void Write(string message)
    {
        try
        {
            lock (Gate)
            {
                var directory = Path.GetDirectoryName(LogPath);
                if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

                // Keep the file small forever; a stale launch record is not useful after a while.
                var file = new FileInfo(LogPath);
                if (file.Exists && file.Length > 96 * 1024)
                {
                    try { File.Copy(LogPath, LogPath + ".old", overwrite: true); } catch { /* best effort */ }
                    File.WriteAllText(LogPath, string.Empty);
                }

                File.AppendAllText(LogPath,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}");
            }
        }
        catch
        {
            // Diagnostics must never be the reason a launch fails.
        }
    }
}
