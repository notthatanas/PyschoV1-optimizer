using System.Windows.Controls;

namespace PyschoV1.App.Views;

public partial class DebloatView : UserControl
{
    public DebloatView() => InitializeComponent();
}
