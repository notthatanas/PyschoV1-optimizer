# Builds release\<version>\PyschoV1.exe and release\<version>\PyschoV1-Setup-<version>.exe.
#
#   powershell -ExecutionPolicy Bypass -File installer\build-installer.ps1
#
# The build publishes to a fresh staging folder, signs the app when a certificate is
# configured, starts a copy to prove it works, copies that verified app into the
# versioned release folder, compiles the setup, signs the setup, installs a copy
# silently, and only then publishes it. That ordering catches a corrupt single-file
# bundle and a corrupt payload before either can reach someone else.
#
#   -SkipPublish              use the existing release\<version>\PyschoV1.exe
#   -SkipInstallerTest        do not install/uninstall the built setup (needs no admin)
#   -SkipSigning              build unsigned even if a certificate is configured
#   -AllowUntrustedSignature  test the signing pipeline with a self-signed cert
#
# Signing is configured with CODESIGN_CERT_THUMBPRINT, or CODESIGN_PFX_PATH plus
# CODESIGN_PFX_PASSWORD. A publicly trusted certificate is the only way to make
# SmartScreen identify notThatanas on other people's PCs.
param(
    [switch] $SkipPublish,
    [switch] $SkipInstallerTest,
    [switch] $SkipSigning,
    [switch] $AllowUntrustedSignature,
    [string] $CertificateThumbprint = $env:CODESIGN_CERT_THUMBPRINT,
    [string] $PfxPath = $env:CODESIGN_PFX_PATH
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repoRoot = Split-Path $PSScriptRoot -Parent
$project = Join-Path $repoRoot 'src\PyschoV1.App\PyschoV1.App.csproj'
$script = Join-Path $PSScriptRoot 'PyschoV1.iss'
$testScript = Join-Path $PSScriptRoot 'test-installer.ps1'
$signScript = Join-Path $PSScriptRoot 'sign.ps1'
$releaseRoot = Join-Path $repoRoot 'release'
$publish = Join-Path $repoRoot 'artifacts\app-publish'
$stage = Join-Path $repoRoot 'artifacts\installer-output'

if ($CertificateThumbprint -and $PfxPath) {
    throw 'Pass either -CertificateThumbprint or -PfxPath, not both.'
}
$signingRequested = -not $SkipSigning -and ($CertificateThumbprint -or $PfxPath)
$signParams = @{}
if ($CertificateThumbprint) { $signParams.CertificateThumbprint = $CertificateThumbprint }
if ($PfxPath) { $signParams.PfxPath = $PfxPath }
if ($AllowUntrustedSignature) { $signParams.AllowUntrusted = $true }

if (-not (Test-Path -LiteralPath $project)) { throw "Missing project: $project" }

# Keep the installer version and the app version from drifting apart.
[xml] $projectXml = Get-Content -LiteralPath $project -Raw
$appVersion = [string] $projectXml.Project.PropertyGroup.Version
if ([string]::IsNullOrWhiteSpace($appVersion)) { throw 'The app csproj has no <Version>.' }
$issText = Get-Content -LiteralPath $script -Raw
if ($issText -notmatch '#define\s+AppVersion\s+"([^"]+)"') {
    throw 'Could not read #define AppVersion from PyschoV1.iss.'
}
$issVersion = $Matches[1]
if ($appVersion -ne $issVersion) {
    throw "Version mismatch: csproj is $appVersion but PyschoV1.iss is $issVersion."
}

# Keep each version in its own folder. Windows' file scanner can hold a setup open for
# a long time; a new version must never have to overwrite that file to be published.
$release = Join-Path $releaseRoot $issVersion
if (-not (Test-Path -LiteralPath $release)) { New-Item -ItemType Directory -Path $release | Out-Null }
$app = Join-Path $release 'PyschoV1.exe'
$releaseSetup = Join-Path $release "PyschoV1-Setup-$issVersion.exe"

$candidates = @()
if ($env:LOCALAPPDATA) { $candidates += (Join-Path $env:LOCALAPPDATA 'Programs\Inno Setup 6\ISCC.exe') }
if (${env:ProgramFiles(x86)}) { $candidates += (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe') }
if ($env:ProgramFiles) { $candidates += (Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe') }

$iscc = $candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $iscc) {
    throw 'Inno Setup 6 was not found. Install it with: winget install --id JRSoftware.InnoSetup -e --source winget'
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = ([Security.Principal.WindowsPrincipal] $identity).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $SkipInstallerTest -and -not $isAdmin) {
    throw 'The installer verification installs and uninstalls the app, so it needs an elevated shell. Run from an administrator PowerShell or pass -SkipInstallerTest.'
}

function Test-AppStarts {
    param([string] $AppPath)

    # A truncated or half-written single-file bundle exits before any managed code, so no
    # log explains it. Run a copy, not the file Inno Setup will read: starting an exe can
    # make a Windows scanner hold a handle on it while the compiler reads the payload.
    Write-Host "Verifying $AppPath starts ..."
    $probe = Join-Path ([System.IO.Path]::GetTempPath()) 'PyschoV1-installer-probe.txt'
    $probeDir = Join-Path ([System.IO.Path]::GetTempPath()) ('PyschoV1-probe-' + [guid]::NewGuid().ToString('N'))
    $probeExe = Join-Path $probeDir 'PyschoV1.exe'
    try {
        New-Item -ItemType Directory -Path $probeDir | Out-Null
        Copy-Item -LiteralPath $AppPath -Destination $probeExe
        if (Test-Path -LiteralPath $probe) { Remove-Item -LiteralPath $probe -Force }
        $probeProc = Start-Process -FilePath $probeExe -ArgumentList ('--benchmark "{0}"' -f $probe) -Wait -PassThru
        if (-not (Test-Path -LiteralPath $probe)) {
            throw "$AppPath did not start. Check %AppData%\PyschoV1\startup.log and republish."
        }
        $measurement = Get-Content -LiteralPath $probe -Raw
        if ($measurement -notmatch 'startup_ms=\d+') {
            throw "$AppPath started but produced no benchmark measurement."
        }
        if ($probeProc.ExitCode -ne 0) {
            throw "$AppPath exited with code $($probeProc.ExitCode)."
        }
        Write-Host ('Startup probe: ' + ($measurement.Trim() -replace "`r?`n", ', '))
    }
    finally {
        if (Test-Path -LiteralPath $probe) { Remove-Item -LiteralPath $probe -Force }
        if (Test-Path -LiteralPath $probeDir) { Remove-Item -LiteralPath $probeDir -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

if (-not $SkipPublish) {
    $running = @(Get-Process -Name 'PyschoV1' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        throw 'Pyscho V1 is running. Close it before building: Windows cannot replace a running exe.'
    }

    if (Test-Path -LiteralPath $publish) { Remove-Item -LiteralPath $publish -Recurse -Force }
    New-Item -ItemType Directory -Path $publish | Out-Null

    Write-Host 'Publishing PyschoV1.exe ...'
    & dotnet publish $project -c Release -r win-x64 --self-contained true `
        -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
        -p:EnableCompressionInSingleFile=true -p:DebugType=none -o $publish
    if ($LASTEXITCODE -ne 0) {
        throw "dotnet publish failed with exit code $LASTEXITCODE. If a file in obj\ is locked by a backup or scanner, close it, wait, or rebuild from a fresh source copy."
    }

    $stagedApp = Join-Path $publish 'PyschoV1.exe'
    if (-not (Test-Path -LiteralPath $stagedApp)) { throw "Publish did not create $stagedApp" }

    if ($signingRequested) {
        Write-Host 'Signing the application ...'
        & $signScript -Path $stagedApp @signParams
    }

    Test-AppStarts -AppPath $stagedApp

    if (Test-Path -LiteralPath $app) {
        Remove-Item -LiteralPath $app -Force -ErrorAction Stop
    }
    Copy-Item -LiteralPath $stagedApp -Destination $app
    Remove-Item -LiteralPath $publish -Recurse -Force -ErrorAction SilentlyContinue
}
else {
    if (-not (Test-Path -LiteralPath $app)) {
        throw "release\$issVersion\PyschoV1.exe is missing. Run without -SkipPublish to publish it."
    }

    if ($signingRequested) {
        Write-Host 'Signing the release application ...'
        & $signScript -Path $app @signParams
    }
    Test-AppStarts -AppPath $app
}

if (-not $signingRequested -and -not $SkipSigning) {
    Write-Warning 'No code-signing certificate configured; building unsigned. Set CODESIGN_CERT_THUMBPRINT or CODESIGN_PFX_PATH to sign. SmartScreen will keep showing Unknown publisher to other people until a trusted certificate is used.'
}

# Never compile over an existing setup. A scanner can hold the old file open, and the
# rewrite can leave a setup that reports success but contains a corrupt payload.
if (Test-Path -LiteralPath $releaseSetup) {
    $removed = $false
    for ($attempt = 0; $attempt -lt 5 -and -not $removed; $attempt++) {
        try {
            Remove-Item -LiteralPath $releaseSetup -Force -ErrorAction Stop
            $removed = $true
        }
        catch {
            Start-Sleep -Milliseconds 800
        }
    }
    if (-not $removed) {
        throw "Cannot replace $releaseSetup because another process (antivirus or Windows file scanner) has it open. Wait a moment or restart, then build again."
    }
}

if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null

Write-Host "Using $iscc"
& $iscc "/O$stage" $script
if ($LASTEXITCODE -ne 0) { throw "ISCC failed with exit code $LASTEXITCODE" }

$stageSetup = Join-Path $stage "PyschoV1-Setup-$issVersion.exe"
if (-not (Test-Path -LiteralPath $stageSetup)) { throw "ISCC finished but $stageSetup was not created." }

if ($signingRequested) {
    Write-Host 'Signing the setup ...'
    & $signScript -Path $stageSetup @signParams
}

if (-not $SkipInstallerTest) {
    Write-Host 'Verifying the built setup installs, launches and uninstalls ...'
    $verifySetup = Join-Path $stage 'verify-setup.exe'
    Copy-Item -LiteralPath $stageSetup -Destination $verifySetup
    & $testScript -SetupPath $verifySetup
    Remove-Item -LiteralPath $verifySetup -Force -ErrorAction SilentlyContinue
}

$stageHash = (Get-FileHash -LiteralPath $stageSetup -Algorithm SHA256).Hash
Copy-Item -LiteralPath $stageSetup -Destination $releaseSetup
$hash = (Get-FileHash -LiteralPath $releaseSetup -Algorithm SHA256).Hash
if ($hash -ne $stageHash) { throw 'The setup changed while being copied to release.' }

$size = [math]::Round((Get-Item -LiteralPath $releaseSetup).Length / 1MB, 1)
Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Portable app: $app"
Write-Host "Installer ready: $releaseSetup ($size MB)"
Write-Host "Signature: $(if ($signingRequested) { 'signed' } else { 'unsigned' })"
Write-Host "SHA256: $hash"
