using System.Collections.ObjectModel;
using System.Text.Json;
using System.Windows.Input;
using Microsoft.Win32;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Catalog;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.ViewModels;

public sealed class PresetCardViewModel : ObservableObject
{
    private int _active;
    private bool _busy;
    private string _note = "";

    public PresetCardViewModel(Preset preset, Action refresh)
    {
        Preset = preset;
        ApplyCommand = new AsyncRelayCommand(ApplyAsync, () => !_busy);
        RevertCommand = new AsyncRelayCommand(RevertAsync, () => !_busy);
        Refresh();
    }

    public Preset Preset { get; }
    public string Name => Preset.Name;
    public string Summary => Preset.Summary;
    public string Accent => Preset.Accent;
    public int Total => Preset.TweakIds.Count;

    public int Active
    {
        get => _active;
        private set
        {
            if (!Set(ref _active, value)) return;
            Raise(nameof(ActiveText));
            Raise(nameof(Ratio));
        }
    }

    public string ActiveText => Active == 0 ? "Not applied" : $"{Active} of {Total} active";
    public double Ratio => Total == 0 ? 0 : Active * 100.0 / Total;

    public string Note { get => _note; private set => Set(ref _note, value); }

    public AsyncRelayCommand ApplyCommand { get; }
    public AsyncRelayCommand RevertCommand { get; }

    public void Refresh()
    {
        Active = Preset.TweakIds
            .Select(TweakCatalog.Find)
            .Where(t => t is not null)
            .Count(t => AppServices.Engine.GetState(t!) == TweakState.On);
    }

    private async Task ApplyAsync()
    {
        _busy = true;
        ApplyCommand.RaiseCanExecuteChanged();
        try
        {
            var outcome = await PresetRunner.ApplyAsync(Preset);
            Note = outcome.Message;
            AppServices.Shell?.ShowToast(outcome.Message, outcome.Success ? "success" : "error");
        }
        finally
        {
            _busy = false;
            ApplyCommand.RaiseCanExecuteChanged();
            RevertCommand.RaiseCanExecuteChanged();
            Refresh();
        }
    }

    private async Task RevertAsync()
    {
        _busy = true;
        RevertCommand.RaiseCanExecuteChanged();
        try
        {
            var outcome = await PresetRunner.RevertAsync(Preset);
            Note = outcome.Message;
            AppServices.Shell?.ShowToast(outcome.Message, outcome.Success ? "info" : "error");
        }
        finally
        {
            _busy = false;
            ApplyCommand.RaiseCanExecuteChanged();
            RevertCommand.RaiseCanExecuteChanged();
            Refresh();
        }
    }
}

public sealed class ProfilesViewModel : ObservableObject
{
    private string _status = "";

    public ProfilesViewModel()
    {
        foreach (var preset in TweakCatalog.Presets) Cards.Add(new PresetCardViewModel(preset, RefreshAll));

        RefreshCommand = new RelayCommand(RefreshAll);
        ExportCommand = new RelayCommand(Export);
        ImportCommand = new AsyncRelayCommand(ImportAsync);
        RefreshAll();
    }

    public ObservableCollection<PresetCardViewModel> Cards { get; } = new();

    public ICommand RefreshCommand { get; }
    public ICommand ExportCommand { get; }
    public ICommand ImportCommand { get; }

    public string Status { get => _status; private set => Set(ref _status, value); }

    public string ActiveText
    {
        get
        {
            var active = TweakCatalog.All.Count(t => AppServices.Engine.GetState(t) == TweakState.On);
            return $"{active} of {TweakCatalog.All.Count} tweaks on this machine";
        }
    }

    public void RefreshAll()
    {
        foreach (var card in Cards) card.Refresh();
        Raise(nameof(ActiveText));
    }

    private void Export()
    {
        var active = TweakCatalog.All
            .Where(t => AppServices.Engine.GetState(t) == TweakState.On)
            .Select(t => t.Id)
            .ToList();

        if (active.Count == 0)
        {
            Status = "Nothing is applied yet, so there is no profile to export.";
            return;
        }

        var dialog = new SaveFileDialog
        {
            Title = "Export Pyscho V1 profile",
            Filter = "Pyscho V1 profile (*.json)|*.json",
            FileName = "pyscho-profile.json"
        };

        if (dialog.ShowDialog() != true) return;

        var payload = new { Product = "PyschoV1", Version = 1, Created = DateTimeOffset.Now, Tweaks = active };
        System.IO.File.WriteAllText(dialog.FileName,
            JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true }));

        Status = $"Exported {active.Count} tweaks.";
    }

    private async Task ImportAsync()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Import Pyscho V1 profile",
            Filter = "Pyscho V1 profile (*.json)|*.json|All files (*.*)|*.*"
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            using var doc = JsonDocument.Parse(System.IO.File.ReadAllText(dialog.FileName));
            if (!doc.RootElement.TryGetProperty("Tweaks", out var array))
            {
                Status = "That file does not contain a tweak list.";
                return;
            }

            var ids = array.EnumerateArray()
                .Select(e => e.GetString())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Select(s => s!)
                .ToList();

            var applied = await Task.Run(() =>
            {
                var count = 0;
                foreach (var id in ids)
                {
                    var tweak = TweakCatalog.Find(id);
                    if (tweak is null) continue;
                    if (!TweakEngine.SupportsPlatform(tweak, AppServices.WindowsBuild)) continue;
                    if (AppServices.Engine.GetState(tweak) == TweakState.On) continue;
                    if (AppServices.Engine.Apply(tweak, "profile:import").Success) count++;
                }
                return count;
            });

            AppServices.Journal.Notify();
            RefreshAll();
            Status = $"Imported {applied} of {ids.Count} tweaks.";
            AppServices.Shell?.ShowToast(Status, "success");
        }
        catch (Exception ex)
        {
            Status = $"Import failed: {ex.Message}";
        }
    }
}
