using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using PyschoV1.App.ViewModels;
using PyschoV1.App.Views;

namespace PyschoV1.App.Runtime;

/// <summary>
/// Renders each page offscreen into a PNG. Used during the build to verify layout without
/// opening a window on the user's desktop, and it proves the layout survives scaling.
/// </summary>
public static class PreviewRenderer
{
    private static readonly (string Key, string File)[] Pages =
    {
        ("dashboard", "01-dashboard.png"),
        ("performance", "02-performance.png"),
        ("privacy", "03-privacy.png"),
        ("debloat", "04-debloat.png"),
        ("startup", "05-startup.png"),
        ("cleaner", "06-cleaner.png"),
        ("network", "07-network.png"),
        ("apps", "08-apps.png"),
        ("profiles", "09-profiles.png"),
        ("history", "10-history.png"),
        ("settings", "11-settings.png")
    };

    public static string Render(string outputDirectory)
    {
        var dir = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(dir);

        var bindingErrors = BindingErrorListener.Attach();

        // The render pass navigates through every page and would otherwise persist "settings" as
        // the last page the user visited.
        var originalPage = AppServices.Settings.LastPage;

        var shell = new ShellViewModel();
        AppServices.Shell = shell;

        // The render always starts on the dashboard so the hardware sampler is created and can
        // produce values, regardless of which page the user last visited in the real app.
        shell.Navigate("dashboard");

        const double width = 1440;
        const double height = 900;

        // Let the deferred dashboard work and at least one hardware sample land, otherwise the
        // capture shows dashes and the visual check is worthless.
        var deadline = DateTime.UtcNow.AddSeconds(8);
        while (DateTime.UtcNow < deadline)
        {
            Dispatcher.CurrentDispatcher.Invoke(() => { }, DispatcherPriority.Background);
            // A single sample gives 0% and a blank sparkline. Wait for a short live series so
            // the dashboard capture actually looks like the running app.
            if (shell.CurrentPage is DashboardViewModel dash &&
                dash.HardeningText.Length > 0 && dash.CpuSeries.Count >= 6) break;
            Thread.Sleep(100);
        }

        foreach (var (key, file) in Pages)
        {
            shell.Navigate(key);
            shell.PaletteOpen = false;

            // The Apps page reads installed programs from the registry in the background; wait for
            // that detection so the capture shows real Installed badges instead of a loading state.
            if (key == "apps")
            {
                var detectionDeadline = DateTime.UtcNow.AddSeconds(6);
                while (DateTime.UtcNow < detectionDeadline)
                {
                    Dispatcher.CurrentDispatcher.Invoke(() => { }, DispatcherPriority.Background);
                    if (shell.CurrentPage is AppsViewModel apps && !apps.IsLoading) break;
                    Thread.Sleep(80);
                }
            }

            // Open one card so the plan preview is part of the visual check.
            if (key == "performance" && shell.CurrentPage is TweakModuleViewModel module &&
                module.Groups.Count > 0 && module.Groups[0].Items.Count > 0)
            {
                module.Groups[0].Items[0].IsExpanded = true;
            }

            var host = new Grid
            {
                Width = width,
                Height = height,
                Background = Application.Current.TryFindResource("WindowBackdrop") as Brush ?? Brushes.Black
            };

            if (Application.Current.TryFindResource("HeroGlow") is Brush glow)
            {
                host.Children.Add(new System.Windows.Shapes.Rectangle
                {
                    Fill = glow,
                    IsHitTestVisible = false
                });
            }

            var view = new ShellView { DataContext = shell };
            host.Children.Add(view);

            host.Measure(new Size(width, height));
            host.Arrange(new Rect(0, 0, width, height));
            host.UpdateLayout();

            Dispatcher.CurrentDispatcher.Invoke(() => { }, DispatcherPriority.Background);

            // Let the entrance and toggle animations finish so the PNG shows the settled UI.
            SettleMotion();

            var bitmap = new RenderTargetBitmap(
                (int)width, (int)height, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(host);

            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));

            using var stream = File.Create(Path.Combine(dir, file));
            encoder.Save(stream);
        }

        var report = bindingErrors.Messages;
        File.WriteAllLines(Path.Combine(dir, "binding-errors.txt"),
            report.Count == 0 ? new[] { "none" } : report);

        File.WriteAllLines(Path.Combine(dir, "ui-check.txt"), UiSelfCheck());

        AppServices.Settings.LastPage = originalPage;
        AppServices.Settings.Save();

        return dir;
    }

    private static void SettleMotion()
    {
        if (!Motion.Enabled) return;

        var deadline = DateTime.UtcNow.AddMilliseconds(420);
        while (DateTime.UtcNow < deadline)
        {
            Dispatcher.CurrentDispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
            Thread.Sleep(30);
        }
    }

    /// <summary>
    /// Exercises the real view-model path (toggle card -> engine) in preview mode, so nothing is
    /// written, and confirms the dry-run branch reports a plan instead of mutating the machine.
    /// </summary>
    private static IEnumerable<string> UiSelfCheck()
    {
        var lines = new List<string>();
        var originalDryRun = AppServices.Settings.DryRun;

        try
        {
            AppServices.Settings.DryRun = true;
            var journalBefore = AppServices.Engine.Journal.ReadAll().Count;

            var module = new TweakModuleViewModel(
                Core.Tweaks.TweakModule.Performance, "Performance", string.Empty);

            // An already-applied tweak cannot change state, so pick one that is genuinely off.
            var item = module.Groups.SelectMany(g => g.Items).First(i => !i.IsOn);

            item.IsOn = true;

            lines.Add($"toggle_handled={item.Note is not null}");
            lines.Add($"note={item.Note}");
            lines.Add($"still_off={!item.IsOn}");
            lines.Add($"journal_unchanged={AppServices.Engine.Journal.ReadAll().Count == journalBefore}");
            lines.Add($"state_label={item.StateLabel}");
        }
        catch (Exception ex)
        {
            lines.Add("error=" + ex.Message);
        }
        finally
        {
            AppServices.Settings.DryRun = originalDryRun;
        }

        return lines;
    }
}
