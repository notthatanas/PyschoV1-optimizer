using System.Windows.Controls;

namespace PyschoV1.App.Views;

public partial class DashboardView : UserControl
{
    public DashboardView() => InitializeComponent();
}
