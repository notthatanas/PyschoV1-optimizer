using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace PyschoV1.Core.SysInfo;

public sealed record SystemSpecs(
    string CpuName,
    int CpuCores,
    int CpuThreads,
    string GpuName,
    double TotalRamGb,
    string OsName,
    string OsBuild,
    string MachineName);

public sealed record HardwareSample(
    double CpuPercent,
    double RamPercent,
    double RamUsedGb,
    double RamTotalGb,
    double DiskBusyPercent,
    double NetworkMbps,
    double UptimeHours)
{
    public static readonly HardwareSample Empty = new(0, 0, 0, 0, 0, 0, 0);
}

public sealed record DriveSample(string Name, string Label, double TotalGb, double FreeGb)
{
    public double UsedPercent => TotalGb <= 0 ? 0 : (TotalGb - FreeGb) / TotalGb * 100.0;
}

/// <summary>
/// Live telemetry with no WMI, no NuGet packages and no polling on the caller's thread.
/// CPU comes from GetSystemTimes deltas, memory from GlobalMemoryStatusEx, disk from the
/// physical disk performance counters, network from the interface byte counters.
/// </summary>
public sealed class HardwareMonitor : IDisposable
{
    private readonly Timer _timer;
    private ulong _prevIdle, _prevKernel, _prevUser;
    private long _prevNetIn, _prevNetOut;
    private readonly Stopwatch _netClock = Stopwatch.StartNew();
    private bool _primed;

    public HardwareSample Latest { get; private set; } = HardwareSample.Empty;
    public event EventHandler<HardwareSample>? Sampled;

    public HardwareMonitor(TimeSpan? interval = null)
    {
        _timer = new Timer(_ => SafeSample(), null, Timeout.Infinite, Timeout.Infinite);
        Interval = interval ?? TimeSpan.FromSeconds(1);
    }

    public TimeSpan Interval { get; }

    public void Start() => _timer.Change(0, (int)Interval.TotalMilliseconds);

    public void Stop() => _timer.Change(Timeout.Infinite, Timeout.Infinite);

    private void SafeSample()
    {
        try
        {
            var sample = Sample();
            Latest = sample;
            Sampled?.Invoke(this, sample);
        }
        catch
        {
            // Sampling must never take the app down; the UI simply keeps the last value.
        }
    }

    public HardwareSample Sample()
    {
        var cpu = ReadCpuPercent();
        var (usedGb, totalGb) = ReadMemory();
        var disk = ReadDiskPercent();
        var net = ReadNetworkMbps();
        _primed = true;

        return new HardwareSample(
            Math.Round(cpu, 1),
            totalGb <= 0 ? 0 : Math.Round(usedGb / totalGb * 100.0, 1),
            Math.Round(usedGb, 2),
            Math.Round(totalGb, 2),
            Math.Round(disk, 1),
            Math.Round(net, 2),
            Math.Round(Environment.TickCount64 / 3_600_000.0, 2));
    }

    private double ReadCpuPercent()
    {
        if (!GetSystemTimes(out var idle, out var kernel, out var user)) return Latest.CpuPercent;
        var i = ToUInt64(idle);
        var k = ToUInt64(kernel);
        var u = ToUInt64(user);

        if (!_primed)
        {
            _prevIdle = i; _prevKernel = k; _prevUser = u;
            return 0;
        }

        var idleDelta = i - _prevIdle;
        var totalDelta = (k - _prevKernel) + (u - _prevUser);
        _prevIdle = i; _prevKernel = k; _prevUser = u;

        if (totalDelta == 0) return Latest.CpuPercent;
        var busy = 100.0 * (totalDelta - idleDelta) / totalDelta;
        return Math.Clamp(busy, 0, 100);
    }

    private static ulong ToUInt64(FileTime ft) => ((ulong)ft.High << 32) | ft.Low;

    private static (double usedGb, double totalGb) ReadMemory()
    {
        var status = new MemoryStatusEx();
        if (!GlobalMemoryStatusEx(status)) return (0, 0);
        const double gb = 1024.0 * 1024.0 * 1024.0;
        return ((status.TotalPhysical - status.AvailablePhysical) / gb, status.TotalPhysical / gb);
    }

    private IntPtr _pdhQuery;
    private IntPtr _pdhDiskCounter;

    /// <summary>
    /// Disk activity straight from PDH. English counter names are used so the value is correct on
    /// localised Windows installs, and the query is opened once instead of per sample.
    /// </summary>
    private double ReadDiskPercent()
    {
        try
        {
            if (_pdhQuery == IntPtr.Zero)
            {
                if (PdhOpenQueryW(null, IntPtr.Zero, out _pdhQuery) != 0) return 0;
                if (PdhAddEnglishCounterW(_pdhQuery, @"\PhysicalDisk(_Total)\% Disk Time", IntPtr.Zero, out _pdhDiskCounter) != 0)
                {
                    PdhCloseQuery(_pdhQuery);
                    _pdhQuery = IntPtr.Zero;
                    return 0;
                }
                PdhCollectQueryData(_pdhQuery);
                return 0;
            }

            if (PdhCollectQueryData(_pdhQuery) != 0) return Latest.DiskBusyPercent;
            if (PdhGetFormattedCounterValue(_pdhDiskCounter, PdhFmtDouble, out _, out var value) != 0)
                return Latest.DiskBusyPercent;

            return Math.Clamp(value.DoubleValue, 0, 100);
        }
        catch
        {
            return Latest.DiskBusyPercent;
        }
    }

    private double ReadNetworkMbps()
    {
        long bytes = 0;
        try
        {
            foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != OperationalStatus.Up) continue;
                if (nic.NetworkInterfaceType is NetworkInterfaceType.Loopback or NetworkInterfaceType.Tunnel) continue;
                try
                {
                    var stats = nic.GetIPv4Statistics();
                    bytes += stats.BytesReceived + stats.BytesSent;
                }
                catch
                {
                    // Interface disappeared mid-enumeration.
                }
            }
        }
        catch
        {
            return 0;
        }

        var elapsed = _netClock.Elapsed.TotalSeconds;
        _netClock.Restart();
        var delta = bytes - _prevNetIn - _prevNetOut;
        _prevNetIn = bytes;
        _prevNetOut = 0;

        if (!_primed || elapsed <= 0.1 || delta < 0) return 0;
        return delta * 8.0 / 1_000_000.0 / elapsed;
    }

    public static SystemSpecs ReadSpecs()
    {
        var cpu = ReadRegistryString(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString")
                  ?? "Unknown CPU";
        var gpu = ReadGpuName();
        var (_, ramGb) = ReadMemory();

        return new SystemSpecs(
            cpu.Trim(),
            Environment.ProcessorCount,
            Environment.ProcessorCount,
            gpu,
            Math.Round(ramGb, 1),
            ReadOsName(),
            Environment.OSVersion.Version.Build.ToString(),
            Environment.MachineName);
    }

    public static IReadOnlyList<DriveSample> ReadDrives()
    {
        var list = new List<DriveSample>();
        foreach (var drive in DriveInfo.GetDrives())
        {
            try
            {
                if (!drive.IsReady || drive.DriveType is not (DriveType.Fixed or DriveType.Removable)) continue;
                list.Add(new DriveSample(
                    drive.Name,
                    string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Local disk" : drive.VolumeLabel,
                    Math.Round(drive.TotalSize / 1073741824.0, 1),
                    Math.Round(drive.AvailableFreeSpace / 1073741824.0, 1)));
            }
            catch
            {
                // A drive can vanish between enumeration and read.
            }
        }
        return list;
    }

    private static string ReadGpuName()
    {
        const string classKey = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}";
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(classKey);
            if (key is null) return "Unknown GPU";
            foreach (var sub in key.GetSubKeyNames().Where(n => n.All(char.IsDigit)).OrderBy(n => n))
            {
                using var adapter = key.OpenSubKey(sub);
                var name = adapter?.GetValue("DriverDesc") as string;
                if (!string.IsNullOrWhiteSpace(name)) return name!;
            }
        }
        catch
        {
            // Fall through to the generic label.
        }
        return "Unknown GPU";
    }

    private static string? ReadRegistryString(string path, string name)
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(path);
            return key?.GetValue(name) as string;
        }
        catch
        {
            return null;
        }
    }

    private static string ReadOsName()
    {
        var build = Environment.OSVersion.Version.Build;
        var product = ReadRegistryString(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "ProductName") ?? "Windows";
        var display = ReadRegistryString(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "DisplayVersion");
        var name = build >= 22000 ? product.Replace("Windows 10", "Windows 11") : product;
        return string.IsNullOrWhiteSpace(display) ? name : $"{name} {display}";
    }

    public void Dispose()
    {
        _timer.Dispose();
        if (_pdhQuery != IntPtr.Zero)
        {
            PdhCloseQuery(_pdhQuery);
            _pdhQuery = IntPtr.Zero;
        }
    }

    // ---- native ----

    [StructLayout(LayoutKind.Sequential)]
    private struct FileTime
    {
        public uint Low;
        public uint High;
    }

    [StructLayout(LayoutKind.Sequential)]
    private sealed class MemoryStatusEx
    {
        public uint Length = (uint)Marshal.SizeOf(typeof(MemoryStatusEx));
        public uint MemoryLoad;
        public ulong TotalPhysical;
        public ulong AvailablePhysical;
        public ulong TotalPageFile;
        public ulong AvailablePageFile;
        public ulong TotalVirtual;
        public ulong AvailableVirtual;
        public ulong AvailableExtendedVirtual;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct PdhFmtCounterValue
    {
        [FieldOffset(0)] public uint Status;
        [FieldOffset(8)] public double DoubleValue;
    }

    private const uint PdhFmtDouble = 0x0000_0200;

    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhOpenQueryW(string? dataSource, IntPtr userData, out IntPtr query);

    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhAddEnglishCounterW(IntPtr query, string path, IntPtr userData, out IntPtr counter);

    [DllImport("pdh.dll")]
    private static extern uint PdhCollectQueryData(IntPtr query);

    [DllImport("pdh.dll")]
    private static extern uint PdhGetFormattedCounterValue(IntPtr counter, uint format, out uint type, out PdhFmtCounterValue value);

    [DllImport("pdh.dll")]
    private static extern uint PdhCloseQuery(IntPtr query);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetSystemTimes(out FileTime idle, out FileTime kernel, out FileTime user);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MemoryStatusEx buffer);
}
