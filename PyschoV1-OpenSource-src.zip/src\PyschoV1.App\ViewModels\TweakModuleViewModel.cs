using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Threading;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Catalog;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.ViewModels;

public sealed class TweakModuleViewModel : ObservableObject
{
    private static readonly string[] PerformanceOrder =
    {
        "Power", "Gaming", "Graphics", "Explorer", "Boot", "System", "Browsers", "Services"
    };

    private static readonly string[] PrivacyOrder =
    {
        "Telemetry", "Assistant", "Search", "Sensors", "Security", "Content", "Browsers", "Office",
        "Services", "System"
    };

    private readonly Dictionary<string, TweakItemViewModel> _items = new();
    private readonly DispatcherTimer _filterTimer = new() { Interval = TimeSpan.FromMilliseconds(140) };
    private string _query = "";
    private string _filter = "All";
    private int _applied;
    private TweakItemViewModel? _highlight;

    public TweakModuleViewModel(TweakModule module, string title, string subtitle)
    {
        Module = module;
        Title = title;
        Subtitle = subtitle;

        _filterTimer.Tick += (_, _) =>
        {
            _filterTimer.Stop();
            Rebuild();
        };

        // Read the journal once for the whole page instead of once per card.
        var managed = ReadManaged();
        foreach (var tweak in TweakCatalog.ForModule(module))
        {
            if (!TweakEngine.SupportsPlatform(tweak, AppServices.WindowsBuild)) continue;
            _items[tweak.Id] = new TweakItemViewModel(tweak, managed);
        }

        SetFilterCommand = new RelayCommand<string>(filter => Filter = filter ?? "All");
        RefreshCommand = new RelayCommand(Refresh);

        Rebuild();
    }

    public TweakModule Module { get; }
    public string Title { get; }
    public string Subtitle { get; }

    public ObservableCollection<TweakGroup> Groups { get; } = new();

    public ICommand SetFilterCommand { get; }
    public ICommand RefreshCommand { get; }

    public string SearchQuery
    {
        get => _query;
        set
        {
            if (!Set(ref _query, value)) return;

            // Rebuilding a page of cards on every key press is wasted work; settle first.
            _filterTimer.Stop();
            _filterTimer.Start();
        }
    }

    public string Filter
    {
        get => _filter;
        private set
        {
            if (!Set(ref _filter, value)) return;
            Raise(nameof(IsAll)); Raise(nameof(IsSafe)); Raise(nameof(IsCaution)); Raise(nameof(IsAdvanced));
            Rebuild();
        }
    }

    public bool IsAll => _filter == "All";
    public bool IsSafe => _filter == "Safe";
    public bool IsCaution => _filter == "Caution";
    public bool IsAdvanced => _filter == "Advanced";

    public int Applied
    {
        get => _applied;
        private set
        {
            if (!Set(ref _applied, value)) return;
            Raise(nameof(AppliedText));
            Raise(nameof(AppliedRatio));
        }
    }

    public int Total => _items.Count;
    public string AppliedText => $"{Applied} of {Total} on this PC";
    public string AppliedHint =>
        "Read directly from Windows. 'On this PC' was already enabled before Pyscho V1; 'Applied' was changed here and can be undone. Nothing is assumed from a saved profile.";
    public double AppliedRatio => Total == 0 ? 0 : Applied * 100.0 / Total;

    public TweakItemViewModel? Highlight
    {
        get => _highlight;
        private set => Set(ref _highlight, value);
    }

    public bool IsEmpty => Groups.Count == 0;

    public void Refresh()
    {
        var managed = ReadManaged();
        foreach (var item in _items.Values) item.Refresh(managed);
        Applied = _items.Values.Count(i => i.IsOn);
        Raise(nameof(IsEmpty));
    }

    public void Rebuild()
    {
        _filterTimer.Stop();
        var query = _query.Trim();
        var matching = _items.Values
            .Where(i => MatchesFilter(i))
            .Where(i => query.Length == 0 ||
                        i.Title.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                        i.Summary.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                        i.Category.Contains(query, StringComparison.OrdinalIgnoreCase))
            .ToList();

        Groups.Clear();
        var order = Module == TweakModule.Performance ? PerformanceOrder : PrivacyOrder;
        var grouped = matching
            .GroupBy(i => i.Category)
            .OrderBy(g => Array.IndexOf(order, g.Key) is var index && index < 0 ? 99 : index)
            .ThenBy(g => g.Key);

        foreach (var group in grouped)
            Groups.Add(new TweakGroup(group.Key, group));

        Applied = _items.Values.Count(i => i.IsOn);
        Raise(nameof(IsEmpty));
    }

    private bool MatchesFilter(TweakItemViewModel item) => _filter switch
    {
        "Safe" => item.Risk == RiskLevel.Safe,
        "Caution" => item.Risk == RiskLevel.Caution,
        "Advanced" => item.Risk == RiskLevel.Advanced,
        _ => true
    };

    private static HashSet<string> ReadManaged() =>
        AppServices.Engine.Journal.ReadAll()
            .Where(entry => !entry.Reverted)
            .Select(entry => entry.TweakId)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

    /// <summary>Used by the command palette: clears filters and opens the matching card.</summary>
    public void FocusTweak(string id)
    {
        if (!_items.TryGetValue(id, out var item)) return;
        SearchQuery = "";
        Filter = "All";

        if (!Groups.Any(g => g.Items.Contains(item))) Rebuild();

        item.IsExpanded = true;
        Highlight = item;
    }
}
