using System.Runtime.InteropServices;

namespace PyschoV1.Core.Modules;

public sealed record CleanTarget(
    string Id,
    string Name,
    string Description,
    IReadOnlyList<string> Paths,
    bool IsRecycleBin = false,
    string? FileFilter = null);

public sealed record CleanScanResult(
    CleanTarget Target,
    long Bytes,
    int Files,
    bool Accessible);

public sealed record CleanReport(
    long BytesFreed,
    int FilesRemoved,
    int Locked,
    IReadOnlyList<string> Failures);

/// <summary>
/// Deletes only files inside explicitly whitelisted folders, never the folders themselves,
/// and never anything outside the profiles and Windows temp trees.
/// </summary>
public sealed class CleanerService
{
    private static readonly string LocalAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
    private static readonly string RoamingAppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
    private static readonly string WindowsDir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
    private static readonly string SystemDrive = Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\";

    public IReadOnlyList<CleanTarget> Targets { get; } = BuildTargets();

    private static List<CleanTarget> BuildTargets()
    {
        var list = new List<CleanTarget>
        {
            new("temp.user", "User temp files",
                "Leftovers from installers and apps in your own profile.",
                new[] { Path.Combine(Path.GetTempPath()) }),
            new("temp.windows", "Windows temp files",
                "System-wide scratch files. In-use files are skipped.",
                new[] { Path.Combine(WindowsDir, "Temp") }),
            new("update.download", "Windows Update cache",
                "Already-installed update payloads.",
                new[] { Path.Combine(WindowsDir, "SoftwareDistribution", "Download") }),
            new("prefetch", "Prefetch data",
                "Boot and app prefetch traces. Windows rebuilds them.",
                new[] { Path.Combine(WindowsDir, "Prefetch") }),
            new("delivery", "Delivery Optimization cache",
                "Cached update and Store content shared with other PCs.",
                new[] { Path.Combine(WindowsDir, "ServiceProfiles", "NetworkService", "AppData", "Local",
                    "Microsoft", "Windows", "DeliveryOptimization", "Cache") }),
            new("thumbnails", "Thumbnail cache",
                "Explorer thumbnail database. Regenerated on demand.",
                new[] { Path.Combine(LocalAppData, "Microsoft", "Windows", "Explorer") },
                FileFilter: "thumbcache_*.db"),
            new("browser.edge", "Edge cache",
                "Browsing cache only — history, logins and cookies are untouched.",
                new[]
                {
                    Path.Combine(LocalAppData, "Microsoft", "Edge", "User Data", "Default", "Cache"),
                    Path.Combine(LocalAppData, "Microsoft", "Edge", "User Data", "Default", "Code Cache")
                }),
            new("browser.chrome", "Chrome cache",
                "Browsing cache only — history, logins and cookies are untouched.",
                new[]
                {
                    Path.Combine(LocalAppData, "Google", "Chrome", "User Data", "Default", "Cache"),
                    Path.Combine(LocalAppData, "Google", "Chrome", "User Data", "Default", "Code Cache")
                }),
            new("browser.firefox", "Firefox cache",
                "Cache2 folders across your Firefox profiles.",
                FirefoxCaches()),
            new("crashdumps", "Crash dumps",
                "Memory dumps written by crashed applications.",
                new[]
                {
                    Path.Combine(LocalAppData, "CrashDumps"),
                    Path.Combine(RoamingAppData, "Microsoft", "Windows", "WER")
                }),
            new("recyclebin", "Recycle Bin",
                "Permanently empties the Recycle Bin for all drives.",
                Array.Empty<string>(), IsRecycleBin: true)
        };

        return list;
    }

    private static string[] FirefoxCaches()
    {
        try
        {
            var profiles = Path.Combine(RoamingAppData, "Mozilla", "Firefox", "Profiles");
            if (!Directory.Exists(profiles)) return Array.Empty<string>();
            return Directory.GetDirectories(profiles)
                .Select(p => Path.Combine(p, "cache2"))
                .Where(Directory.Exists)
                .ToArray();
        }
        catch
        {
            return Array.Empty<string>();
        }
    }

    public CleanScanResult Scan(CleanTarget target)
    {
        if (target.IsRecycleBin)
        {
            // The shell does not expose a cheap size query; report the bin as available.
            return new CleanScanResult(target, 0, 0, true);
        }

        long bytes = 0;
        var files = 0;
        var accessible = false;

        foreach (var path in target.Paths)
        {
            if (!IsSafePath(path)) continue;
            if (!Directory.Exists(path)) continue;
            accessible = true;

            try
            {
                var enumeration = target.FileFilter is null
                    ? Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories)
                    : Directory.EnumerateFiles(path, target.FileFilter, SearchOption.TopDirectoryOnly);

                foreach (var file in enumeration)
                {
                    try
                    {
                        bytes += new FileInfo(file).Length;
                        files++;
                    }
                    catch
                    {
                        // Skip files that disappear mid-scan.
                    }
                }
            }
            catch
            {
                // A locked subtree should not fail the whole target.
            }
        }

        return new CleanScanResult(target, bytes, files, accessible);
    }

    public CleanReport Clean(IEnumerable<CleanTarget> targets)
    {
        long freed = 0;
        var removed = 0;
        var locked = 0;
        var failures = new List<string>();

        foreach (var target in targets)
        {
            if (target.IsRecycleBin)
            {
                if (EmptyRecycleBin(out var message))
                {
                    freed += 0;
                }
                else if (message is not null)
                {
                    failures.Add(message);
                }
                continue;
            }

            foreach (var path in target.Paths)
            {
                if (!IsSafePath(path) || !Directory.Exists(path)) continue;

                IEnumerable<string> files;
                try
                {
                    files = target.FileFilter is null
                        ? Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories).ToList()
                        : Directory.EnumerateFiles(path, target.FileFilter, SearchOption.TopDirectoryOnly).ToList();
                }
                catch (Exception ex)
                {
                    failures.Add($"{target.Name}: {ex.Message}");
                    continue;
                }

                foreach (var file in files)
                {
                    try
                    {
                        var size = new FileInfo(file).Length;
                        File.SetAttributes(file, FileAttributes.Normal);
                        File.Delete(file);
                        freed += size;
                        removed++;
                    }
                    catch (UnauthorizedAccessException)
                    {
                        locked++;
                    }
                    catch (IOException)
                    {
                        locked++;
                    }
                    catch (Exception ex)
                    {
                        failures.Add($"{Path.GetFileName(file)}: {ex.Message}");
                    }
                }
            }
        }

        return new CleanReport(freed, removed, locked, failures.Take(20).ToList());
    }

    /// <summary>
    /// Hard guard: only paths inside the user profile, Windows, or ProgramData are ever deleted from,
    /// and never a drive root or a top-level system folder.
    /// </summary>
    public static bool IsSafePath(string path)
    {
        try
        {
            var full = Path.GetFullPath(path);
            if (!Path.IsPathRooted(full)) return false;

            var roots = new[]
            {
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                WindowsDir,
                Path.Combine(SystemDrive, "ProgramData")
            };

            if (Path.GetPathRoot(full)?.Equals(full, StringComparison.OrdinalIgnoreCase) == true) return false;

            return roots.Any(root =>
            {
                if (string.IsNullOrEmpty(root)) return false;

                // Require a directory separator after the root, otherwise C:\Users\Bob2 would
                // pass a guard for C:\Users\Bob. The root itself is never a valid target.
                var normalizedRoot = Path.GetFullPath(root)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                    + Path.DirectorySeparatorChar;

                return full.Length > normalizedRoot.Length &&
                       full.StartsWith(normalizedRoot, StringComparison.OrdinalIgnoreCase);
            });
        }
        catch
        {
            return false;
        }
    }

    private static bool EmptyRecycleBin(out string? error)
    {
        error = null;
        try
        {
            const uint noConfirmation = 0x00000001;
            const uint noProgress = 0x00000002;
            const uint noSound = 0x00000004;
            var result = SHEmptyRecycleBin(IntPtr.Zero, null, noConfirmation | noProgress | noSound);
            if (result != 0 && result != 0x8000FFFF)
            {
                error = "The Recycle Bin could not be emptied.";
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
    private static extern uint SHEmptyRecycleBin(IntPtr hwnd, string? rootPath, uint flags);

    public static string FormatBytes(long bytes)
    {
        string[] units = { "B", "KB", "MB", "GB" };
        double value = bytes;
        var unit = 0;
        while (value >= 1024 && unit < units.Length - 1)
        {
            value /= 1024;
            unit++;
        }
        return $"{value:0.#} {units[unit]}";
    }
}
