using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Catalog;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.ViewModels;

public sealed class ShellViewModel : ObservableObject
{
    private readonly Dictionary<string, Func<object>> _factories = new();
    private readonly Dictionary<string, object> _cache = new();
    private readonly DispatcherTimer _toastTimer;

    private object? _currentPage;
    private NavItemViewModel? _selectedNav;
    private string _currentTitle = "";
    private string _currentSubtitle = "";
    private bool _paletteOpen;
    private string _paletteQuery = "";
    private PaletteResult? _paletteSelection;
    private string _toastMessage = "";
    private bool _toastVisible;
    private string _toastKind = "info";

    public ShellViewModel()
    {
        _toastTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(4.5) };
        _toastTimer.Tick += (_, _) =>
        {
            _toastTimer.Stop();
            ToastVisible = false;
        };

        Register("dashboard", "Dashboard", "IcoHome", "Live system state", () => new DashboardViewModel());
        Register("performance", "Performance", "IcoSpeed", "Speed and responsiveness", () =>
            new TweakModuleViewModel(TweakModule.Performance, "Performance",
                "Latency, clocks and background load. Every change is reversible."));
        Register("privacy", "Privacy", "IcoShield", "Telemetry and tracking", () =>
            new TweakModuleViewModel(TweakModule.Privacy, "Privacy & security",
                "Close the telemetry, assistant and suggestion paths."));
        Register("debloat", "Debloat", "IcoGrid", "Preinstalled apps", () => new DebloatViewModel());
        Register("startup", "Startup", "IcoRocket", "Boot load", () => new StartupViewModel());
        Register("cleaner", "Cleaner", "IcoBroom", "Disk cleanup", () => new CleanerViewModel());
        Register("network", "Network", "IcoGlobe", "DNS and latency", () => new NetworkViewModel());
        Register("apps", "Apps", "IcoBox", "Common apps, straight from their publishers", () =>
            new AppsViewModel());

        Nav = new ObservableCollection<NavItemViewModel>
        {
            Make("dashboard", "Dashboard", "IcoHome", "Live system state"),
            Make("performance", "Performance", "IcoSpeed", "Speed and responsiveness"),
            Make("privacy", "Privacy", "IcoShield", "Telemetry and tracking"),
            Make("debloat", "Debloat", "IcoGrid", "Preinstalled apps"),
            Make("startup", "Startup", "IcoRocket", "Boot load"),
            Make("cleaner", "Cleaner", "IcoBroom", "Disk cleanup"),
            Make("network", "Network", "IcoGlobe", "DNS and latency"),
            Make("apps", "Apps", "IcoBox", "Common apps download"),
            Make("profiles", "Profiles", "IcoSliders", "Presets and custom profiles")
        };

        Footer = new ObservableCollection<NavItemViewModel>
        {
            Make("history", "Change history", "IcoUndo", "Everything you have applied"),
            Make("settings", "Settings", "IcoGear", "App behaviour")
        };

        Register("history", "Change history", "IcoUndo", "", () => new HistoryViewModel());
        Register("profiles", "Profiles", "IcoSliders", "Presets and custom profiles", () => new ProfilesViewModel());
        Register("settings", "Settings", "IcoGear", "", () => new SettingsViewModel());

        NavigateCommand = new RelayCommand<string>(key => Navigate(key ?? "dashboard"));
        OpenPaletteCommand = new RelayCommand(() => OpenPalette());
        ClosePaletteCommand = new RelayCommand(() => PaletteOpen = false);
        ElevateCommand = new RelayCommand(AppServices.RequestElevation);
        OpenHistoryCommand = new RelayCommand(() => Navigate("history"));
        PaletteAcceptCommand = new RelayCommand(AcceptPalette);

        AppServices.Journal.Changed += (_, _) =>
        {
            Raise(nameof(ChangeCount));
            Raise(nameof(ChangeSummary));
        };

        // Reopen where the user left off, so the tool does not always snap back to the dashboard.
        var start = _factories.ContainsKey(AppServices.Settings.LastPage)
            ? AppServices.Settings.LastPage
            : "dashboard";
        Navigate(start);
    }

    public ObservableCollection<NavItemViewModel> Nav { get; }
    public ObservableCollection<NavItemViewModel> Footer { get; }

    public ICommand NavigateCommand { get; }
    public ICommand OpenPaletteCommand { get; }
    public ICommand ClosePaletteCommand { get; }
    public ICommand ElevateCommand { get; }
    public ICommand OpenHistoryCommand { get; }
    public ICommand PaletteAcceptCommand { get; }

    private void Register(string key, string title, string icon, string subtitle, Func<object> factory)
    {
        _factories[key] = factory;
        _titles[key] = (title, subtitle);
    }

    private readonly Dictionary<string, (string Title, string Subtitle)> _titles = new();

    private NavItemViewModel Make(string key, string label, string icon, string description) =>
        new(key, label, icon, description);

    public object? CurrentPage
    {
        get => _currentPage;
        private set => Set(ref _currentPage, value);
    }

    public string CurrentTitle
    {
        get => _currentTitle;
        private set => Set(ref _currentTitle, value);
    }

    public string CurrentSubtitle
    {
        get => _currentSubtitle;
        private set => Set(ref _currentSubtitle, value);
    }

    public bool IsElevated => AppServices.IsElevated;

    public string ElevationText => AppServices.IsElevated
        ? "Administrator"
        : "Standard user";

    public string ElevationHint => AppServices.IsElevated
        ? "System writes are available."
        : "Click to run as administrator — needed to change system settings.";

    public int ChangeCount => AppServices.Engine.Journal.ReadAll().Count(e => !e.Reverted);

    public string ChangeSummary => ChangeCount == 0 ? "No changes yet" : $"{ChangeCount} active change{(ChangeCount == 1 ? "" : "s")}";

    public bool ToastVisible
    {
        get => _toastVisible;
        private set => Set(ref _toastVisible, value);
    }

    public string ToastMessage
    {
        get => _toastMessage;
        private set => Set(ref _toastMessage, value);
    }

    public string ToastKind
    {
        get => _toastKind;
        private set => Set(ref _toastKind, value);
    }

    public bool PaletteOpen
    {
        get => _paletteOpen;
        set
        {
            if (!Set(ref _paletteOpen, value)) return;
            if (!value)
            {
                PaletteQuery = "";
                PaletteResults.Clear();
            }
        }
    }

    public string PaletteQuery
    {
        get => _paletteQuery;
        set
        {
            if (!Set(ref _paletteQuery, value)) return;
            RefreshPalette();
        }
    }

    public ObservableCollection<PaletteResult> PaletteResults { get; } = new();

    public PaletteResult? PaletteSelection
    {
        get => _paletteSelection;
        set => Set(ref _paletteSelection, value);
    }

    public void Navigate(string key)
    {
        if (!_factories.ContainsKey(key)) return;

        if (!_cache.TryGetValue(key, out var page))
        {
            page = _factories[key]();
            _cache[key] = page;
        }

        CurrentPage = page;
        _titles.TryGetValue(key, out var meta);
        CurrentTitle = meta.Title ?? key;
        CurrentSubtitle = meta.Subtitle ?? "";

        foreach (var item in Nav.Concat(Footer))
            item.IsSelected = item.Key == key;

        SelectedNav = Nav.Concat(Footer).FirstOrDefault(i => i.Key == key);
        PaletteOpen = false;

        if (AppServices.Settings.LastPage != key)
        {
            AppServices.Settings.LastPage = key;
            AppServices.Settings.Save();
        }
    }

    public NavItemViewModel? SelectedNav
    {
        get => _selectedNav;
        private set => Set(ref _selectedNav, value);
    }

    public void OpenPalette()
    {
        PaletteOpen = true;
        RefreshPalette();
    }

    public void ShowToast(string message, string kind = "info")
    {
        ToastMessage = message;
        ToastKind = kind;
        ToastVisible = true;
        _toastTimer.Stop();
        _toastTimer.Start();
    }

    private void RefreshPalette()
    {
        PaletteResults.Clear();
        var query = PaletteQuery.Trim();

        if (query.Length == 0)
        {
            foreach (var item in Nav.Concat(Footer))
                PaletteResults.Add(new PaletteResult(item.Label, item.Description, item.Key, null, item.Icon));
        }
        else
        {
            foreach (var tweak in TweakCatalog.All)
            {
                if (!tweak.Title.Contains(query, StringComparison.OrdinalIgnoreCase) &&
                    !tweak.Summary.Contains(query, StringComparison.OrdinalIgnoreCase) &&
                    !tweak.Id.Contains(query, StringComparison.OrdinalIgnoreCase)) continue;

                PaletteResults.Add(new PaletteResult(
                    tweak.Title,
                    tweak.Summary,
                    tweak.Module == TweakModule.Performance ? "performance" : "privacy",
                    tweak.Id,
                    tweak.Module == TweakModule.Performance ? "IcoSpeed" : "IcoShield"));
            }

            foreach (var item in Nav.Concat(Footer))
            {
                if (item.Label.Contains(query, StringComparison.OrdinalIgnoreCase))
                    PaletteResults.Add(new PaletteResult(item.Label, item.Description, item.Key, null, item.Icon));
            }
        }

        PaletteSelection = PaletteResults.FirstOrDefault();
    }

    private void AcceptPalette()
    {
        var target = PaletteSelection ?? PaletteResults.FirstOrDefault();
        if (target is null) return;

        Navigate(target.ModuleKey);

        if (target.TweakId is not null && CurrentPage is TweakModuleViewModel module)
            module.FocusTweak(target.TweakId);

        PaletteOpen = false;
    }
}
