using Microsoft.Win32;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.Core.Engine;

/// <summary>Snapshot of a registry value, normalised to strings so it can be journalled and replayed.</summary>
public readonly record struct RegistrySnapshot(bool Existed, string? Value, string? Kind)
{
    public static readonly RegistrySnapshot Missing = new(false, null, null);
}

/// <summary>
/// Every side effect the engine can perform. Swapping this out is how the self-test runs
/// the whole apply/undo cycle without touching a real machine.
/// </summary>
public interface ISystemAccess
{
    bool IsElevated { get; }

    RegistrySnapshot ReadRegistry(Hive hive, string path, string name);
    void WriteRegistry(Hive hive, string path, string name, string value, RegistryKind kind);
    void DeleteRegistry(Hive hive, string path, string name);

    /// <summary>Raw Start value of a service, as text ("2", "4", ...). Null when the service does not exist.</summary>
    string? ReadServiceStart(string service);
    void WriteServiceStart(string service, ServiceStart mode);
    void StopService(string service);

    /// <summary>Active power scheme GUID as text, or null if it cannot be read.</summary>
    string? ReadActivePowerPlan();
    void WriteActivePowerPlan(string guid);
}

/// <summary>Real machine implementation. Uses only documented Windows surfaces.</summary>
public sealed class WindowsSystemAccess : ISystemAccess
{
    public bool IsElevated
    {
        get
        {
            try
            {
                using var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
                var principal = new System.Security.Principal.WindowsPrincipal(identity);
                return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }
    }

    private static RegistryKey OpenHive(Hive hive, bool writable) => hive switch
    {
        Hive.LocalMachine => Registry.LocalMachine,
        Hive.CurrentUser => Registry.CurrentUser,
        _ => Registry.Users
    };

    public RegistrySnapshot ReadRegistry(Hive hive, string path, string name)
    {
        try
        {
            using var baseKey = OpenHive(hive, false);
            using var key = baseKey.OpenSubKey(path, false);
            if (key is null) return RegistrySnapshot.Missing;

            // GetValueKind throws when the name is absent, so the presence check comes first.
            if (!key.GetValueNames().Contains(name, StringComparer.OrdinalIgnoreCase))
                return RegistrySnapshot.Missing;

            var kind = key.GetValueKind(name);
            var raw = key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
            if (raw is null) return RegistrySnapshot.Missing;

            // DWORD and QWORD come back signed. Render them unsigned so a value such as
            // 0xFFFFFFFF round-trips as 4294967295 instead of -1 and compares equal after a write.
            var text = kind switch
            {
                Microsoft.Win32.RegistryValueKind.Binary => Convert.ToHexString((byte[])raw),
                Microsoft.Win32.RegistryValueKind.DWord when raw is int dword =>
                    unchecked((uint)dword).ToString(System.Globalization.CultureInfo.InvariantCulture),
                Microsoft.Win32.RegistryValueKind.QWord when raw is long qword =>
                    unchecked((ulong)qword).ToString(System.Globalization.CultureInfo.InvariantCulture),
                _ => Convert.ToString(raw, System.Globalization.CultureInfo.InvariantCulture)
            };

            return new RegistrySnapshot(true, text, kind.ToString());
        }
        catch (System.Security.SecurityException)
        {
            return RegistrySnapshot.Missing;
        }
        catch (UnauthorizedAccessException)
        {
            return RegistrySnapshot.Missing;
        }
        catch (Exception)
        {
            // A locked or unloaded hive must read as missing, not crash detection.
            return RegistrySnapshot.Missing;
        }
    }

    public void WriteRegistry(Hive hive, string path, string name, string value, RegistryKind kind)
    {
        using var baseKey = OpenHive(hive, true);
        using var key = baseKey.CreateSubKey(path, true);
        var regKind = kind switch
        {
            RegistryKind.String => Microsoft.Win32.RegistryValueKind.String,
            RegistryKind.ExpandString => Microsoft.Win32.RegistryValueKind.ExpandString,
            RegistryKind.Binary => Microsoft.Win32.RegistryValueKind.Binary,
            RegistryKind.Qword => Microsoft.Win32.RegistryValueKind.QWord,
            _ => Microsoft.Win32.RegistryValueKind.DWord
        };

        object converted = regKind switch
        {
            Microsoft.Win32.RegistryValueKind.DWord => unchecked((int)ToLong(value)),
            Microsoft.Win32.RegistryValueKind.QWord => ToLong(value),
            Microsoft.Win32.RegistryValueKind.Binary => Convert.FromHexString(value),
            _ => value
        };

        key.SetValue(name, converted, regKind);
    }

    private static long ToLong(string value)
    {
        if (long.TryParse(value, out var parsed)) return parsed;
        if (uint.TryParse(value, out var unsigned)) return unsigned;
        return 0;
    }

    public void DeleteRegistry(Hive hive, string path, string name)
    {
        using var baseKey = OpenHive(hive, true);
        using var key = baseKey.OpenSubKey(path, true);
        key?.DeleteValue(name, throwOnMissingValue: false);
    }

    public string? ReadServiceStart(string service)
    {
        var snapshot = ReadRegistry(Hive.LocalMachine,
            $@"SYSTEM\CurrentControlSet\Services\{service}", "Start");
        return snapshot.Existed ? snapshot.Value : null;
    }

    public void WriteServiceStart(string service, ServiceStart mode)
    {
        WriteRegistry(Hive.LocalMachine,
            $@"SYSTEM\CurrentControlSet\Services\{service}", "Start",
            ((int)mode).ToString(), RegistryKind.Dword);
    }

    public void StopService(string service)
    {
        // No ServiceController package; sc.exe is the documented equivalent and never shows a window.
        RunHidden("sc.exe", $"stop \"{service}\"");
    }

    public string? ReadActivePowerPlan()
    {
        var raw = RunCaptured("powercfg.exe", "/getactivescheme");
        if (string.IsNullOrWhiteSpace(raw)) return null;
        var match = System.Text.RegularExpressions.Regex.Match(
            raw, "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
        return match.Success ? match.Value.ToLowerInvariant() : null;
    }

    public void WriteActivePowerPlan(string guid) => RunHidden("powercfg.exe", $"/setactive {guid}");

    private static void RunHidden(string file, string args)
    {
        try
        {
            using var process = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = file,
                Arguments = args,
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            });
            process?.WaitForExit(8000);
        }
        catch
        {
            // Best effort: a failed service stop is not fatal, the start mode is what matters.
        }
    }

    private static string? RunCaptured(string file, string args)
    {
        try
        {
            using var process = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = file,
                Arguments = args,
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            });
            if (process is null) return null;
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(8000);
            return output;
        }
        catch
        {
            return null;
        }
    }
}
