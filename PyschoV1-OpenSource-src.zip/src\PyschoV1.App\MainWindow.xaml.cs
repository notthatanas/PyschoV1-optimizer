using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using PyschoV1.App.Runtime;
using PyschoV1.App.ViewModels;

namespace PyschoV1.App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        var shell = new ShellViewModel();
        AppServices.Shell = shell;
        Shell.DataContext = shell;
        Shell.AttachWindow(this);

        try
        {
            WindowMetrics.Attach(this);
        }
        catch (Exception ex)
        {
            // Custom chrome still works without the work-area hook; never fail the launch for it.
            StartupTrace.Write("window metrics unavailable: " + ex.Message);
        }

        PreviewKeyDown += OnPreviewKeyDown;
        StateChanged += (_, _) => Shell.ShowRestoreGlyph(WindowState == WindowState.Maximized);

        // A short entrance makes the window feel intentional without delaying the first frame.
        if (Motion.Enabled)
        {
            var scale = new ScaleTransform(1, 1);
            RootGrid.RenderTransform = scale;
            RootGrid.Opacity = 1;

            Loaded += (_, _) =>
            {
                RootGrid.BeginAnimation(OpacityProperty, Motion.Tween(0, 1, 180));
                scale.BeginAnimation(ScaleTransform.ScaleXProperty, Motion.Tween(0.985, 1, 260));
                scale.BeginAnimation(ScaleTransform.ScaleYProperty, Motion.Tween(0.985, 1, 260));
            };
        }
    }

    private void OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (Shell.DataContext is not ShellViewModel shell) return;

        if (e.Key == Key.K && Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            shell.OpenPalette();
            e.Handled = true;
            return;
        }

        if (e.Key == Key.Escape && shell.PaletteOpen)
        {
            shell.PaletteOpen = false;
            e.Handled = true;
        }
    }
}
