using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Apps;

namespace PyschoV1.App.ViewModels;

/// <summary>One selectable category pill in the Apps toolbar.</summary>
public sealed class CategoryChip : ObservableObject
{
    private bool _isSelected;

    public CategoryChip(string name) => Name = name;

    public string Name { get; }

    public bool IsSelected
    {
        get => _isSelected;
        set => Set(ref _isSelected, value);
    }
}

/// <summary>A category group on the Apps page.</summary>
public sealed class AppGroup
{
    public AppGroup(string name, IReadOnlyList<AppItemViewModel> items)
    {
        Name = name;
        Items = items;
    }

    public string Name { get; }
    public IReadOnlyList<AppItemViewModel> Items { get; }
}

public sealed class AppsViewModel : ObservableObject
{
    private readonly List<AppItemViewModel> _items = new();
    private readonly DispatcherTimer _filterTimer = new() { Interval = TimeSpan.FromMilliseconds(140) };
    private string _query = "";
    private string _category = "All";
    private bool _isLoading = true;
    private bool _wingetAvailable;
    private string _statusText = "Reading installed apps…";

    public AppsViewModel()
    {
        var service = AppServices.Apps;
        foreach (var entry in AppCatalog.All)
            _items.Add(new AppItemViewModel(this, service, entry));

        CategoryChips.Add(new CategoryChip("All"));
        foreach (var category in AppCatalog.Categories)
            CategoryChips.Add(new CategoryChip(category));
        CategoryChips[0].IsSelected = true;

        _filterTimer.Tick += (_, _) =>
        {
            _filterTimer.Stop();
            Rebuild();
        };

        SetCategoryCommand = new RelayCommand<string>(SetCategory);
        RefreshCommand = new AsyncRelayCommand(RefreshDetectionAsync);
        OpenDownloadsCommand = new RelayCommand(AppInstallerService.OpenDownloadFolder);

        Rebuild();
        _ = InitializeAsync();
    }

    public ObservableCollection<CategoryChip> CategoryChips { get; } = new();
    public ObservableCollection<AppGroup> Groups { get; } = new();

    public ICommand SetCategoryCommand { get; }
    public ICommand RefreshCommand { get; }
    public ICommand OpenDownloadsCommand { get; }

    public string SearchQuery
    {
        get => _query;
        set
        {
            if (!Set(ref _query, value)) return;

            // Settle typing before rebuilding the card list, same as the tweak pages.
            _filterTimer.Stop();
            _filterTimer.Start();
        }
    }

    public string StatusText
    {
        get => _statusText;
        private set => Set(ref _statusText, value);
    }

    public bool IsLoading
    {
        get => _isLoading;
        private set => Set(ref _isLoading, value);
    }

    public bool WingetAvailable
    {
        get => _wingetAvailable;
        private set
        {
            if (!Set(ref _wingetAvailable, value)) return;
            foreach (var item in _items) item.RaiseInstallMeta();
        }
    }

    public int InstalledCount => _items.Count(i => i.IsInstalled);

    public string InstalledText => $"{InstalledCount} of {_items.Count} installed";

    public bool IsEmpty => Groups.Count == 0;

    private async Task InitializeAsync()
    {
        IsLoading = true;
        StatusText = "Reading installed apps…";
        try
        {
            var wingetTask = AppServices.Apps.CheckWingetAsync();
            var installed = await Task.Run(() => AppServices.Apps.ScanInstalled());
            ApplyInstalled(installed);
            WingetAvailable = await wingetTask;
            StatusText = WingetAvailable
                ? "winget is available — installs use the latest verified Microsoft package source. Nothing is bundled or repackaged."
                : "winget was not found — installs fall back to the publisher's own installer, and the official page stays one click away.";
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
            StatusText = "Installed apps could not be read. Use Refresh to try again.";
        }
        finally
        {
            IsLoading = false;
        }
    }

    /// <summary>Re-reads the uninstall registry so a fresh install shows up immediately.</summary>
    public async Task RefreshDetectionAsync()
    {
        try
        {
            var installed = await Task.Run(() => AppServices.Apps.ScanInstalled());
            ApplyInstalled(installed);
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
        }
    }

    /// <summary>Called by the view when the page becomes visible again.</summary>
    public void Refresh()
    {
        if (IsLoading) return;
        _ = RefreshDetectionAsync();
    }

    private void ApplyInstalled(IReadOnlyList<InstalledApp> installed)
    {
        foreach (var item in _items)
            item.UpdateInstalled(AppInstallerService.FindInstalled(item.Entry, installed));

        Raise(nameof(InstalledCount));
        Raise(nameof(InstalledText));
    }

    private void SetCategory(string? name)
    {
        _category = string.IsNullOrWhiteSpace(name) ? "All" : name;
        foreach (var chip in CategoryChips)
            chip.IsSelected = chip.Name == _category;
        Rebuild();
    }

    private void Rebuild()
    {
        _filterTimer.Stop();
        var query = _query.Trim();

        var matching = _items
            .Where(i => _category == "All" || i.Entry.Category == _category)
            .Where(i => query.Length == 0 ||
                        i.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                        i.Publisher.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                        i.Summary.Contains(query, StringComparison.OrdinalIgnoreCase))
            .ToList();

        Groups.Clear();
        foreach (var category in AppCatalog.Categories)
        {
            var inCategory = matching
                .Where(i => i.Entry.Category == category)
                .OrderBy(i => i.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (inCategory.Count > 0)
                Groups.Add(new AppGroup(category, inCategory));
        }

        Raise(nameof(IsEmpty));
    }
}
