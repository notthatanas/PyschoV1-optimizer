using PyschoV1.Core.Tweaks;

namespace PyschoV1.Core.Catalog;

internal static class PrivacyTweaks
{
    internal static IEnumerable<Tweak> All() => new[]
    {
        new Tweak
        {
            Id = "priv.telemetry.policy",
            Title = "Block diagnostic telemetry",
            Summary = "Sets the Windows telemetry policy to Security (off).",
            Detail = "Applies the documented policy that stops optional diagnostic data. Required level data is still sent on Enterprise-managed devices.",
            Module = TweakModule.Privacy,
            Category = "Telemetry",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\DataCollection", "AllowTelemetry", 0)
            }
        },
        new Tweak
        {
            Id = "priv.diagtrack",
            Title = "Disable Connected User Experiences service",
            Summary = "Stops DiagTrack, the service that uploads telemetry.",
            Module = TweakModule.Privacy,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("DiagTrack", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "priv.dmwappush",
            Title = "Disable WAP push message service",
            Summary = "Stops dmwappushservice, a legacy telemetry relay.",
            Module = TweakModule.Privacy,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("dmwappushservice", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "priv.adid",
            Title = "Disable advertising ID",
            Summary = "Apps can no longer track you across sessions for ad profiling.",
            Module = TweakModule.Privacy,
            Category = "Telemetry",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", 0)
            }
        },
        new Tweak
        {
            Id = "priv.tailored",
            Title = "Disable tailored experiences",
            Summary = "Stops Windows using diagnostic data to personalise tips and ads.",
            Module = TweakModule.Privacy,
            Category = "Telemetry",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\Privacy",
                    "TailoredExperiencesWithDiagnosticDataEnabled", 0)
            }
        },
        new Tweak
        {
            Id = "priv.speech",
            Title = "Disable online speech recognition",
            Summary = "Voice input stays on-device and is not sent to Microsoft.",
            Module = TweakModule.Privacy,
            Category = "Sensors",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy", "HasAccepted", 0)
            }
        },
        new Tweak
        {
            Id = "priv.inking",
            Title = "Disable typing and inking personalization",
            Summary = "Stops Windows collecting a personal dictionary and handwriting profile.",
            Module = TweakModule.Privacy,
            Category = "Sensors",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\InputPersonalization", "RestrictImplicitTextCollection", 1),
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\InputPersonalization", "RestrictImplicitInkCollection", 1),
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\InputPersonalization\TrainedDataStore", "HarvestContacts", 0),
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\InputPersonalization", "AllowInputPersonalization", 0)
            }
        },
        new Tweak
        {
            Id = "priv.cortana",
            Title = "Disable Cortana",
            Summary = "Turns off the assistant and its voice activation hooks.",
            Module = TweakModule.Privacy,
            Category = "Assistant",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\Windows Search", "AllowCortana", 0)
            }
        },
        new Tweak
        {
            Id = "priv.bingsearch",
            Title = "Remove web results from Start search",
            Summary = "Start menu searches only your PC, not Bing.",
            Module = TweakModule.Privacy,
            Category = "Search",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", 0),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Search", "CortanaConsent", 0)
            }
        },
        new Tweak
        {
            Id = "priv.copilot",
            Title = "Disable Windows Copilot",
            Summary = "Removes Copilot from the taskbar and the Edge sidebar.",
            Module = TweakModule.Privacy,
            Category = "Assistant",
            Risk = RiskLevel.Safe,
            Platforms = new[] { "11" },
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", 1)
            }
        },
        new Tweak
        {
            Id = "priv.recall",
            Title = "Disable Recall snapshots",
            Summary = "Stops Windows 11 from screenshotting your screen history.",
            Module = TweakModule.Privacy,
            Category = "Assistant",
            Risk = RiskLevel.Safe,
            Platforms = new[] { "11" },
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\WindowsAI", "DisableAIDataAnalysis", 1)
            }
        },
        new Tweak
        {
            Id = "priv.feedback",
            Title = "Silence feedback requests",
            Summary = "Windows stops asking you to rate itself.",
            Module = TweakModule.Privacy,
            Category = "Telemetry",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Siuf\Rules", "NumberOfSIUFInPeriod", 0),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Siuf\Rules", "PeriodInNanoSeconds", 0)
            }
        },
        new Tweak
        {
            Id = "priv.wer",
            Title = "Disable Windows Error Reporting",
            Summary = "Crash dumps are no longer collected or uploaded.",
            Module = TweakModule.Privacy,
            Category = "Telemetry",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Microsoft\Windows\Windows Error Reporting", "Disabled", 1)
            }
        },
        new Tweak
        {
            Id = "priv.location",
            Title = "Disable location services",
            Summary = "Turns off the location provider for all apps.",
            Detail = "Maps and Find My Device stop working. Leave this off if you rely on them.",
            Module = TweakModule.Privacy,
            Category = "Sensors",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors", "DisableLocation", 1)
            }
        },
        new Tweak
        {
            Id = "priv.activity",
            Title = "Disable activity history",
            Summary = "Stops Windows recording what you open and syncing it.",
            Module = TweakModule.Privacy,
            Category = "Telemetry",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\System", "EnableActivityFeed", 0),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\System", "PublishUserActivities", 0),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\System", "UploadUserActivities", 0)
            }
        },
        new Tweak
        {
            Id = "priv.consumer",
            Title = "Block consumer feature suggestions",
            Summary = "Stops Windows installing promoted apps and tips.",
            Module = TweakModule.Privacy,
            Category = "Content",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\CloudContent", "DisableWindowsConsumerFeatures", 1),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\CloudContent", "DisableSoftLanding", 1)
            }
        },
        new Tweak
        {
            Id = "priv.suggestions",
            Title = "Remove Start and lock screen suggestions",
            Summary = "No promoted content in Start, Settings or the lock screen.",
            Module = TweakModule.Privacy,
            Category = "Content",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", "SubscribedContent-338388Enabled", 0),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", "SubscribedContent-338389Enabled", 0),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", "SystemPaneSuggestionsEnabled", 0)
            }
        },
        new Tweak
        {
            Id = "priv.apptracking",
            Title = "Disable app launch tracking",
            Summary = "Start and search stop recording which apps you open most.",
            Module = TweakModule.Privacy,
            Category = "Content",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "Start_TrackProgs", 0)
            }
        },
        new Tweak
        {
            Id = "priv.edge",
            Title = "Block Edge diagnostics",
            Summary = "Stops Edge reporting browsing data to Microsoft.",
            Module = TweakModule.Privacy,
            Category = "Browsers",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Edge", "PersonalizationReportingEnabled", 0),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Edge", "SendSiteInfoToImproveServices", 0),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Edge", "UserFeedbackAllowed", 0)
            }
        },
        new Tweak
        {
            Id = "priv.office",
            Title = "Block Office telemetry",
            Summary = "Office 2016 and newer stop sending usage data.",
            Module = TweakModule.Privacy,
            Category = "Office",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Office\16.0\Common\ClientTelemetry", "SendTelemetry", 3),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Office\16.0\Common\ClientTelemetry", "DisconnectedState", 2)
            }
        },
        new Tweak
        {
            Id = "priv.sync",
            Title = "Disable settings sync",
            Summary = "Passwords, themes and preferences stop syncing to other devices.",
            Detail = "Uses the documented SettingSync policy. Local settings are untouched; only cross-device sync stops.",
            Module = TweakModule.Privacy,
            Category = "System",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\SettingSync", "DisableSettingSync", 2),
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\SettingSync", "DisableSettingSyncUserOverride", 1)
            }
        },
        new Tweak
        {
            Id = "priv.autoplay",
            Title = "Disable AutoPlay",
            Summary = "Windows stops prompting to open USB drives, discs and photos.",
            Module = TweakModule.Privacy,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers", "DisableAutoplay", 1)
            }
        },
        new Tweak
        {
            Id = "priv.remotehelp",
            Title = "Disable Remote Assistance",
            Summary = "Other people cannot request a remote session into this PC.",
            Module = TweakModule.Privacy,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SYSTEM\CurrentControlSet\Control\Remote Assistance", "fAllowToGetHelp", 0)
            }
        },
        new Tweak
        {
            Id = "priv.clipboard",
            Title = "Disable cloud clipboard",
            Summary = "Stops clipboard content syncing between your devices.",
            Detail = "Win+V history stops working. Local copy and paste are untouched.",
            Module = TweakModule.Privacy,
            Category = "System",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Clipboard", "EnableClipboardHistory", 0),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Clipboard", "CloudClipboardAutomaticUpload", 0),
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\System", "AllowCrossDeviceClipboard", 0)
            }
        },
        new Tweak
        {
            Id = "priv.searchhighlights",
            Title = "Disable search highlights",
            Summary = "Removes the changing content Windows puts in the search box.",
            Detail = "Applies the documented 'Allow search highlights' policy. Local file search and web results are separate settings and are not touched.",
            Module = TweakModule.Privacy,
            Category = "Search",
            Risk = RiskLevel.Safe,
            Platforms = new[] { "11" },
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\Windows Search", "EnableDynamicContentInWSB", 0)
            }
        },
        new Tweak
        {
            Id = "priv.spotlight",
            Title = "Disable Windows Spotlight",
            Summary = "Stops the lock screen downloading rotating images and tips.",
            Detail = "Your current wallpaper stays. Choose a static picture under Personalisation → Lock screen; no browsing data or account identity is affected.",
            Module = TweakModule.Privacy,
            Category = "Content",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", "RotatingLockScreenEnabled", 0),
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", "RotatingLockScreenOverlayEnabled", 0),
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", "SubscribedContent-338387Enabled", 0)
            }
        },
        new Tweak
        {
            Id = "priv.remoteregistry",
            Title = "Disable Remote Registry",
            Summary = "Stops other machines reading this PC's registry over the network.",
            Detail = "Normal apps, Windows Update and printing do not need this service. Some enterprise management tools do; undo restores the previous start mode.",
            Module = TweakModule.Privacy,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("RemoteRegistry", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "priv.quickaccess",
            Title = "Hide recent files in Quick Access",
            Summary = "File Explorer stops listing recently opened files and folders.",
            Detail = "Sets the two Explorer values behind 'Show recently opened items in Start, Jump Lists'. Pinned items stay pinned; the recent list stops being shown and fed.",
            Module = TweakModule.Privacy,
            Category = "Content",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "ShowRecent", 0),
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "ShowFrequent", 0)
            }
        },
        new Tweak
        {
            Id = "priv.smb1",
            Title = "Disable the SMB1 file-sharing protocol",
            Summary = "Old devices that only speak SMB1 can no longer connect to this PC.",
            Detail = "SMB1 is a decades-old protocol without the mitigations of SMB2/3 and is how ransomware spreads laterally. Windows 10/11, current NAS boxes and printers use SMB2/3 and keep working. If an ancient device stops sharing files, undo this.",
            Module = TweakModule.Privacy,
            Category = "Security",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters", "SMB1", 0)
            }
        }
    };
}
