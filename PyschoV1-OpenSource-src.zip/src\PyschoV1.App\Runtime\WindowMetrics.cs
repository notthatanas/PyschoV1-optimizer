using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace PyschoV1.App.Runtime;

/// <summary>
/// A borderless WPF window maximises over the taskbar unless WM_GETMINMAXINFO is answered with the
/// monitor work area. This is the standard fix and costs nothing at runtime.
/// </summary>
internal static class WindowMetrics
{
    private const int WmGetMinMaxInfo = 0x0024;
    private const int MonitorDefaultToNearest = 0x00000002;

    public static void Attach(Window window)
    {
        if (window.IsLoaded)
        {
            Hook(window);
            return;
        }
        window.SourceInitialized += (_, _) => Hook(window);
    }

    private static void Hook(Window window)
    {
        var handle = new WindowInteropHelper(window).Handle;
        HwndSource.FromHwnd(handle)?.AddHook((IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled) =>
        {
            if (msg != WmGetMinMaxInfo) return IntPtr.Zero;

            var monitor = MonitorFromWindow(hwnd, MonitorDefaultToNearest);
            if (monitor == IntPtr.Zero) return IntPtr.Zero;

            var info = new MonitorInfo { Size = Marshal.SizeOf<MonitorInfo>() };
            if (!GetMonitorInfo(monitor, ref info)) return IntPtr.Zero;

            var mmi = Marshal.PtrToStructure<MinMaxInfo>(lParam);
            mmi.MaxPosition.X = Math.Abs(info.Monitor.Left - info.Work.Left);
            mmi.MaxPosition.Y = Math.Abs(info.Monitor.Top - info.Work.Top);
            mmi.MaxSize.X = Math.Abs(info.Work.Right - info.Work.Left);
            mmi.MaxSize.Y = Math.Abs(info.Work.Bottom - info.Work.Top);
            mmi.MaxTrackSize = mmi.MaxSize;

            Marshal.StructureToPtr(mmi, lParam, true);
            handled = true;
            return IntPtr.Zero;
        });
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Point
    {
        public int X;
        public int Y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MinMaxInfo
    {
        public Point Reserved;
        public Point MaxSize;
        public Point MaxPosition;
        public Point MinTrackSize;
        public Point MaxTrackSize;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MonitorInfo
    {
        public int Size;
        public Rect Monitor;
        public Rect Work;
        public uint Flags;
    }

    [DllImport("user32.dll")]
    private static extern IntPtr MonitorFromWindow(IntPtr hwnd, int flags);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
}
