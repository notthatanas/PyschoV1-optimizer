using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.Converters;

/// <summary>Risk level to a translucent badge background.</summary>
public sealed class RiskBrushConverter : IValueConverter
{
    private static readonly Brush Safe = Frozen(0x22, 0x45, 0xC0, 0x8A);
    private static readonly Brush Caution = Frozen(0x26, 0xE3, 0xB3, 0x41);
    private static readonly Brush Advanced = Frozen(0x26, 0xE5, 0x48, 0x4D);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        RiskLevel.Safe => Safe,
        RiskLevel.Caution => Caution,
        RiskLevel.Advanced => Advanced,
        _ => Safe
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();

    private static Brush Frozen(byte a, byte r, byte g, byte b)
    {
        var brush = new SolidColorBrush(Color.FromArgb(a, r, g, b));
        brush.Freeze();
        return brush;
    }
}

public sealed class RiskTextBrushConverter : IValueConverter
{
    private static readonly Brush Safe = Frozen(0x6B, 0xDC, 0xAB);
    private static readonly Brush Caution = Frozen(0xF0, 0xC8, 0x66);
    private static readonly Brush Advanced = Frozen(0xF5, 0x7C, 0x80);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        RiskLevel.Safe => Safe,
        RiskLevel.Caution => Caution,
        RiskLevel.Advanced => Advanced,
        _ => Brushes.Gray
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();

    private static Brush Frozen(byte r, byte g, byte b)
    {
        var brush = new SolidColorBrush(Color.FromRgb(r, g, b));
        brush.Freeze();
        return brush;
    }
}

public sealed class EmptyStringToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        string.IsNullOrWhiteSpace(value as string) ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class InverseBooleanConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is bool b && !b;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is bool b && !b;
}

public sealed class NullToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is null ? Visibility.Collapsed : Visibility.Visible;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class BoolToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var visible = value is bool b && b;
        if (Invert) visible = !visible;
        return visible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is Visibility.Visible;
}

public sealed class CountToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var count = value is int i ? i : 0;
        var visible = count > 0;
        if (Invert) visible = !visible;
        return visible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

/// <summary>0-100 percentage to a green / amber / red brush.</summary>
public sealed class PercentToBrushConverter : IValueConverter
{
    private static readonly Brush High = Frozen(0xE5, 0x48, 0x4D);
    private static readonly Brush Medium = Frozen(0xE3, 0xB3, 0x41);
    private static readonly Brush Normal = Frozen(0x7C, 0x5C, 0xFF);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var percent = value is double d ? d : 0;
        return percent switch
        {
            >= 85 => High,
            >= 65 => Medium,
            _ => Normal
        };
    }

    private static Brush Frozen(byte r, byte g, byte b)
    {
        var brush = new SolidColorBrush(Color.FromRgb(r, g, b));
        brush.Freeze();
        return brush;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class StateLabelConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        TweakState.On => "Applied",
        TweakState.Partial => "Partial",
        TweakState.Unavailable => "Unsupported",
        _ => "Off"
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class FileSizeConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var bytes = value switch
        {
            long l => l,
            int i => i,
            _ => 0L
        };
        return Core.Modules.CleanerService.FormatBytes(bytes);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
