using System.Globalization;
using PyschoV1.Core.Safety;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.Core.Engine;

public enum TweakState
{
    Off,
    On,
    /// <summary>Some ops of the tweak match, some do not. Shown as an amber half-toggle.</summary>
    Partial,
    /// <summary>The tweak cannot be evaluated on this build (write would be refused).</summary>
    Unavailable
}

public sealed record PlanStep(string Description, string Current, bool Matches);

public sealed class ApplyResult
{
    public bool Success { get; init; }
    public bool DryRun { get; init; }
    public string? Error { get; init; }
    public bool NeedsElevation { get; init; }
    public JournalEntry? Entry { get; init; }
    public IReadOnlyList<PlanStep> Plan { get; init; } = Array.Empty<PlanStep>();

    public static ApplyResult Ok(JournalEntry? entry, bool dryRun, IReadOnlyList<PlanStep> plan) =>
        new() { Success = true, Entry = entry, DryRun = dryRun, Plan = plan };

    public static ApplyResult Fail(string error, bool needsElevation) =>
        new() { Success = false, Error = error, NeedsElevation = needsElevation };
}

/// <summary>
/// The only thing allowed to change the machine. Every write is preceded by a before-state capture,
/// so a failed tweak rolls itself back and a successful one is always reversible.
/// </summary>
public sealed class TweakEngine
{
    private readonly ISystemAccess _sys;
    private readonly TweakJournal _journal;
    private readonly object _writeGate = new();

    public TweakEngine(ISystemAccess sys, TweakJournal journal)
    {
        _sys = sys;
        _journal = journal;
    }

    public TweakJournal Journal => _journal;

    public bool IsElevated => _sys.IsElevated;

    /// <summary>True when the catalog entry applies to this Windows build.</summary>
    public static bool SupportsPlatform(Tweak tweak, int build)
    {
        if (tweak.Platforms.Count == 0) return true;
        var tag = build >= 22000 ? "11" : "10";
        return tweak.Platforms.Contains(tag);
    }

    public TweakState GetState(Tweak tweak)
    {
        var applicable = 0;
        var matches = 0;
        foreach (var op in tweak.Ops)
        {
            var current = ReadOp(op);
            if (current is null) continue;
            applicable++;
            if (Matches(op, current.Value)) matches++;
        }

        // A service that is not installed (or a value that cannot be read) is not "off" — the
        // tweak simply cannot be evaluated here. That distinction keeps the UI from offering a
        // switch that would silently do nothing.
        if (applicable == 0) return TweakState.Unavailable;
        if (matches == 0) return TweakState.Off;
        return matches == applicable ? TweakState.On : TweakState.Partial;
    }

    /// <summary>Builds the dry-run description the UI shows before anything is written.</summary>
    public IReadOnlyList<PlanStep> BuildPlan(Tweak tweak)
    {
        var steps = new List<PlanStep>(tweak.Ops.Count);
        foreach (var op in tweak.Ops)
        {
            var current = ReadOp(op);
            var text = current is null ? "(not supported here)" : current.Value ?? "(not set)";
            steps.Add(new PlanStep(op.Describe(), text, current is not null && Matches(op, current.Value)));
        }
        return steps;
    }

    public ApplyResult Apply(Tweak tweak, string origin = "manual", bool dryRun = false)
    {
        var plan = BuildPlan(tweak);
        if (dryRun) return ApplyResult.Ok(null, true, plan);

        // Serialise writes: a preset can run in the background while the user flips a switch.
        lock (_writeGate)
        {
            var patches = new List<PatchRecord>();
            foreach (var op in tweak.Ops)
            {
                try
                {
                    var patch = WriteOp(op);
                    patches.Add(patch);

                    // Read the value back. A write that Windows quietly dropped must fail the
                    // tweak instead of being journalled as applied.
                    var verification = ReadOp(op);
                    if (verification is null || !Matches(op, verification.Value))
                        throw new InvalidOperationException(
                            $"Windows did not keep the change for {op.Describe()}.");
                }
                catch (UnauthorizedAccessException ex)
                {
                    UndoPatches(patches);
                    return ApplyResult.Fail(
                        $"Windows refused the change ({ex.Message}). Run Pyscho V1 as administrator.", true);
                }
                catch (Exception ex)
                {
                    UndoPatches(patches);
                    return ApplyResult.Fail($"Could not apply: {ex.Message}", false);
                }
            }

            var entry = new JournalEntry
            {
                TweakId = tweak.Id,
                Title = tweak.Title,
                Module = tweak.Module.ToString(),
                Origin = origin,
                Plan = plan.Select(p => p.Description).ToList(),
                Patches = patches
            };

            // A change without an undo record is not a reversible change. If the journal cannot be
            // written, put the machine back rather than claiming the tweak is safely applied.
            if (!_journal.TryAppend(entry))
            {
                var rollback = UndoPatches(patches);
                var suffix = rollback.Count == 0
                    ? " The change was rolled back."
                    : " The rollback also reported: " + string.Join("; ", rollback);
                return ApplyResult.Fail("The undo journal could not be saved, so nothing was kept." + suffix, false);
            }

            return ApplyResult.Ok(entry, false, plan);
        }
    }

    public ApplyResult Revert(JournalEntry entry, bool dryRun = false)
    {
        if (dryRun) return ApplyResult.Ok(entry, true, Array.Empty<PlanStep>());

        lock (_writeGate)
        {
            try
            {
                var failures = UndoPatches(entry.Patches);
                if (failures.Count > 0)
                {
                    return ApplyResult.Fail(
                        "Revert did not restore every value: " + string.Join("; ", failures),
                        failures.Any(f => f.Contains("denied", StringComparison.OrdinalIgnoreCase)));
                }

                entry.Reverted = true;
                entry.RevertedAt = DateTimeOffset.Now;
                _journal.Save(entry);
                return ApplyResult.Ok(entry, false, Array.Empty<PlanStep>());
            }
            catch (Exception ex)
            {
                return ApplyResult.Fail($"Revert failed: {ex.Message}", ex is UnauthorizedAccessException);
            }
        }
    }

    /// <summary>Restores patches in reverse order. Returns the failures instead of hiding them.</summary>
    private List<string> UndoPatches(IReadOnlyList<PatchRecord> patches)
    {
        var failures = new List<string>();
        for (var i = patches.Count - 1; i >= 0; i--)
        {
            var patch = patches[i];
            try
            {
                switch (patch.Kind)
                {
                    case "registry":
                        if (patch.Existed && patch.Value is not null)
                        {
                            _sys.WriteRegistry(
                                ParseHive(patch.Hive),
                                patch.Path ?? "",
                                patch.Name ?? "",
                                patch.Value,
                                ParseKind(patch.ValueKind));
                        }
                        else
                        {
                            _sys.DeleteRegistry(ParseHive(patch.Hive), patch.Path ?? "", patch.Name ?? "");
                        }
                        break;

                    case "service":
                        if (patch.Service is not null && int.TryParse(patch.PreviousStart, out var start))
                            _sys.WriteServiceStart(patch.Service, (ServiceStart)start);
                        break;

                    case "powerplan":
                        if (!string.IsNullOrEmpty(patch.PreviousPlan))
                            _sys.WriteActivePowerPlan(patch.PreviousPlan);
                        break;
                }
            }
            catch (Exception ex)
            {
                // Keep unwinding: the remaining patches are still worth restoring.
                failures.Add($"{patch.Describe()} ({ex.Message})");
            }
        }

        return failures;
    }

    private PatchRecord WriteOp(TweakOp op) => op switch
    {
        RegistryValueOp rv => WriteRegistryOp(rv),
        RegistryDeleteOp rd => DeleteRegistryOp(rd),
        ServiceStartOp sv => WriteServiceOp(sv),
        PowerPlanOp pp => WritePowerPlanOp(pp),
        _ => throw new NotSupportedException($"Unknown op {op.GetType().Name}")
    };

    private PatchRecord WriteRegistryOp(RegistryValueOp op)
    {
        var before = _sys.ReadRegistry(op.Hive, op.Path, op.Name);
        _sys.WriteRegistry(op.Hive, op.Path, op.Name, ToText(op.Value), op.Kind);
        return new PatchRecord
        {
            Kind = "registry",
            Hive = op.Hive.ToString(),
            Path = op.Path,
            Name = op.Name,
            Existed = before.Existed,
            Value = before.Value,
            ValueKind = before.Kind
        };
    }

    private PatchRecord DeleteRegistryOp(RegistryDeleteOp op)
    {
        var before = _sys.ReadRegistry(op.Hive, op.Path, op.Name);
        _sys.DeleteRegistry(op.Hive, op.Path, op.Name);
        return new PatchRecord
        {
            Kind = "registry",
            Hive = op.Hive.ToString(),
            Path = op.Path,
            Name = op.Name,
            Existed = before.Existed,
            Value = before.Value,
            ValueKind = before.Kind
        };
    }

    private PatchRecord WriteServiceOp(ServiceStartOp op)
    {
        var before = _sys.ReadServiceStart(op.Service)
            ?? throw new InvalidOperationException(
                $"The {op.Service} service is not installed on this PC.");

        _sys.WriteServiceStart(op.Service, op.Mode);
        if (op.Mode == ServiceStart.Disabled) _sys.StopService(op.Service);

        return new PatchRecord { Kind = "service", Service = op.Service, PreviousStart = before };
    }

    private PatchRecord WritePowerPlanOp(PowerPlanOp op)
    {
        var before = _sys.ReadActivePowerPlan()
            ?? throw new InvalidOperationException(
                "The active power plan could not be read, so it could not be restored later.");

        _sys.WriteActivePowerPlan(op.Scheme.ToString());
        return new PatchRecord { Kind = "powerplan", PreviousPlan = before };
    }

    private OpReading? ReadOp(TweakOp op) => op switch
    {
        RegistryValueOp rv => ReadRegistryOp(rv),
        RegistryDeleteOp rd => ReadDeleteOp(rd),
        ServiceStartOp sv => _sys.ReadServiceStart(sv.Service) is { } start
            ? new OpReading(start, ((int)sv.Mode).ToString(CultureInfo.InvariantCulture))
            : null,
        PowerPlanOp pp => _sys.ReadActivePowerPlan() is { } plan
            ? new OpReading(plan, pp.Scheme.ToString().ToLowerInvariant())
            : null,
        _ => null
    };

    private OpReading? ReadRegistryOp(RegistryValueOp op)
    {
        var snapshot = _sys.ReadRegistry(op.Hive, op.Path, op.Name);
        if (!snapshot.Existed) return new OpReading(null, ToText(op.Value));
        return new OpReading(snapshot.Value, ToText(op.Value));
    }

    private OpReading? ReadDeleteOp(RegistryDeleteOp op)
    {
        var snapshot = _sys.ReadRegistry(op.Hive, op.Path, op.Name);
        // A delete op is satisfied when the value is absent.
        return new OpReading(snapshot.Value, null);
    }

    private static bool Matches(TweakOp op, string? current) => op switch
    {
        RegistryValueOp rv => string.Equals(current, ToText(rv.Value), StringComparison.OrdinalIgnoreCase),
        RegistryDeleteOp => string.IsNullOrEmpty(current),
        ServiceStartOp sv => string.Equals(current, ((int)sv.Mode).ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal),
        PowerPlanOp pp => string.Equals(current, pp.Scheme.ToString().ToLowerInvariant(), StringComparison.OrdinalIgnoreCase),
        _ => false
    };

    private static string ToText(object value) => value switch
    {
        byte[] bytes => Convert.ToHexString(bytes),
        bool b => b ? "1" : "0",
        IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
        _ => value.ToString() ?? ""
    };

    private static Hive ParseHive(string? hive) => hive switch
    {
        nameof(Hive.CurrentUser) => Hive.CurrentUser,
        nameof(Hive.Users) => Hive.Users,
        _ => Hive.LocalMachine
    };

    private static RegistryKind ParseKind(string? kind) => kind switch
    {
        nameof(RegistryKind.String) => RegistryKind.String,
        nameof(RegistryKind.ExpandString) => RegistryKind.ExpandString,
        nameof(RegistryKind.Binary) => RegistryKind.Binary,
        nameof(RegistryKind.Qword) => RegistryKind.Qword,
        _ => RegistryKind.Dword
    };

    private sealed record OpReading(string? Value, string? Target);
}
