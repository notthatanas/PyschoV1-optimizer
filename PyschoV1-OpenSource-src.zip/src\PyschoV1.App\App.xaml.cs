using System.Windows;
using System.Windows.Threading;
using PyschoV1.App.Runtime;

namespace PyschoV1.App;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            if (args.ExceptionObject is Exception ex)
            {
                AppServices.ReportError(ex);
                StartupTrace.Write("FATAL (background): " + ex.GetType().Name + ": " + ex.Message);
            }
        };

        StartupTrace.Write(
            $"launch args=[{string.Join(' ', e.Args)}] os={Environment.OSVersion} elevated={IsElevatedForTrace()}");

        try
        {
            RunStartup(e);
        }
        catch (Exception ex)
        {
            // The old path let an exception here leave an invisible process running. A failed
            // launch now says what happened and writes both diagnostic logs.
            Fatal(ex);
        }
    }

    private void RunStartup(StartupEventArgs e)
    {
        AppServices.Initialize();
        StartupTrace.Write("services ready");

        // Baseline: how much of the launch time is WPF itself, with none of our UI.
        var baselineIndex = Array.IndexOf(e.Args, "--benchmark-baseline");
        if (baselineIndex >= 0 && baselineIndex + 1 < e.Args.Length)
        {
            var clock = System.Diagnostics.Stopwatch.StartNew();
            var bare = new Window
            {
                Width = 400,
                Height = 300,
                WindowStartupLocation = WindowStartupLocation.Manual,
                Left = -20000,
                Top = -20000,
                ShowInTaskbar = false,
                Content = new System.Windows.Controls.TextBlock { Text = "baseline" }
            };
            bare.ContentRendered += (_, _) =>
            {
                clock.Stop();
                var self = System.Diagnostics.Process.GetCurrentProcess();
                System.IO.File.WriteAllText(e.Args[baselineIndex + 1],
                    $"startup_ms={clock.ElapsedMilliseconds}\nworking_set_mb={self.WorkingSet64 / 1048576.0:0.0}\nprivate_mb={self.PrivateMemorySize64 / 1048576.0:0.0}\n");
                bare.Close();
                Shutdown();
            };
            bare.Show();
            return;
        }

        // Measures real cold start and idle footprint on the published binary.
        var benchIndex = Array.IndexOf(e.Args, "--benchmark");
        if (benchIndex >= 0 && benchIndex + 1 < e.Args.Length)
        {
            var clock = System.Diagnostics.Stopwatch.StartNew();
            var benchWindow = new MainWindow
            {
                // Rendered for real, but off-screen so the benchmark does not flash on the desktop.
                WindowStartupLocation = WindowStartupLocation.Manual,
                Left = -20000,
                Top = -20000,
                ShowInTaskbar = false
            };
            MainWindow = benchWindow;
            benchWindow.ContentRendered += (_, _) =>
            {
                clock.Stop();
                var self = System.Diagnostics.Process.GetCurrentProcess();
                var workingSet = self.WorkingSet64 / 1048576.0;
                var privateBytes = self.PrivateMemorySize64 / 1048576.0;
                try
                {
                    System.IO.File.WriteAllText(e.Args[benchIndex + 1],
                        $"startup_ms={clock.ElapsedMilliseconds}\nworking_set_mb={workingSet:0.0}\nprivate_mb={privateBytes:0.0}\n");
                }
                catch
                {
                    Console.WriteLine($"startup_ms={clock.ElapsedMilliseconds} ws={workingSet:0.0} private={privateBytes:0.0}");
                }

                benchWindow.Close();
                Shutdown();
            };
            benchWindow.Show();
            return;
        }

        var iconIndex = Array.IndexOf(e.Args, "--make-icon");
        if (iconIndex >= 0 && iconIndex + 1 < e.Args.Length)
        {
            try
            {
                IconBuilder.Write(e.Args[iconIndex + 1]);
                Console.WriteLine("icon written: " + e.Args[iconIndex + 1]);
            }
            catch (Exception ex)
            {
                AppServices.ReportError(ex);
                Console.WriteLine("ICON FAILED: " + ex);
            }

            Shutdown();
            return;
        }

        // Offscreen render mode, used by the build to check the layout without opening a window.
        var renderIndex = Array.IndexOf(e.Args, "--render-preview");
        if (renderIndex >= 0 && renderIndex + 1 < e.Args.Length)
        {
            try
            {
                var target = PreviewRenderer.Render(e.Args[renderIndex + 1]);
                Console.WriteLine(target);
            }
            catch (Exception ex)
            {
                AppServices.ReportError(ex);
                Console.WriteLine("RENDER FAILED: " + ex);
            }

            Shutdown();
            return;
        }

        StartupTrace.Write("creating main window");
        var window = new MainWindow();
        MainWindow = window;
        window.Show();
        window.Activate();
        StartupTrace.Write("main window shown");
    }

    private static bool IsElevatedForTrace()
    {
        try
        {
            using var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
            return new System.Security.Principal.WindowsPrincipal(identity)
                .IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
        }
        catch
        {
            return false;
        }
    }

    private void OnUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        // Before the shell is visible there is nothing to recover: report, close and do not leave
        // a process with no window behind.
        if (MainWindow?.IsVisible != true)
        {
            e.Handled = true;
            Fatal(e.Exception);
            return;
        }

        AppServices.ReportError(e.Exception);
        StartupTrace.Write("unhandled UI error: " + e.Exception.GetType().Name + ": " + e.Exception.Message);
        MessageBox.Show(
            $"Something went wrong:\n\n{e.Exception.Message}\n\nDetails were written to %AppData%\\PyschoV1\\errors.log.",
            "Pyscho V1", MessageBoxButton.OK, MessageBoxImage.Warning);
        e.Handled = true;
    }

    private void Fatal(Exception ex)
    {
        AppServices.ReportError(ex);
        StartupTrace.Write("FATAL: " + ex.GetType().Name + ": " + ex.Message);

        try
        {
            MessageBox.Show(
                "Pyscho V1 could not open.\n\n" +
                ex.Message +
                "\n\nA diagnostic log was written to:\n%AppData%\\PyschoV1\\errors.log" +
                "\n\nIf Windows SmartScreen or antivirus blocked the file, allow it and try again.",
                "Pyscho V1", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        catch
        {
            // A failing dialog must not keep a broken process alive.
        }

        try { Shutdown(1); } catch { }
    }
}
