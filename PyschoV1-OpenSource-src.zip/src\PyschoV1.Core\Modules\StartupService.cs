using System.Text.Json;
using Microsoft.Win32;

namespace PyschoV1.Core.Modules;

public sealed record StartupItem(
    string Id,
    string Name,
    string Command,
    string Location,
    string Scope,
    bool IsEnabled,
    bool IsFolderItem,
    string ApprovedKey,
    string ApprovedName,
    string Detail)
{
    public string Impact => IsEnabled ? "Enabled" : "Disabled";
}

public sealed record StartupBackup(DateTimeOffset CreatedAt, List<StartupBackupItem> Items);

public sealed record StartupBackupItem(
    string ApprovedKey,
    string ApprovedName,
    string? RawHex,
    bool IsEnabled,
    string? Scope = null);

/// <summary>
/// Reads and toggles startup entries non-destructively. Entries are never deleted from Run keys;
/// only the StartupApproved flag changes, so Task Manager and Pyscho V1 always agree.
/// </summary>
public sealed class StartupService
{
    private const string RunPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ApprovedRun = @"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run";
    private const string ApprovedStartupFolder = @"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder";

    public IReadOnlyList<StartupItem> Read()
    {
        var items = new List<StartupItem>();
        ReadRunKey(Registry.CurrentUser, "User", items);
        ReadRunKey(Registry.LocalMachine, "All users", items);
        ReadStartupFolder(Environment.SpecialFolder.Startup, "User", ApprovedStartupFolder, items);
        ReadStartupFolder(Environment.SpecialFolder.CommonStartup, "All users", ApprovedStartupFolder, items);
        return items.OrderByDescending(i => i.IsEnabled).ThenBy(i => i.Name).ToList();
    }

    private static void ReadRunKey(RegistryKey hive, string scope, List<StartupItem> items)
    {
        try
        {
            using var run = hive.OpenSubKey(RunPath);
            if (run is null) return;

            var approvedHive = hive;
            using var approved = approvedHive.OpenSubKey(ApprovedRun);

            foreach (var name in run.GetValueNames())
            {
                if (string.IsNullOrWhiteSpace(name)) continue;
                var command = run.GetValue(name)?.ToString() ?? "";
                var enabled = IsApprovedEnabled(approved, name);
                items.Add(new StartupItem(
                    $"run:{scope}:{name}",
                    name,
                    command,
                    "Registry Run key",
                    scope,
                    enabled,
                    false,
                    ApprovedRun,
                    name,
                    DescribeCommand(command)));
            }
        }
        catch
        {
            // A locked Run key simply yields fewer entries.
        }
    }

    private static void ReadStartupFolder(Environment.SpecialFolder folder, string scope, string approvedPath, List<StartupItem> items)
    {
        try
        {
            var path = Environment.GetFolderPath(folder);
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;

            // The common startup folder is approved in HKLM; the per-user folder in HKCU.
            // Using HKCU for both was reading the wrong flag for All users entries.
            using var approved = RootFor(scope).OpenSubKey(approvedPath);

            foreach (var file in Directory.EnumerateFiles(path))
            {
                var name = Path.GetFileName(file);

                // desktop.ini is a folder-metadata file, not a startup entry.
                if (name.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)) continue;
                var attributes = File.GetAttributes(file);
                if (attributes.HasFlag(FileAttributes.Hidden) || attributes.HasFlag(FileAttributes.System)) continue;

                var enabled = IsApprovedEnabled(approved, name);
                items.Add(new StartupItem(
                    $"folder:{scope}:{name}",
                    Path.GetFileNameWithoutExtension(name),
                    file,
                    "Startup folder",
                    scope,
                    enabled,
                    true,
                    approvedPath,
                    name,
                    file));
            }
        }
        catch
        {
            // Missing startup folder is normal on stripped systems.
        }
    }

    private static RegistryKey RootFor(string scope) =>
        scope == "User" ? Registry.CurrentUser : Registry.LocalMachine;

    private static bool IsApprovedEnabled(RegistryKey? approved, string name)
    {
        try
        {
            if (approved?.GetValue(name) is not byte[] bytes || bytes.Length == 0) return true;
            // 0x02 = enabled by user, 0x03 = disabled by user, 0x06 = disabled by policy.
            return bytes[0] is not (0x03 or 0x06 or 0x07);
        }
        catch
        {
            return true;
        }
    }

    public bool SetEnabled(StartupItem item, bool enabled)
    {
        try
        {
            using var key = RootFor(item.Scope).CreateSubKey(item.ApprovedKey, true);

            if (enabled)
            {
                key.DeleteValue(item.ApprovedName, throwOnMissingValue: false);
            }
            else
            {
                var blob = new byte[12];
                blob[0] = 0x03;
                key.SetValue(item.ApprovedName, blob, RegistryValueKind.Binary);
            }
            return true;
        }
        catch
        {
            return false;
        }
    }

    public StartupBackup CreateBackup()
    {
        var list = new List<StartupBackupItem>();
        foreach (var item in Read())
        {
            string? hex = null;
            try
            {
                using var key = RootFor(item.Scope).OpenSubKey(item.ApprovedKey);
                if (key?.GetValue(item.ApprovedName) is byte[] bytes) hex = Convert.ToHexString(bytes);
            }
            catch
            {
                // Leave the raw value out; the enabled flag is still restored.
            }

            list.Add(new StartupBackupItem(item.ApprovedKey, item.ApprovedName, hex, item.IsEnabled, item.Scope));
        }
        return new StartupBackup(DateTimeOffset.Now, list);
    }

    public string SaveBackup(string directory)
    {
        Directory.CreateDirectory(directory);
        var backup = CreateBackup();
        var file = Path.Combine(directory, $"startup-{DateTime.Now:yyyyMMdd-HHmmss}.json");
        File.WriteAllText(file, JsonSerializer.Serialize(backup, new JsonSerializerOptions { WriteIndented = true }));
        return file;
    }

    public int RestoreBackup(StartupBackup backup)
    {
        var restored = 0;
        foreach (var item in backup.Items)
        {
            try
            {
                // New backups record the scope, so a common-startup entry goes back to HKLM.
                // Older backups have no scope: try both hives and use whichever key exists.
                var hives = string.IsNullOrWhiteSpace(item.Scope)
                    ? new[] { Registry.CurrentUser, Registry.LocalMachine }
                    : new[] { RootFor(item.Scope) };

                foreach (var hive in hives)
                {
                    using var key = hive.OpenSubKey(item.ApprovedKey, true);
                    if (key is null) continue;
                    if (item.RawHex is not null)
                        key.SetValue(item.ApprovedName, Convert.FromHexString(item.RawHex), RegistryValueKind.Binary);
                    else
                        key.DeleteValue(item.ApprovedName, throwOnMissingValue: false);
                    restored++;
                    break;
                }
            }
            catch
            {
                // Keep restoring the rest.
            }
        }
        return restored;
    }

    private static string DescribeCommand(string command)
    {
        if (string.IsNullOrWhiteSpace(command)) return "No command recorded";
        var trimmed = command.Trim();
        var exe = trimmed.StartsWith('"')
            ? trimmed.Split('"', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault()
            : trimmed.Split(' ').FirstOrDefault();
        return exe ?? trimmed;
    }
}
