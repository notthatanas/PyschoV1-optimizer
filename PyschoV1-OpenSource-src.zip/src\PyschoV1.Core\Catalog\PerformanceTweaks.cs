using PyschoV1.Core.Tweaks;

namespace PyschoV1.Core.Catalog;

internal static class PerformanceTweaks
{
    internal static readonly Guid HighPerformancePlan = new("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c");

    internal static IEnumerable<Tweak> All() => new[]
    {
        new Tweak
        {
            Id = "perf.power.high",
            Title = "High performance power plan",
            Summary = "Keeps the CPU at full clocks instead of parking cores.",
            Detail = "Switches the active scheme so the processor never scales down. Laptops run warmer and drain faster on battery.",
            Module = TweakModule.Performance,
            Category = "Power",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[] { new PowerPlanOp(HighPerformancePlan, "High performance") }
        },
        new Tweak
        {
            Id = "perf.gamemode",
            Title = "Game Mode",
            Summary = "Gives the foreground game CPU and GPU priority.",
            Module = TweakModule.Performance,
            Category = "Gaming",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\GameBar", "AllowAutoGameMode", 1),
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\GameBar", "AutoGameModeEnabled", 1)
            }
        },
        new Tweak
        {
            Id = "perf.gamedvr",
            Title = "Disable Game DVR background recording",
            Summary = "Stops Xbox Game Bar recording the last few minutes in the background.",
            Detail = "Frees the encoder and disk writes Game DVR uses while gaming. Game Bar screenshots still work; capture through the overlay is off.",
            Module = TweakModule.Performance,
            Category = "Gaming",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"System\GameConfigStore", "GameDVR_Enabled", 0),
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0)
            }
        },
        new Tweak
        {
            Id = "perf.mmcss",
            Title = "Tune multimedia scheduling for games",
            Summary = "Reserves more CPU for the foreground game instead of background tasks.",
            Detail = "Lowers SystemResponsiveness from the 20% desktop default to 10%. Microsoft documents this value for multimedia workloads.",
            Module = TweakModule.Performance,
            Category = "Gaming",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                    "SystemResponsiveness", 10)
            }
        },
        new Tweak
        {
            Id = "perf.hags",
            Title = "Hardware-accelerated GPU scheduling",
            Summary = "Lets the GPU manage its own memory queue. Needs a reboot.",
            Detail = "Reduces CPU overhead in GPU-heavy titles. Requires a WDDM 2.7 driver; older cards silently ignore it.",
            Module = TweakModule.Performance,
            Category = "Graphics",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Platforms = new[] { "10", "11" },
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", 2)
            }
        },
        new Tweak
        {
            Id = "perf.visualfx",
            Title = "Trim window animations",
            Summary = "Sets Windows to best-performance visual effects.",
            Module = TweakModule.Performance,
            Category = "Explorer",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", "VisualFXSetting", 2)
            }
        },
        new Tweak
        {
            Id = "perf.transparency",
            Title = "Disable transparency effects",
            Summary = "Removes acrylic blur, the biggest idle GPU cost on the desktop.",
            Module = TweakModule.Performance,
            Category = "Explorer",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", 0)
            }
        },
        new Tweak
        {
            Id = "perf.widgets",
            Title = "Disable the Widgets panel",
            Summary = "Removes the taskbar Widgets feed and its background content updates.",
            Detail = "Windows 11 only. The weather icon on the taskbar disappears; the rest of the taskbar is untouched.",
            Module = TweakModule.Performance,
            Category = "Explorer",
            Risk = RiskLevel.Safe,
            Platforms = new[] { "11" },
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "TaskbarDa", 0)
            }
        },
        new Tweak
        {
            Id = "perf.menudelay",
            Title = "Remove menu delay",
            Summary = "Menus open instantly instead of after a 400 ms wait.",
            Module = TweakModule.Performance,
            Category = "Explorer",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Control Panel\Desktop", "MenuShowDelay", "0", RegistryKind.String)
            }
        },
        new Tweak
        {
            Id = "perf.startupdelay",
            Title = "Remove startup app delay",
            Summary = "Launches startup entries immediately at sign-in.",
            Module = TweakModule.Performance,
            Category = "Boot",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize", "StartupDelayInMSec", 0)
            }
        },
        new Tweak
        {
            Id = "perf.bgapps",
            Title = "Throttle background apps",
            Summary = "Stops UWP apps from running and updating in the background.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications", "GlobalUserDisabled", 1)
            }
        },
        new Tweak
        {
            Id = "perf.deliveryopt",
            Title = "Stop Delivery Optimization peer uploads",
            Summary = "Downloads updates from Microsoft without uploading pieces to other PCs.",
            Detail = "Restricts Delivery Optimization to HTTP. Saves upload bandwidth and background disk activity on metered or shared connections.",
            Module = TweakModule.Performance,
            Category = "Network",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization", "DODownloadMode", 1)
            }
        },
        new Tweak
        {
            Id = "perf.netthrottle",
            Title = "Remove network throttling cap",
            Summary = "Lets the network stack use its full budget during multimedia playback.",
            Detail = "Sets NetworkThrottlingIndex to unlimited (0xFFFFFFFF). A classic low-latency tweak; it can raise CPU use on very fast links.",
            Module = TweakModule.Performance,
            Category = "Network",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                    "NetworkThrottlingIndex", uint.MaxValue)
            }
        },
        new Tweak
        {
            Id = "perf.priority",
            Title = "Favour foreground programs",
            Summary = "Tunes the scheduler quantum so the active window gets longer slices.",
            Detail = "Win32PrioritySeparation = 38 (hex 26) is the classic foreground-boost value. Makes a visible difference in single-threaded games.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SYSTEM\CurrentControlSet\Control\PriorityControl", "Win32PrioritySeparation", 38)
            }
        },
        new Tweak
        {
            Id = "perf.sysmain",
            Title = "Disable SysMain (Superfetch)",
            Summary = "Stops the prefetch service on SSD-only machines.",
            Detail = "Free on memory and disk I/O on SSDs. Leave it enabled on spinning disks or the machine will feel slower.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("SysMain", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.wsearch",
            Title = "Disable Windows Search indexing",
            Summary = "Stops the indexer. Start-menu file search becomes slower.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("WSearch", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.powerthrottling",
            Title = "Disable power throttling",
            Summary = "Stops Windows from throttling background processes.",
            Module = TweakModule.Performance,
            Category = "Power",
            Risk = RiskLevel.Advanced,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "PowerThrottlingOff", 1)
            }
        },
        new Tweak
        {
            Id = "perf.storagesense",
            Title = "Automatic Storage Sense",
            Summary = "Cleans temp files automatically when disk space runs low.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser,
                    @"Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy", "01", 1)
            }
        },
        new Tweak
        {
            Id = "perf.updaterestart",
            Title = "Do not auto-restart for updates",
            Summary = "Windows waits for you to restart instead of rebooting on its own.",
            Detail = "Applies the documented AU policy. Security updates still install; only the automatic reboot is deferred.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU",
                    "NoAutoRebootWithLoggedOnUsers", 1)
            }
        },
        new Tweak
        {
            Id = "perf.mousehover",
            Title = "Faster tooltip delay",
            Summary = "Drops the hover delay from 400 ms to 100 ms.",
            Module = TweakModule.Performance,
            Category = "Explorer",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Control Panel\Mouse", "MouseHoverTime", "100", RegistryKind.String)
            }
        },
        new Tweak
        {
            Id = "perf.mouseaccel",
            Title = "Disable mouse acceleration",
            Summary = "Makes pointer movement 1:1 instead of applying Windows' acceleration curve.",
            Detail = "Clears the classic 'Enhance pointer precision' values. Aim is predictable in games and design work; some desktop users prefer the accelerated feel, and every value is restored on undo.",
            Module = TweakModule.Performance,
            Category = "Gaming",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.CurrentUser, @"Control Panel\Mouse", "MouseSpeed", "0", RegistryKind.String),
                new RegistryValueOp(Hive.CurrentUser, @"Control Panel\Mouse", "MouseThreshold1", "0", RegistryKind.String),
                new RegistryValueOp(Hive.CurrentUser, @"Control Panel\Mouse", "MouseThreshold2", "0", RegistryKind.String)
            }
        },
        new Tweak
        {
            Id = "perf.edgebackground",
            Title = "Stop Edge background work",
            Summary = "Edge stops preloading at sign-in and running extensions after you close it.",
            Detail = "Two documented Edge policies: BackgroundModeEnabled and StartupBoostEnabled. Edge restarts to pick them up; your browsing data and extensions are untouched.",
            Module = TweakModule.Performance,
            Category = "Browsers",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Edge", "BackgroundModeEnabled", 0),
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Edge", "StartupBoostEnabled", 0)
            }
        },
        new Tweak
        {
            Id = "perf.registrybackup",
            Title = "Enable weekly registry backups",
            Summary = "Windows saves a copy of the registry every week as a recovery net.",
            Detail = "Windows 10 stopped taking the automatic weekly registry backup by default; this documented Configuration Manager value turns it back on. Costs a few megabytes of disk per week and changes no runtime behaviour.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager",
                    "EnablePeriodicBackup", 1)
            }
        },
        new Tweak
        {
            Id = "perf.verbose",
            Title = "Show detailed startup messages",
            Summary = "Sign-in and shutdown report exactly which step Windows is on.",
            Detail = "VerboseStatus replaces 'Preparing Windows' with the real operation. Purely informational; nothing is disabled or sped up by it.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Safe,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "VerboseStatus", 1)
            }
        },
        new Tweak
        {
            Id = "perf.wudrivers",
            Title = "Stop Windows Update delivering drivers",
            Summary = "Windows Update no longer pushes driver updates; you pick them.",
            Detail = "Applies the documented ExcludeWUDriversInQualityUpdate policy. Security and feature updates still install — only driver packages are skipped. Keep GPU and chipset drivers current yourself, or leave this off.",
            Module = TweakModule.Performance,
            Category = "System",
            Risk = RiskLevel.Caution,
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine,
                    @"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate",
                    "ExcludeWUDriversInQualityUpdate", 1)
            }
        },
        new Tweak
        {
            Id = "perf.spooler",
            Title = "Disable the Print Spooler service",
            Summary = "Print jobs are not queued. Printing stops until you switch it back on.",
            Detail = "Microsoft documents disabling Spooler on machines that never print — it removes a frequently targeted service. Printing, scan-to-folder through the spooler and print-to-PDF queues will not work while this is off. Undo restores the previous start mode.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Advanced,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("Spooler", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.mediasharing",
            Title = "Stop the Windows Media sharing service",
            Summary = "No DLNA streaming from this PC to TVs or consoles.",
            Detail = "WMPNetworkSvc advertises and serves your media library on the local network. If you never cast to a smart TV or console, it is idle weight; if you do, leave it on.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("WMPNetworkSvc", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.compatassist",
            Title = "Disable the Program Compatibility Assistant",
            Summary = "Stops Windows watching programs for compatibility problems.",
            Detail = "PCA only pops warnings and suggests fixes for old software. With it off, genuinely old programs may need their compatibility settings set by hand.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("PcaSvc", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.xboxnet",
            Title = "Disable the Xbox network service",
            Summary = "Xbox Live sign-in, achievements and social features stop; games keep running.",
            Detail = "Stops XboxNetApiSvc only — controller, accessory and game-save services are left alone. The Xbox app and Game Pass will not sign in while this is off.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("XboxNetApiSvc", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.sensors",
            Title = "Disable sensor monitoring",
            Summary = "Ambient-light brightness and auto-rotation stop reacting.",
            Detail = "The Sensor Monitoring Service drives auto-brightness and screen rotation on laptops and 2-in-1s. Desktops are unaffected. Undo restores the previous start mode.",
            Module = TweakModule.Performance,
            Category = "Services",
            Risk = RiskLevel.Caution,
            RequiresReboot = true,
            Ops = new TweakOp[] { new ServiceStartOp("SensrSvc", ServiceStart.Disabled) }
        },
        new Tweak
        {
            Id = "perf.feeds10",
            Title = "Hide the taskbar news and weather feed",
            Summary = "Removes the news and interests button from the Windows 10 taskbar.",
            Detail = "Windows 10 only — on Windows 11 the Widgets toggle covers the same slot. Applies the documented AllowNewsAndInterests policy; feeds never load again until it is undone.",
            Module = TweakModule.Performance,
            Category = "Explorer",
            Risk = RiskLevel.Safe,
            Platforms = new[] { "10" },
            Ops = new TweakOp[]
            {
                new RegistryValueOp(Hive.LocalMachine, @"SOFTWARE\Policies\Microsoft\Dsh", "AllowNewsAndInterests", 0)
            }
        }
    };
}
