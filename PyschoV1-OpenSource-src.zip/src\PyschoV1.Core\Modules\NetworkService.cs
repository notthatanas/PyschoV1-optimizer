using System.Net.NetworkInformation;
using Microsoft.Win32;

namespace PyschoV1.Core.Modules;

public sealed record AdapterInfo(
    string Id,
    string Name,
    string Description,
    string Kind,
    bool IsUp,
    string DnsSummary)
{
    public string StatusLabel => IsUp ? "Connected" : "Disconnected";
}

public sealed record DnsPreset(string Name, string V4, string V6, string Note)
{
    public string[] V4Servers => V4.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}

public sealed record PingSummary(bool Success, int Sent, int Received, double AverageMs, double MinMs, double MaxMs, string? Error)
{
    public double LossPercent => Sent == 0 ? 0 : (Sent - Received) * 100.0 / Sent;
}

/// <summary>DNS is written per adapter (both stacks) and can always be restored to DHCP-provided servers.</summary>
public sealed class NetworkService
{
    private const string Tcpip4 = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\";
    private const string Tcpip6 = @"SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\";

    public static readonly IReadOnlyList<DnsPreset> Presets = new[]
    {
        new DnsPreset("Cloudflare", "1.1.1.1,1.0.0.1", "2606:4700:4700::1111,2606:4700:4700::1001", "Fastest public resolver, no logging of IPs."),
        new DnsPreset("Quad9", "9.9.9.9,149.112.112.112", "2620:fe::fe,2620:fe::9", "Blocks known malware domains."),
        new DnsPreset("Google", "8.8.8.8,8.8.4.4", "2001:4860:4860::8888,2001:4860:4860::8844", "Reliable, widely peered."),
        new DnsPreset("AdGuard", "94.140.14.14,94.140.15.15", "2a10:50c0::ad1:ff,2a10:50c0::ad2:ff", "Filters ads and trackers at DNS level."),
        new DnsPreset("Control D", "76.76.2.0,76.76.10.0", "2606:1a40::,2606:1a40:1::", "Configurable filtering."),
        new DnsPreset("OpenDNS", "208.67.222.222,208.67.220.220", "2620:119:35::35,2620:119:53::53", "Family-safe option available.")
    };

    public IReadOnlyList<AdapterInfo> GetAdapters()
    {
        var list = new List<AdapterInfo>();
        foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
        {
            // Only real, user-facing links. Windows exposes light-weight filter drivers and
            // Wi-Fi Direct siblings as adapters; changing DNS on those does nothing useful.
            if (nic.NetworkInterfaceType is not (NetworkInterfaceType.Wireless80211
                or NetworkInterfaceType.Ethernet or NetworkInterfaceType.GigabitEthernet)) continue;

            if (IsPseudoAdapter(nic)) continue;

            var kind = nic.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 ? "Wi-Fi" : "Ethernet";

            var dns = ReadDns(nic.Id);
            list.Add(new AdapterInfo(
                nic.Id,
                nic.Name,
                nic.Description,
                kind,
                nic.OperationalStatus == OperationalStatus.Up,
                string.IsNullOrWhiteSpace(dns) ? "Automatic (DHCP)" : dns));
        }

        return list
            .GroupBy(a => a.Description, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .OrderByDescending(a => a.IsUp)
            .ThenBy(a => a.Kind == "Ethernet" ? 0 : 1)
            .ThenBy(a => a.Name)
            .ToList();
    }

    private static bool IsPseudoAdapter(NetworkInterface nic)
    {
        var markers = new[]
        {
            "QoS Packet Scheduler", "WFP", "Filter Driver", "Kernel Debugger", "Virtual",
            "Pseudo", "Loopback", "Teredo", "ISATAP", "Tunnel", "vEthernet", "Hyper-V",
            "Wi-Fi Direct", "Local Area Connection*"
        };

        return markers.Any(marker =>
            nic.Name.Contains(marker, StringComparison.OrdinalIgnoreCase) ||
            nic.Description.Contains(marker, StringComparison.OrdinalIgnoreCase));
    }

    public string ReadDns(string adapterId)
    {
        var id = Normalize(adapterId);
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(Tcpip4 + id);
            var v4 = key?.GetValue("NameServer") as string;
            if (!string.IsNullOrWhiteSpace(v4)) return v4;
        }
        catch
        {
            // Fall through to automatic.
        }
        return "";
    }

    public bool ApplyDns(string adapterId, DnsPreset? preset)
    {
        var id = Normalize(adapterId);
        try
        {
            if (preset is null)
            {
                Delete(Tcpip4 + id);
                Delete(Tcpip6 + id);
                FlushDns(out _);
                return true;
            }

            using (var key = Registry.LocalMachine.CreateSubKey(Tcpip4 + id, true))
                key.SetValue("NameServer", preset.V4, RegistryValueKind.String);

            try
            {
                using var key6 = Registry.LocalMachine.CreateSubKey(Tcpip6 + id, true);
                key6.SetValue("NameServer", preset.V6, RegistryValueKind.String);
            }
            catch
            {
                // Some adapters have no IPv6 interface key; IPv4 still applies.
            }

            FlushDns(out _);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static void Delete(string path)
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(path, true);
            key?.DeleteValue("NameServer", throwOnMissingValue: false);
        }
        catch
        {
            // Nothing to clear.
        }
    }

    private static string Normalize(string adapterId)
    {
        var id = adapterId.Trim();
        if (!id.StartsWith('{')) id = "{" + id;
        if (!id.EndsWith('}')) id += "}";
        return id;
    }

    public bool FlushDns(out string output)
    {
        try
        {
            using var process = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "ipconfig.exe",
                Arguments = "/flushdns",
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true
            });
            output = process?.StandardOutput.ReadToEnd().Trim() ?? "";
            process?.WaitForExit(6000);
            return true;
        }
        catch (Exception ex)
        {
            output = ex.Message;
            return false;
        }
    }

    public async Task<PingSummary> PingAsync(string host, int count = 4, CancellationToken token = default)
    {
        var sent = 0;
        var received = 0;
        var times = new List<double>();

        try
        {
            using var ping = new Ping();
            for (var i = 0; i < count; i++)
            {
                token.ThrowIfCancellationRequested();
                sent++;
                try
                {
                    var reply = await ping.SendPingAsync(host, 1500);
                    if (reply.Status == IPStatus.Success)
                    {
                        received++;
                        times.Add(reply.RoundtripTime);
                    }
                }
                catch
                {
                    // Counted as loss.
                }

                if (i < count - 1) await Task.Delay(180, token);
            }
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            return new PingSummary(false, sent, received, 0, 0, 0, ex.Message);
        }

        if (times.Count == 0)
            return new PingSummary(false, sent, received, 0, 0, 0, $"No reply from {host}.");

        return new PingSummary(true, sent, received,
            Math.Round(times.Average(), 1), times.Min(), times.Max(), null);
    }
}
