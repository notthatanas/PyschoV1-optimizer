# End-to-end check of the built setup, safe to run on a machine that already has
# Pyscho V1 installed: silently install into a scratch folder with no shortcuts,
# launch the installed exe, uninstall, and confirm everything is gone.
#
#   powershell -ExecutionPolicy Bypass -File installer\test-installer.ps1
#   powershell -ExecutionPolicy Bypass -File installer\test-installer.ps1 -SetupPath .\release\1.0.0\PyschoV1-Setup-1.0.0.exe
param(
    [string] $SetupPath
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repoRoot = Split-Path $PSScriptRoot -Parent
$releaseRoot = Join-Path $repoRoot 'release'
$scratch = Join-Path $repoRoot 'artifacts'
$target = Join-Path $scratch 'install-test'
$log = Join-Path $scratch 'install-log.txt'
$bench = Join-Path $scratch 'installed-bench.txt'

$setup = if ($SetupPath) {
    Get-Item -LiteralPath $SetupPath
} else {
    Get-ChildItem -LiteralPath $releaseRoot -Filter 'PyschoV1-Setup-*.exe' -Recurse -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
}
if (-not $setup) { throw "No setup executable found under $releaseRoot" }
if (-not (Test-Path -LiteralPath $scratch)) { New-Item -ItemType Directory -Path $scratch | Out-Null }

# Remove the previous test install, if any. A real installation elsewhere is untouched.
if (Test-Path -LiteralPath (Join-Path $target 'unins000.exe')) {
    $old = Start-Process -FilePath (Join-Path $target 'unins000.exe') `
        -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait -PassThru
    Write-Host "previous_test_uninstall_exit=$($old.ExitCode)"
}
if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
foreach ($stale in @($log, $bench)) {
    if (Test-Path -LiteralPath $stale) { Remove-Item -LiteralPath $stale -Force }
}

Write-Host "== install ($($setup.Name)) =="
$installArgs = @(
    '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/SP-',
    "/DIR=`"$target`"",
    '/NOICONS',
    '/TASKS=',
    "/LOG=`"$log`""
)
$proc = Start-Process -FilePath $setup.FullName -ArgumentList $installArgs -Wait -PassThru
Write-Host "installer_exit=$($proc.ExitCode)"
if ($proc.ExitCode -ne 0) {
    if (Test-Path -LiteralPath $log) { Get-Content -LiteralPath $log -Tail 30 }
    throw "Installer failed with exit code $($proc.ExitCode)"
}

$exe = Join-Path $target 'PyschoV1.exe'
$readme = Join-Path $target 'README.txt'
$uninst = Join-Path $target 'unins000.exe'
foreach ($required in @($exe, $readme, $uninst)) {
    if (-not (Test-Path -LiteralPath $required)) { throw "Missing installed file: $required" }
}
Write-Host 'installed files: ok'

$entry = Get-ChildItem 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall' |
    Where-Object {
        $_.GetValue('DisplayName') -eq 'Pyscho V1 Optimizer' -and
        ([string] $_.GetValue('InstallLocation')).TrimEnd('\') -ieq $target.TrimEnd('\')
    } |
    Select-Object -First 1
if (-not $entry) { throw 'The test install did not register an uninstall entry.' }
Write-Host "uninstall_entry=$($entry.PSChildName) version=$($entry.GetValue('DisplayVersion'))"
Write-Host "uninstall_string=$($entry.GetValue('UninstallString'))"

Write-Host '== launch the installed exe =='
$launch = Start-Process -FilePath $exe -ArgumentList ('--benchmark "{0}"' -f $bench) -Wait -PassThru
Write-Host "app_exit=$($launch.ExitCode)"
if ($launch.ExitCode -ne 0) { throw "Installed app exited with code $($launch.ExitCode)." }
if (-not (Test-Path -LiteralPath $bench)) { throw 'Installed app produced no benchmark output.' }
Get-Content -LiteralPath $bench

Write-Host '== uninstall =='
$uninstallProc = Start-Process -FilePath $uninst `
    -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait -PassThru
Write-Host "uninstaller_exit=$($uninstallProc.ExitCode)"
if ($uninstallProc.ExitCode -ne 0) { throw "Uninstaller failed with exit code $($uninstallProc.ExitCode)." }
Start-Sleep -Milliseconds 700

$leftovers = @()
if (Test-Path -LiteralPath $target) { $leftovers += $target }
$entryAfter = Get-ChildItem 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall' |
    Where-Object {
        $_.GetValue('DisplayName') -eq 'Pyscho V1 Optimizer' -and
        ([string] $_.GetValue('InstallLocation')).TrimEnd('\') -ieq $target.TrimEnd('\')
    }
if ($entryAfter) { $leftovers += 'uninstall registry entry' }
if ($leftovers.Count -gt 0) { throw ('Uninstall left behind: ' + ($leftovers -join ', ')) }
Write-Host 'uninstall clean: ok'
