using System.Windows.Controls;

namespace PyschoV1.App.Views;

public partial class CleanerView : UserControl
{
    public CleanerView() => InitializeComponent();
}

public partial class NetworkView : UserControl
{
    public NetworkView() => InitializeComponent();
}

public partial class ProfilesView : UserControl
{
    public ProfilesView() => InitializeComponent();
}

public partial class HistoryView : UserControl
{
    public HistoryView() => InitializeComponent();
}

public partial class SettingsView : UserControl
{
    public SettingsView() => InitializeComponent();
}
