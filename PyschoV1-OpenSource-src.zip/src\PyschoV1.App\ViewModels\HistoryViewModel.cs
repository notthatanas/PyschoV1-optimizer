using System.Collections.ObjectModel;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Safety;

namespace PyschoV1.App.ViewModels;

public sealed class HistoryRowViewModel
{
    public HistoryRowViewModel(JournalEntry entry) => Entry = entry;

    public JournalEntry Entry { get; }
    public string Title => Entry.Title;
    public string Module => Entry.Module;
    public string When => Entry.AppliedAt.LocalDateTime.ToString("dd MMM · HH:mm");
    public string Origin => Entry.Origin.StartsWith("preset:", StringComparison.Ordinal)
        ? $"preset · {Entry.Origin[7..]}"
        : Entry.Origin;
    public string Detail => string.Join(Environment.NewLine, Entry.Patches.Select(p => "• " + p.Describe()));
    public bool CanRevert => !Entry.Reverted;
    public string StatusText => Entry.Reverted ? "Reverted" : "Active";
}

public sealed class HistoryViewModel : ObservableObject
{
    private string _status = "";
    private int _activeCount;

    public HistoryViewModel()
    {
        RevertCommand = new AsyncRelayCommand<HistoryRowViewModel>(RevertAsync, row => row?.CanRevert == true);
        RevertAllCommand = new AsyncRelayCommand(RevertAllAsync, () => ActiveCount > 0);
        RefreshCommand = new RelayCommand(Load);

        AppServices.Journal.Changed += (_, _) => Load();
        Load();
    }

    public ObservableCollection<HistoryRowViewModel> Rows { get; } = new();

    public ICommand RevertCommand { get; }
    public ICommand RevertAllCommand { get; }
    public ICommand RefreshCommand { get; }

    public string Status { get => _status; private set => Set(ref _status, value); }

    public int ActiveCount
    {
        get => _activeCount;
        private set
        {
            if (!Set(ref _activeCount, value)) return;
            Raise(nameof(Summary));
            (RevertAllCommand as AsyncRelayCommand)?.RaiseCanExecuteChanged();
        }
    }

    public string Summary => Rows.Count == 0
        ? "No changes have been made yet."
        : $"{Rows.Count} recorded change{(Rows.Count == 1 ? "" : "s")} · {ActiveCount} still active";

    public bool IsEmpty => Rows.Count == 0;

    public void Load()
    {
        Rows.Clear();
        foreach (var entry in AppServices.Engine.Journal.ReadAll())
            Rows.Add(new HistoryRowViewModel(entry));

        ActiveCount = Rows.Count(r => r.CanRevert);
        Raise(nameof(Summary));
        Raise(nameof(IsEmpty));
        Status = $"Journal: {AppServices.Engine.Journal.Directory}";
    }

    private async Task RevertAsync(HistoryRowViewModel? row)
    {
        if (row is null) return;
        var result = await Task.Run(() => AppServices.Engine.Revert(row.Entry));
        Status = result.Success ? $"Reverted {row.Title}." : result.Error ?? "Revert failed.";
        AppServices.Shell?.ShowToast(Status, result.Success ? "info" : "error");
        AppServices.Journal.Notify();
    }

    private async Task RevertAllAsync()
    {
        var active = Rows.Where(r => r.CanRevert).Select(r => r.Entry).ToList();
        if (active.Count == 0) return;

        var reverted = 0;
        var failed = 0;

        foreach (var entry in active)
        {
            var result = await Task.Run(() => AppServices.Engine.Revert(entry));
            if (result.Success) reverted++;
            else failed++;
        }

        Status = failed == 0
            ? $"Reverted all {reverted} changes."
            : $"Reverted {reverted}, {failed} could not be undone.";
        AppServices.Shell?.ShowToast(Status, failed == 0 ? "success" : "error");
        AppServices.Journal.Notify();
    }
}
