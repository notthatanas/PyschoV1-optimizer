using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace PyschoV1.App.Converters;

/// <summary>Turns a resource key such as "IcoHome" into the geometry declared in Tokens.xaml.</summary>
public sealed class IconGeometryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is not string key) return Geometry.Empty;
        if (Application.Current?.TryFindResource(key) is Geometry geometry) return geometry;
        return Geometry.Empty;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
