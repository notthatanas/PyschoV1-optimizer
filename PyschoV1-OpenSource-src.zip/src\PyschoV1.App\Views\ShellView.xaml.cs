using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PyschoV1.App.Runtime;
using PyschoV1.App.ViewModels;

namespace PyschoV1.App.Views;

public partial class ShellView : UserControl
{
    private Window? _window;

    public ShellView()
    {
        InitializeComponent();
        DataContextChanged += OnDataContextChanged;
        Loaded += (_, _) =>
        {
            FocusPaletteIfOpen();
            PageScroll?.ScrollToTop();
        };
    }

    public void AttachWindow(Window window) => _window = window;

    private ShellViewModel? Vm => DataContext as ShellViewModel;

    private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (e.OldValue is ShellViewModel oldVm)
            oldVm.PropertyChanged -= OnVmPropertyChanged;

        if (e.NewValue is ShellViewModel newVm)
            newVm.PropertyChanged += OnVmPropertyChanged;
    }

    private void OnVmPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(ShellViewModel.PaletteOpen)) FocusPaletteIfOpen();

        // Let the new page measure first, then reset the scroll offset and play the transition.
        if (e.PropertyName == nameof(ShellViewModel.CurrentPage))
        {
            Dispatcher.BeginInvoke(new Action(PlayPageTransition), DispatcherPriority.Loaded);
        }

        if (e.PropertyName == nameof(ShellViewModel.CurrentTitle))
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (Motion.Enabled) Motion.FadeAndSlide(PageHeader, 8, 240);
            }), DispatcherPriority.Loaded);
        }
    }

    private void PlayPageTransition()
    {
        PageScroll?.ScrollToTop();
        if (PageHost is null) return;

        if (!Motion.Enabled)
        {
            PageHost.BeginAnimation(OpacityProperty, null);
            PageHost.Opacity = 1;
            if (PageHost.RenderTransform is TranslateTransform still) still.Y = 0;
            return;
        }

        PageHost.Opacity = 1;
        var translate = PageHost.RenderTransform as TranslateTransform;
        if (translate is null || translate.IsFrozen)
        {
            translate = new TranslateTransform();
            PageHost.RenderTransform = translate;
        }

        PageHost.BeginAnimation(OpacityProperty, Motion.Tween(0, 1, 200));
        translate.BeginAnimation(TranslateTransform.YProperty, Motion.Tween(14, 0, 280));
    }

    private void FocusPaletteIfOpen()
    {
        if (Vm?.PaletteOpen != true) return;
        Dispatcher.BeginInvoke(new Action(() =>
        {
            PaletteBox.Focus();
            Keyboard.Focus(PaletteBox);
        }));
    }

    // ---- title bar ----

    private void OnTitleBarMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (_window is null) return;
        if (e.ClickCount == 2)
        {
            ToggleMaximize();
            return;
        }

        if (e.ButtonState == MouseButtonState.Pressed) _window.DragMove();
    }

    private void OnMinimizeClick(object sender, RoutedEventArgs e)
    {
        if (_window is not null) _window.WindowState = WindowState.Minimized;
    }

    private void OnMaximizeClick(object sender, RoutedEventArgs e) => ToggleMaximize();

    private void OnCloseClick(object sender, RoutedEventArgs e) => _window?.Close();

    private void ToggleMaximize()
    {
        if (_window is null) return;
        _window.WindowState = _window.WindowState == WindowState.Maximized
            ? WindowState.Normal
            : WindowState.Maximized;
        ShowRestoreGlyph(_window.WindowState == WindowState.Maximized);
    }

    public void ShowRestoreGlyph(bool maximized)
    {
        if (MaxGlyph is null) return;
        MaxGlyph.Data = (Geometry)(Application.Current.TryFindResource(maximized ? "IcoRestore" : "IcoMax")
                                   ?? Geometry.Empty);
    }

    private void OnElevationClick(object sender, MouseButtonEventArgs e)
    {
        if (Vm?.IsElevated == true) return;
        Vm?.ElevateCommand.Execute(null);
    }

    // ---- palette ----

    private void OnPaletteBackdropClick(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is Grid) Vm?.ClosePaletteCommand.Execute(null);
    }

    private void OnPaletteKeyDown(object sender, KeyEventArgs e)
    {
        var vm = Vm;
        if (vm is null) return;

        switch (e.Key)
        {
            case Key.Escape:
                vm.ClosePaletteCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.Enter:
                vm.PaletteAcceptCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.Down:
                MoveSelection(vm, 1);
                e.Handled = true;
                break;

            case Key.Up:
                MoveSelection(vm, -1);
                e.Handled = true;
                break;
        }
    }

    private void MoveSelection(ShellViewModel vm, int delta)
    {
        if (vm.PaletteResults.Count == 0) return;
        var index = vm.PaletteSelection is null ? -1 : vm.PaletteResults.IndexOf(vm.PaletteSelection);
        var next = Math.Clamp(index + delta, 0, vm.PaletteResults.Count - 1);
        vm.PaletteSelection = vm.PaletteResults[next];
    }
}
