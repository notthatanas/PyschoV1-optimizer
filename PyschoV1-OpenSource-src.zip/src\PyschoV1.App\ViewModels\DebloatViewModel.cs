using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Modules;

namespace PyschoV1.App.ViewModels;

public sealed class AppxItemViewModel : ObservableObject
{
    private bool _selected;

    public AppxItemViewModel(AppxPackage package) => Package = package;

    public AppxPackage Package { get; }
    public string Name => Package.FriendlyName;
    public string PackageName => Package.Name;
    public string Publisher => string.IsNullOrWhiteSpace(Package.Publisher) ? "Unknown publisher" : Package.Publisher;
    public string Version => Package.Version;
    public bool IsProtected => Package.IsProtected;
    public string ProtectionLabel => Package.IsProtected ? "System" : "Removable";

    public bool IsSelected
    {
        get => _selected;
        set => Set(ref _selected, value);
    }
}

public sealed class DebloatViewModel : ObservableObject
{
    private string _search = "";
    private bool _loading;
    private string _status = "Loading installed packages…";
    private bool _showProtected = true;
    private int _selectedCount;

    public DebloatViewModel()
    {
        LoadCommand = new AsyncRelayCommand(LoadAsync);
        RemoveCommand = new AsyncRelayCommand(RemoveAsync, () => SelectedCount > 0 && !IsLoading);
        SelectAllCommand = new RelayCommand(SelectAll);
        ClearCommand = new RelayCommand(ClearSelection);
        RefreshCommand = new AsyncRelayCommand(LoadAsync);

        _ = LoadAsync();
    }

    public ObservableCollection<AppxItemViewModel> Items { get; } = new();
    public ObservableCollection<AppxItemViewModel> Visible { get; } = new();

    public ICommand LoadCommand { get; }
    public ICommand RefreshCommand { get; }
    public ICommand RemoveCommand { get; }
    public ICommand SelectAllCommand { get; }
    public ICommand ClearCommand { get; }

    public string Search
    {
        get => _search;
        set
        {
            if (Set(ref _search, value)) ApplyFilter();
        }
    }

    public bool ShowProtected
    {
        get => _showProtected;
        set
        {
            if (Set(ref _showProtected, value)) ApplyFilter();
        }
    }

    public bool IsLoading
    {
        get => _loading;
        private set
        {
            if (Set(ref _loading, value)) (RemoveCommand as AsyncRelayCommand)?.RaiseCanExecuteChanged();
        }
    }

    public string Status
    {
        get => _status;
        private set => Set(ref _status, value);
    }

    public int SelectedCount
    {
        get => _selectedCount;
        private set
        {
            if (!Set(ref _selectedCount, value)) return;
            Raise(nameof(SelectedText));
            (RemoveCommand as AsyncRelayCommand)?.RaiseCanExecuteChanged();
        }
    }

    public string SelectedText => SelectedCount == 0 ? "Nothing selected" : $"{SelectedCount} selected";

    private async Task LoadAsync()
    {
        IsLoading = true;
        Status = "Reading the package list from Windows…";
        try
        {
            var packages = await AppServices.Debloat.ListAsync();
            Items.Clear();
            foreach (var package in packages)
            {
                var vm = new AppxItemViewModel(package);
                vm.PropertyChanged += (_, args) =>
                {
                    if (args.PropertyName == nameof(AppxItemViewModel.IsSelected)) Recount();
                };
                Items.Add(vm);
            }

            ApplyFilter();
            Status = $"{Items.Count} removable apps found.";
        }
        catch (Exception ex)
        {
            Status = $"Could not read the package list: {ex.Message}";
            AppServices.ReportError(ex);
        }
        finally
        {
            IsLoading = false;
        }
    }

    private void ApplyFilter()
    {
        var query = _search.Trim();
        var filtered = Items
            .Where(i => _showProtected || !i.IsProtected)
            .Where(i => query.Length == 0 ||
                        i.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                        i.PackageName.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                        i.Publisher.Contains(query, StringComparison.OrdinalIgnoreCase))
            .ToList();

        Visible.Clear();
        foreach (var item in filtered) Visible.Add(item);
        Recount();
    }

    private void Recount() => SelectedCount = Items.Count(i => i.IsSelected);

    private void SelectAll()
    {
        foreach (var item in Visible.Where(i => !i.IsProtected)) item.IsSelected = true;
    }

    private void ClearSelection()
    {
        foreach (var item in Items) item.IsSelected = false;
    }

    private async Task RemoveAsync()
    {
        var targets = Items.Where(i => i.IsSelected && !i.IsProtected).Select(i => i.Package).ToList();
        if (targets.Count == 0) return;

        if (!AppServices.IsElevated)
        {
            AppServices.Shell?.ShowToast("Removing apps needs administrator rights.", "error");
            return;
        }

        var confirm = MessageBox.Show(
            $"Remove {targets.Count} app{(targets.Count == 1 ? "" : "s")} for the current user?\n\n" +
            "They can be reinstalled later from the Microsoft Store.",
            "Pyscho V1 — remove apps",
            MessageBoxButton.OKCancel, MessageBoxImage.Question);

        if (confirm != MessageBoxResult.OK) return;

        IsLoading = true;
        Status = $"Removing {targets.Count} packages…";
        try
        {
            var result = await AppServices.Debloat.RemoveAsync(targets);
            Status = result.Success
                ? $"Removed {result.Removed} package{(result.Removed == 1 ? "" : "s")}."
                : $"Removed {result.Removed}, {result.Errors.Count} failed.";
            AppServices.Shell?.ShowToast(Status, result.Success ? "success" : "error");
            await LoadAsync();
        }
        finally
        {
            IsLoading = false;
        }
    }
}
