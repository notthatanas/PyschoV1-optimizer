# Signs one or more PE files with an Authenticode certificate.
#
#   # certificate already in CurrentUser\My or LocalMachine\My:
#   $env:CODESIGN_CERT_THUMBPRINT = 'ABCDEF...'
#   powershell -File installer\sign.ps1 -Path dist\PyschoV1.exe, release\PyschoV1-Setup-1.0.0.exe
#
#   # or a PFX (do not put the password on the command line):
#   $env:CODESIGN_PFX_PATH = 'C:\keys\notThatanas.pfx'
#   $env:CODESIGN_PFX_PASSWORD = '...'
#
# A publicly trusted OV/EV certificate is required before SmartScreen can show
# notThatanas as the publisher on other people's PCs. A self-signed certificate
# only helps on machines where its root is explicitly trusted; -AllowUntrusted
# exists for pipeline tests, not for a release.
param(
    [Parameter(Mandatory, Position = 0)]
    [string[]] $Path,

    [string] $CertificateThumbprint = $env:CODESIGN_CERT_THUMBPRINT,
    [string] $PfxPath = $env:CODESIGN_PFX_PATH,
    [SecureString] $PfxPassword,
    [string] $TimestampUrl = 'http://timestamp.digicert.com',
    [switch] $SkipTimestamp,
    [switch] $AllowUntrusted
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$importedCerts = @()

function Resolve-SigningCertificate {
    param(
        [string] $Thumbprint,
        [string] $Pfx,
        [SecureString] $Password
    )

    if ($Thumbprint -and $Pfx) {
        throw 'Pass either -CertificateThumbprint or -PfxPath, not both.'
    }

    if ($Pfx) {
        if (-not (Test-Path -LiteralPath $Pfx)) { throw "PFX file not found: $Pfx" }
        if (-not $Password) {
            if ($env:CODESIGN_PFX_PASSWORD) {
                $Password = ConvertTo-SecureString $env:CODESIGN_PFX_PASSWORD -AsPlainText -Force
            }
            else {
                throw 'CODESIGN_PFX_PASSWORD is not set and no -PfxPassword was supplied.'
            }
        }

        $importArgs = @{
            FilePath          = $Pfx
            CertStoreLocation = 'Cert:\CurrentUser\My'
            Password          = $Password
        }
        $cert = Import-PfxCertificate @importArgs
        if (-not $cert) { throw "No certificate was imported from $Pfx" }
        $script:importedCerts += $cert
        if (-not $cert.HasPrivateKey) { throw "The certificate from $Pfx has no private key." }
        return $cert
    }

    if (-not $Thumbprint) { return $null }

    $normalized = ($Thumbprint -replace '\s', '').ToUpperInvariant()
    $stores = @('Cert:\CurrentUser\My', 'Cert:\LocalMachine\My')
    foreach ($store in $stores) {
        $found = Get-ChildItem -Path $store -ErrorAction SilentlyContinue |
            Where-Object { $_.Thumbprint -eq $normalized } |
            Select-Object -First 1
        if ($found) {
            if (-not $found.HasPrivateKey) { throw "Certificate $normalized has no private key in $store." }
            return $found
        }
    }

    throw "No code-signing certificate with thumbprint $normalized was found in CurrentUser\My or LocalMachine\My."
}

$cert = Resolve-SigningCertificate -Thumbprint $CertificateThumbprint -Pfx $PfxPath -Password $PfxPassword
if (-not $cert) {
    throw @'
No code-signing certificate is configured.

Set CODESIGN_CERT_THUMBPRINT to a certificate in the Windows certificate store, or set
CODESIGN_PFX_PATH and CODESIGN_PFX_PASSWORD to a PFX file. The certificate must have a private key.

A publicly trusted OV/EV code-signing certificate (or Azure Artifact Signing) is required for
SmartScreen to identify notThatanas on other PCs. A self-signed certificate does not do that.
'@
}

try {
    foreach ($item in $Path) {
        if (-not (Test-Path -LiteralPath $item)) { throw "File not found: $item" }
        $full = (Resolve-Path -LiteralPath $item).Path

        $signArgs = @{
            FilePath      = $full
            Certificate   = $cert
            HashAlgorithm = 'SHA256'
        }
        if (-not $SkipTimestamp) { $signArgs.TimestampServer = $TimestampUrl }

        Write-Host "Signing $full ..."
        $signature = Set-AuthenticodeSignature @signArgs

        if ($signature.Status -eq 'Valid') {
            # trusted chain completed
        }
        elseif ($AllowUntrusted -and $signature.SignerCertificate) {
            Write-Warning "Signature is present but the certificate chain is not trusted: $($signature.StatusMessage)"
        }
        else {
            throw "Signing failed for $full`: $($signature.Status) - $($signature.StatusMessage)"
        }

        if (-not $SkipTimestamp -and -not $signature.TimeStamperCertificate) {
            throw "Signature for $full has no timestamp. Check network access to $TimestampUrl or use -SkipTimestamp for a local test."
        }

        $verify = Get-AuthenticodeSignature -FilePath $full
        $signer = if ($verify.SignerCertificate) { $verify.SignerCertificate.Subject } else { '<none>' }
        $stamp = if ($verify.TimeStamperCertificate) { 'timestamped' } else { 'no timestamp' }
        Write-Host "Signed: $full"
        Write-Host "  signer=$signer"
        Write-Host "  status=$($verify.Status) ($stamp)"
    }
}
finally {
    foreach ($imported in $importedCerts) {
        $storePath = "Cert:\CurrentUser\My\$($imported.Thumbprint)"
        if (Test-Path -LiteralPath $storePath) {
            Remove-Item -LiteralPath $storePath -Force -ErrorAction SilentlyContinue
        }
    }
}
