using System.Collections.ObjectModel;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.ViewModels;

public sealed class TweakItemViewModel : ObservableObject
{
    private bool _isOn;
    private bool _busy;
    private bool _expanded;
    private bool _suppress;
    private bool _managed;
    private bool _canToggle = true;
    private string _toggleHint = "";
    private string? _note;
    private string? _error;

    public TweakItemViewModel(Tweak tweak, HashSet<string>? managed = null)
    {
        Tweak = tweak;
        ToggleExpandedCommand = new RelayCommand(() => IsExpanded = !IsExpanded);
        Refresh(managed);
    }

    public Tweak Tweak { get; }

    public string Id => Tweak.Id;
    public string Title => Tweak.Title;
    public string Summary => Tweak.Summary;
    public string? Detail => Tweak.Detail;
    public string Category => Tweak.Category ?? "General";
    public RiskLevel Risk => Tweak.Risk;
    public string RiskLabel => Tweak.RiskLabel;
    public bool RequiresReboot => Tweak.RequiresReboot;

    public ICommand ToggleExpandedCommand { get; }

    public ObservableCollection<PlanStep> Plan { get; } = new();

    public bool IsOn
    {
        get => _isOn;
        set
        {
            // The value must always be stored; suppression only stops the write-back to Windows.
            if (!Set(ref _isOn, value)) return;
            if (_suppress) return;
            _ = ApplyAsync(value);
        }
    }

    public string ExpandLabel => IsExpanded ? "Hide details" : "What changes";

    public bool IsExpanded
    {
        get => _expanded;
        set
        {
            if (!Set(ref _expanded, value)) return;
            Raise(nameof(ExpandLabel));
            if (value) RefreshPlan();
        }
    }

    public bool IsBusy
    {
        get => _busy;
        private set
        {
            if (Set(ref _busy, value)) Raise(nameof(CanInteract));
        }
    }

    public string? Note
    {
        get => _note;
        private set => Set(ref _note, value);
    }

    public string? Error
    {
        get => _error;
        private set
        {
            if (Set(ref _error, value)) Raise(nameof(HasError));
        }
    }

    public bool HasError => !string.IsNullOrEmpty(_error);

    public TweakState State { get; private set; }

    /// <summary>True when the current on-state came from a Pyscho V1 journal entry.</summary>
    public bool IsManaged
    {
        get => _managed;
        private set => Set(ref _managed, value);
    }

    /// <summary>
    /// Windows state that Pyscho V1 did not set. It is shown as on, but the switch is disabled:
    /// there is no captured previous value, so turning it off here would be a lie.
    /// </summary>
    public bool IsPreExisting => State == TweakState.On && !IsManaged;

    public bool CanToggle
    {
        get => _canToggle;
        private set
        {
            if (Set(ref _canToggle, value)) Raise(nameof(CanInteract));
        }
    }

    /// <summary>The switch is only clickable when it is supported, owned by the app and not mid-write.</summary>
    public bool CanInteract => CanToggle && !IsBusy;

    public string ToggleHint
    {
        get => _toggleHint;
        private set => Set(ref _toggleHint, value);
    }

    public string StateLabel => State switch
    {
        TweakState.On => IsManaged ? "Applied" : "On this PC",
        TweakState.Partial => "Partial",
        TweakState.Unavailable => "Not available",
        _ => "Off"
    };

    /// <summary>Re-reads the machine. Called after every change and whenever the page is shown.</summary>
    public void Refresh(HashSet<string>? managed = null)
    {
        State = AppServices.Engine.GetState(Tweak);

        if (State == TweakState.On && managed is null)
        {
            managed = AppServices.Engine.Journal.ReadAll()
                .Where(entry => !entry.Reverted)
                .Select(entry => entry.TweakId)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
        }

        IsManaged = managed?.Contains(Id) == true;
        CanToggle = State switch
        {
            TweakState.Unavailable => false,
            TweakState.On => IsManaged,
            _ => true
        };

        ToggleHint = State switch
        {
            TweakState.Unavailable => "Windows does not expose this setting on this PC.",
            TweakState.On when !IsManaged =>
                "This PC already had this setting on before Pyscho V1. The app did not change it, so the switch stays read-only; use Windows Settings if you want it off.",
            TweakState.On => "Applied by Pyscho V1. Turn off to restore the previous value.",
            TweakState.Partial => "Some values already match. Turn on to complete the remaining changes.",
            _ => "Turn on to apply through the journalled engine."
        };

        _suppress = true;
        IsOn = State == TweakState.On;
        _suppress = false;
        Raise(nameof(State));
        Raise(nameof(StateLabel));
        Raise(nameof(IsPreExisting));
        Raise(nameof(CanInteract));
        Raise(nameof(IsOn));
        if (IsExpanded) RefreshPlan();
    }

    private void RefreshPlan()
    {
        Plan.Clear();
        foreach (var step in AppServices.Engine.BuildPlan(Tweak)) Plan.Add(step);
    }

    private async Task ApplyAsync(bool desired)
    {
        if (!CanInteract || IsBusy)
        {
            Refresh();
            return;
        }

        IsBusy = true;
        Error = null;
        Note = null;

        try
        {
            if (AppServices.Settings.DryRun)
            {
                var preview = AppServices.Engine.BuildPlan(Tweak);
                Note = $"Preview only — {preview.Count} change{(preview.Count == 1 ? "" : "s")} would be written. Turn off preview mode in Settings to apply.";
                return;
            }

            if (!AppServices.IsElevated)
            {
                Error = "Administrator rights are required. Use the button in the title bar to relaunch elevated.";
                return;
            }

            if (desired)
            {
                if (AppServices.Settings.ConfirmAdvanced && Tweak.Risk == RiskLevel.Advanced)
                {
                    var confirm = System.Windows.MessageBox.Show(
                        $"{Title}\n\n{Tweak.Summary}\n\nThis is marked Advanced. Apply it anyway?",
                        "Pyscho V1 — advanced tweak",
                        System.Windows.MessageBoxButton.OKCancel,
                        System.Windows.MessageBoxImage.Warning);

                    if (confirm != System.Windows.MessageBoxResult.OK) return;
                }

                var restoreNote = await AppServices.EnsureRestorePointAsync();
                if (!string.IsNullOrEmpty(restoreNote)) AppServices.Shell?.ShowToast(restoreNote, "info");

                // Service stops and powercfg can take seconds; keep the window responsive.
                var result = await Task.Run(() => AppServices.Engine.Apply(Tweak));
                if (!result.Success)
                {
                    Error = result.Error;
                    AppServices.Shell?.ShowToast(result.Error ?? "The change failed.", "error");
                }
                else
                {
                    Note = Tweak.RequiresReboot ? "Applied. Reboot to take effect." : "Applied.";
                    AppServices.Shell?.ShowToast($"Applied: {Title}", "success");
                    AppServices.Journal.Notify();
                }
            }
            else
            {
                var entry = await Task.Run(() => AppServices.Engine.Journal.ReadAll()
                    .FirstOrDefault(e => e.TweakId == Tweak.Id && !e.Reverted));

                if (entry is null)
                {
                    Note = "This tweak was already off, nothing to revert.";
                }
                else
                {
                    var result = await Task.Run(() => AppServices.Engine.Revert(entry));
                    if (!result.Success)
                    {
                        Error = result.Error;
                        AppServices.Shell?.ShowToast(result.Error ?? "Revert failed.", "error");
                    }
                    else
                    {
                        Note = "Reverted to the previous value.";
                        AppServices.Shell?.ShowToast($"Reverted: {Title}", "info");
                        AppServices.Journal.Notify();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Error = "Could not complete the change: " + ex.Message;
            AppServices.ReportError(ex);
            AppServices.Shell?.ShowToast(Error, "error");
        }
        finally
        {
            IsBusy = false;
            Refresh();
        }
    }
}

public sealed class TweakGroup
{
    public TweakGroup(string name, IEnumerable<TweakItemViewModel> items)
    {
        Name = name;
        Items = new ObservableCollection<TweakItemViewModel>(items);
    }

    public string Name { get; }
    public ObservableCollection<TweakItemViewModel> Items { get; }
}
