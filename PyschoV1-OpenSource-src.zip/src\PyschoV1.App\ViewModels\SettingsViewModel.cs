using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Settings;

namespace PyschoV1.App.ViewModels;

public sealed class SettingsViewModel : ObservableObject
{
    private const string DiscordUrl = "https://discord.gg/jVMShPrxa";
    private const string InstagramUrl = "https://www.instagram.com/yesthatanas?xtok=MWViaDdpemRtcXlnMA==";

    private readonly AppSettings _settings = AppServices.Settings;
    private bool _elevated = AppServices.IsElevated;

    public SettingsViewModel()
    {
        ElevateCommand = new RelayCommand(AppServices.RequestElevation);
        OpenJournalCommand = new RelayCommand(() => OpenFolder(AppServices.Engine.Journal.Directory));
        OpenSettingsFolderCommand = new RelayCommand(() => OpenFolder(Path.GetDirectoryName(AppSettings.SettingsPath) ?? ""));
        OpenDiscordCommand = new RelayCommand(() => OpenUrl(DiscordUrl));
        OpenInstagramCommand = new RelayCommand(() => OpenUrl(InstagramUrl));
        RefreshCommand = new RelayCommand(() => { _elevated = AppServices.IsElevated; RaiseAll(); });
    }

    public ICommand ElevateCommand { get; }
    public ICommand OpenJournalCommand { get; }
    public ICommand OpenSettingsFolderCommand { get; }
    public ICommand OpenDiscordCommand { get; }
    public ICommand OpenInstagramCommand { get; }
    public ICommand RefreshCommand { get; }

    public string Author => "notThatanas";

    public bool CreateRestorePoint
    {
        get => _settings.CreateRestorePoint;
        set
        {
            if (_settings.CreateRestorePoint == value) return;
            _settings.CreateRestorePoint = value;
            _settings.Save();
            Raise();
        }
    }

    public bool DryRun
    {
        get => _settings.DryRun;
        set
        {
            if (_settings.DryRun == value) return;
            _settings.DryRun = value;
            _settings.Save();
            Raise();
            AppServices.Shell?.ShowToast(value
                ? "Preview mode on — nothing will be written."
                : "Preview mode off — changes apply immediately.", value ? "info" : "success");
        }
    }

    public bool ConfirmAdvanced
    {
        get => _settings.ConfirmAdvanced;
        set
        {
            if (_settings.ConfirmAdvanced == value) return;
            _settings.ConfirmAdvanced = value;
            _settings.Save();
            Raise();
        }
    }

    public bool ReduceMotion
    {
        get => _settings.ReduceMotion;
        set
        {
            if (_settings.ReduceMotion == value) return;
            _settings.ReduceMotion = value;
            _settings.Save();
            Raise();
            AppServices.Shell?.ShowToast(value
                ? "Reduce motion on — page and card animations are off."
                : "Animations on.", "info");
        }
    }

    public bool IsElevated => _elevated;

    public string ElevationText => _elevated
        ? "Running as administrator"
        : "Running as a standard user";

    public string ElevationHint => _elevated
        ? "System-wide tweaks, services and DNS can be changed."
        : "Relaunch elevated to write system settings. Browsing and previews work either way.";

    public string Version =>
        Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0";

    public string SettingsPath => AppSettings.SettingsPath;

    public string JournalPath => AppServices.Engine.Journal.Directory;

    public string ModeText => AppSettings.IsPortable
        ? "Portable — settings live next to the executable"
        : "Installed — settings live in %AppData%\\PyschoV1";

    public string PlatformText => $"Windows build {AppServices.WindowsBuild} · {AppServices.Specs.OsName}";

    public string JournalCount => $"{AppServices.Engine.Journal.ReadAll().Count} entries recorded";

    private static void OpenFolder(string path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            Directory.CreateDirectory(path);
            Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
        }
    }

    private static void OpenUrl(string url)
    {
        try
        {
            Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            AppServices.ReportError(ex);
        }
    }
}
