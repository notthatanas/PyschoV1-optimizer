using System.Runtime.InteropServices;

namespace PyschoV1.Core.Safety;

public readonly record struct RestorePointResult(bool Created, string Message)
{
    public static RestorePointResult Skipped(string why) => new(false, why);
    public static RestorePointResult Ok(long sequence) => new(true, $"Restore point #{sequence} created.");
}

/// <summary>
/// Synchronous restore point via srclient.dll. Deliberately not PowerShell Checkpoint-Computer,
/// which blocks for 30+ seconds and fails silently on many systems.
/// </summary>
public static class RestorePoint
{
    private const int BeginSystemChange = 100;
    private const int ModifySettings = 12;
    private const int ApplicationInstall = 0;

    public static RestorePointResult Create(string description)
    {
        var spec = new RestorePointInfo
        {
            EventType = BeginSystemChange,
            RestorePointType = ModifySettings,
            Description = $"{description} ({DateTime.Now:HH:mm})"
        };

        try
        {
            if (!SRSetRestorePointW(ref spec, out var status))
            {
                var error = Marshal.GetLastWin32Error();
                return RestorePointResult.Skipped(error switch
                {
                    0 => "System Restore is disabled for this drive, so no checkpoint was taken.",
                    5 => "Access denied — system restore needs administrator rights.",
                    _ => $"System Restore refused the request (error {error})."
                });
            }
            return RestorePointResult.Ok(status.SequenceNumber);
        }
        catch (DllNotFoundException)
        {
            return RestorePointResult.Skipped("System Restore is unavailable on this Windows edition.");
        }
        catch (Exception ex)
        {
            return RestorePointResult.Skipped($"Could not create a restore point: {ex.Message}");
        }
    }

    /// <summary>True when the drive holding Windows has restore protection switched on.</summary>
    public static bool IsEnabled()
    {
        try
        {
            using var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore");
            var disable = key?.GetValue("DisableSR");
            return disable is null || Convert.ToInt32(disable) == 0;
        }
        catch
        {
            return false;
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct RestorePointInfo
    {
        public int EventType;
        public int RestorePointType;
        public long SequenceNumber;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string Description;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct StateManagerStatus
    {
        public int Status;
        public long SequenceNumber;
    }

    [DllImport("srclient.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SRSetRestorePointW(ref RestorePointInfo spec, out StateManagerStatus status);

    /// <summary>Kept for the advanced path: an install-class restore point before mass changes.</summary>
    public static RestorePointResult CreateInstallCheckpoint(string description)
    {
        var spec = new RestorePointInfo
        {
            EventType = BeginSystemChange,
            RestorePointType = ApplicationInstall,
            Description = description
        };
        try
        {
            return SRSetRestorePointW(ref spec, out var status)
                ? RestorePointResult.Ok(status.SequenceNumber)
                : RestorePointResult.Skipped($"System Restore refused (error {Marshal.GetLastWin32Error()}).");
        }
        catch (Exception ex)
        {
            return RestorePointResult.Skipped(ex.Message);
        }
    }
}
