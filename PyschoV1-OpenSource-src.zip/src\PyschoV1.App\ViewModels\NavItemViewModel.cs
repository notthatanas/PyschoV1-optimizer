using PyschoV1.App.Mvvm;

namespace PyschoV1.App.ViewModels;

public sealed class NavItemViewModel : ObservableObject
{
    private bool _isSelected;

    public NavItemViewModel(string key, string label, string icon, string description)
    {
        Key = key;
        Label = label;
        Icon = icon;
        Description = description;
    }

    public string Key { get; }
    public string Label { get; }
    public string Icon { get; }
    public string Description { get; }

    public bool IsSelected
    {
        get => _isSelected;
        set => Set(ref _isSelected, value);
    }
}

public sealed record PaletteResult(string Title, string Subtitle, string ModuleKey, string? TweakId, string Glyph);
