using System.Windows;
using System.Windows.Media;

namespace PyschoV1.App.Controls;

/// <summary>
/// Minimal polyline chart. Hand-drawn instead of a charting library: one control, no dependency,
/// no layout cost, and it redraws in a single OnRender pass.
/// </summary>
public sealed class Sparkline : FrameworkElement
{
    private static readonly Pen Baseline = CreateBaseline();
    private Pen? _strokePen;
    private Brush? _strokeBrush;

    public static readonly DependencyProperty ValuesProperty = DependencyProperty.Register(
        nameof(Values), typeof(IEnumerable<double>), typeof(Sparkline),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty StrokeProperty = DependencyProperty.Register(
        nameof(Stroke), typeof(Brush), typeof(Sparkline),
        new FrameworkPropertyMetadata(Brushes.MediumPurple, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty FillProperty = DependencyProperty.Register(
        nameof(Fill), typeof(Brush), typeof(Sparkline),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty MaximumProperty = DependencyProperty.Register(
        nameof(Maximum), typeof(double), typeof(Sparkline),
        new FrameworkPropertyMetadata(100.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty ShowBaselineProperty = DependencyProperty.Register(
        nameof(ShowBaseline), typeof(bool), typeof(Sparkline),
        new FrameworkPropertyMetadata(true, FrameworkPropertyMetadataOptions.AffectsRender));

    public IEnumerable<double>? Values
    {
        get => (IEnumerable<double>?)GetValue(ValuesProperty);
        set => SetValue(ValuesProperty, value);
    }

    public Brush Stroke
    {
        get => (Brush)GetValue(StrokeProperty);
        set => SetValue(StrokeProperty, value);
    }

    public Brush? Fill
    {
        get => (Brush?)GetValue(FillProperty);
        set => SetValue(FillProperty, value);
    }

    public double Maximum
    {
        get => (double)GetValue(MaximumProperty);
        set => SetValue(MaximumProperty, value);
    }

    public bool ShowBaseline
    {
        get => (bool)GetValue(ShowBaselineProperty);
        set => SetValue(ShowBaselineProperty, value);
    }

    protected override void OnRender(DrawingContext dc)
    {
        var width = ActualWidth;
        var height = ActualHeight;
        if (width < 4 || height < 4) return;

        var values = Values?.ToList() ?? new List<double>();
        if (values.Count < 2) return;

        var max = Math.Max(Maximum, values.Max());
        var step = width / (values.Count - 1);

        var geometry = new StreamGeometry();
        using (var ctx = geometry.Open())
        {
            var start = new Point(0, height - ToY(values[0], height, max));
            ctx.BeginFigure(start, isFilled: Fill is not null, isClosed: false);

            for (var i = 1; i < values.Count; i++)
                ctx.LineTo(new Point(i * step, height - ToY(values[i], height, max)), true, false);

            if (Fill is not null)
            {
                ctx.LineTo(new Point(width, height), true, false);
                ctx.LineTo(new Point(0, height), true, false);
            }
        }
        geometry.Freeze();

        if (Fill is not null) dc.DrawGeometry(Fill, null, geometry);

        if (_strokePen is null || !ReferenceEquals(_strokeBrush, Stroke))
        {
            _strokeBrush = Stroke;
            _strokePen = new Pen(Stroke, 1.6)
            {
                LineJoin = PenLineJoin.Round,
                StartLineCap = PenLineCap.Round,
                EndLineCap = PenLineCap.Round
            };
            _strokePen.Freeze();
        }

        dc.DrawGeometry(null, _strokePen, geometry);

        if (!ShowBaseline) return;
        dc.DrawLine(Baseline, new Point(0, height - 0.5), new Point(width, height - 0.5));
    }

    private static Pen CreateBaseline()
    {
        var brush = new SolidColorBrush(Color.FromArgb(0x20, 0xFF, 0xFF, 0xFF));
        brush.Freeze();
        var pen = new Pen(brush, 1);
        pen.Freeze();
        return pen;
    }

    private static double ToY(double value, double height, double max)
    {
        if (!double.IsFinite(value)) value = 0;
        var ratio = Math.Clamp(value / Math.Max(max, 0.001), 0, 1);
        return ratio * (height - 2);
    }
}
