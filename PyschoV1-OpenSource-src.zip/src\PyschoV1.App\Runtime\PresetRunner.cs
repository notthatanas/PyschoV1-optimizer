using PyschoV1.Core.Catalog;
using PyschoV1.Core.Engine;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.Runtime;

public sealed record PresetOutcome(int Applied, int AlreadyOn, int Failed, string Message, int Skipped = 0)
{
    public bool Success => Failed == 0;
}

public static class PresetRunner
{
    /// <summary>Applies only the tweaks that are not already active, through the journalled engine.</summary>
    public static async Task<PresetOutcome> ApplyAsync(Preset preset)
    {
        var engine = AppServices.Engine;

        var tweaks = preset.TweakIds
            .Select(TweakCatalog.Find)
            .Where(t => t is not null)
            .Select(t => t!)
            .Where(t => TweakEngine.SupportsPlatform(t, AppServices.WindowsBuild))
            .ToList();

        if (AppServices.Settings.DryRun)
        {
            var steps = tweaks.Sum(t => engine.BuildPlan(t).Count);
            return new PresetOutcome(0, 0, 0, $"Preview: {tweaks.Count} tweaks, {steps} changes would be written.");
        }

        if (!AppServices.IsElevated)
            return new PresetOutcome(0, 0, 0, "Administrator rights are required to apply a preset.");

        var restoreNote = await AppServices.EnsureRestorePointAsync();
        if (!string.IsNullOrEmpty(restoreNote)) AppServices.Shell?.ShowToast(restoreNote, "info");

        // Apply the whole preset off the UI thread: a service stop alone can take seconds.
        var (applied, already, skipped, failed, lastError) = await Task.Run(() =>
        {
            var appliedCount = 0;
            var alreadyCount = 0;
            var skippedCount = 0;
            var failedCount = 0;
            var error = "";

            foreach (var tweak in tweaks)
            {
                var state = engine.GetState(tweak);
                if (state == TweakState.On)
                {
                    alreadyCount++;
                    continue;
                }

                // An absent service or hidden policy cannot be evaluated. It is not a failed
                // change: the machine simply does not expose it, so leave it alone.
                if (state == TweakState.Unavailable)
                {
                    skippedCount++;
                    continue;
                }

                var result = engine.Apply(tweak, $"preset:{preset.Id}");
                if (result.Success) appliedCount++;
                else
                {
                    failedCount++;
                    error = result.Error ?? "";
                }
            }

            return (appliedCount, alreadyCount, skippedCount, failedCount, error);
        });

        AppServices.Journal.Notify();

        var details = new List<string>();
        if (already > 0) details.Add($"{already} already on");
        if (skipped > 0) details.Add($"{skipped} not available here");

        var message = failed == 0
            ? $"{preset.Name}: {applied} applied" +
              (details.Count == 0 ? "." : ", " + string.Join(", ", details) + ".")
            : $"{preset.Name}: {applied} applied, {failed} failed. {lastError}";

        return new PresetOutcome(applied, already, failed, message, skipped);
    }

    public static async Task<PresetOutcome> RevertAsync(Preset preset)
    {
        var engine = AppServices.Engine;
        if (!AppServices.IsElevated)
            return new PresetOutcome(0, 0, 0, "Administrator rights are required to undo a preset.");

        var ids = preset.TweakIds.ToHashSet();
        var entries = engine.Journal.ReadAll()
            .Where(e => !e.Reverted && (ids.Contains(e.TweakId) || e.Origin == $"preset:{preset.Id}"))
            .ToList();

        var (reverted, failed) = await Task.Run(() =>
        {
            var revertedCount = 0;
            var failedCount = 0;
            foreach (var entry in entries)
            {
                if (engine.Revert(entry).Success) revertedCount++;
                else failedCount++;
            }
            return (revertedCount, failedCount);
        });

        AppServices.Journal.Notify();
        return new PresetOutcome(reverted, 0, failed,
            failed == 0 ? $"Reverted {reverted} change{(reverted == 1 ? "" : "s")} from {preset.Name}."
                        : $"{failed} changes could not be reverted.");
    }
}
