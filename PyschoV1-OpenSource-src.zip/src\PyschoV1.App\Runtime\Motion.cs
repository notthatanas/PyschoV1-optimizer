using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace PyschoV1.App.Runtime;

/// <summary>
/// One place that decides whether motion is allowed and builds the short, GPU-friendly
/// animations the shell uses. Only opacity and render transforms are animated, so no animation
/// ever triggers a layout pass.
/// </summary>
public static class Motion
{
    /// <summary>Windows' own "Animation effects" setting plus the app's Reduce motion switch.</summary>
    public static bool Enabled
    {
        get
        {
            try
            {
                return !AppServices.Settings.ReduceMotion && SystemParameters.ClientAreaAnimation;
            }
            catch
            {
                return true;
            }
        }
    }

    /// <summary>A short ease-out tween that leaves the DP at its base value when it ends.</summary>
    public static DoubleAnimation Tween(
        double from,
        double to,
        double milliseconds,
        EasingMode easing = EasingMode.EaseOut)
    {
        var animation = new DoubleAnimation(from, to, TimeSpan.FromMilliseconds(milliseconds))
        {
            EasingFunction = new CubicEase { EasingMode = easing },
            FillBehavior = FillBehavior.Stop
        };

        animation.Freeze();
        return animation;
    }

    public static void FadeAndSlide(FrameworkElement element, double fromY = 12, double milliseconds = 260)
    {
        element.Opacity = 1;

        var translate = element.RenderTransform as TranslateTransform;
        if (translate is null || translate.IsFrozen)
        {
            translate = new TranslateTransform();
            element.RenderTransform = translate;
        }

        element.RenderTransformOrigin = new Point(0.5, 0.35);
        translate.Y = 0;

        if (!Enabled) return;

        element.BeginAnimation(UIElement.OpacityProperty, Tween(0, 1, milliseconds * 0.82));
        translate.BeginAnimation(TranslateTransform.YProperty, Tween(fromY, 0, milliseconds));
    }

    public static void ScaleFade(FrameworkElement element, double fromScale = 0.985, double milliseconds = 260)
    {
        element.Opacity = 1;

        var scale = new ScaleTransform(1, 1);
        element.RenderTransform = scale;
        element.RenderTransformOrigin = new Point(0.5, 0.5);

        if (!Enabled) return;

        element.BeginAnimation(UIElement.OpacityProperty, Tween(0, 1, milliseconds * 0.8));
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, Tween(fromScale, 1, milliseconds));
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, Tween(fromScale, 1, milliseconds));
    }
}
