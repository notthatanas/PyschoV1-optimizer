using System.Text.Json;
using System.Text.Json.Serialization;

namespace PyschoV1.Core.Safety;

/// <summary>
/// One reversible before-state. Deliberately a flat serialisable record instead of a polymorphic type
/// so old journals keep loading after the catalog changes.
/// </summary>
public sealed class PatchRecord
{
    /// <summary>registry | service | powerplan</summary>
    public string Kind { get; set; } = "registry";
    public string? Hive { get; set; }
    public string? Path { get; set; }
    public string? Name { get; set; }
    public bool Existed { get; set; }
    public string? Value { get; set; }
    public string? ValueKind { get; set; }
    public string? Service { get; set; }
    public string? PreviousStart { get; set; }
    public string? PreviousPlan { get; set; }

    public string Describe() => Kind switch
    {
        "service" => $"service {Service}: start {PreviousStart ?? "unchanged"}",
        "powerplan" => $"power plan: {PreviousPlan ?? "unchanged"}",
        _ => $"{Hive}.{Path}\\{Name}: {(Existed ? Value : "<absent>")}"
    };
}

public sealed class JournalEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("n");
    public string TweakId { get; set; } = "";
    public string Title { get; set; } = "";
    public string Module { get; set; } = "";
    public DateTimeOffset AppliedAt { get; set; } = DateTimeOffset.Now;
    public string Origin { get; set; } = "manual";
    public List<string> Plan { get; set; } = new();
    public List<PatchRecord> Patches { get; set; } = new();
    public bool Reverted { get; set; }
    public DateTimeOffset? RevertedAt { get; set; }
}

/// <summary>
/// Append-only, crash-safe change log. One file per applied tweak, so a half-written journal can
/// never corrupt the history and a revert is just re-reading the newest entries.
/// </summary>
public sealed class TweakJournal
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    private readonly object _gate = new();

    public string Directory { get; }

    public TweakJournal(string? directory = null)
    {
        Directory = directory ?? ResolveWritableDirectory();
        try { System.IO.Directory.CreateDirectory(Directory); } catch { /* read-only media */ }
    }

    /// <summary>
    /// Prefers ProgramData so every account sees one history, but falls back to the current user's
    /// AppData when the app is running unelevated and ProgramData is not writable.
    /// </summary>
    private static string ResolveWritableDirectory()
    {
        var candidates = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "PyschoV1", "journal"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PyschoV1", "journal")
        };

        foreach (var candidate in candidates)
        {
            try
            {
                System.IO.Directory.CreateDirectory(candidate);
                var probe = Path.Combine(candidate, ".write-test");
                File.WriteAllText(probe, "ok");
                File.Delete(probe);
                return candidate;
            }
            catch
            {
                // Try the next location.
            }
        }

        return candidates[^1];
    }

    /// <summary>Writes one entry. False means the undo record is not on disk.</summary>
    public bool TryAppend(JournalEntry entry)
    {
        entry.Id = string.IsNullOrWhiteSpace(entry.Id) ? Guid.NewGuid().ToString("n") : entry.Id;
        var file = PathFor(entry);
        lock (_gate)
        {
            try
            {
                File.WriteAllText(file, JsonSerializer.Serialize(entry, JsonOptions));
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    /// <summary>Compatibility helper. Engines should use <see cref="TryAppend"/> so they can roll back.</summary>
    public JournalEntry Append(JournalEntry entry)
    {
        TryAppend(entry);
        return entry;
    }

    public void Save(JournalEntry entry)
    {
        lock (_gate)
        {
            try { File.WriteAllText(PathFor(entry), JsonSerializer.Serialize(entry, JsonOptions)); }
            catch { }
        }
    }

    public IReadOnlyList<JournalEntry> ReadAll()
    {
        var list = new List<JournalEntry>();
        lock (_gate)
        {
            if (!System.IO.Directory.Exists(Directory)) return list;

            foreach (var file in System.IO.Directory.EnumerateFiles(Directory, "*.json"))
            {
                try
                {
                    var entry = JsonSerializer.Deserialize<JournalEntry>(File.ReadAllText(file), JsonOptions);
                    if (entry is not null) list.Add(entry);
                }
                catch
                {
                    // Skip unreadable entries rather than failing the whole history.
                }
            }
        }

        return list.OrderByDescending(e => e.AppliedAt).ToList();
    }

    private string PathFor(JournalEntry entry) =>
        Path.Combine(Directory, $"{entry.AppliedAt:yyyyMMdd-HHmmss}-{entry.Id}.json");
}
