using PyschoV1.Core.Tweaks;

namespace PyschoV1.Core.Catalog;

public sealed class Preset
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Summary { get; init; }
    public required IReadOnlyList<string> TweakIds { get; init; }
    public string Accent { get; init; } = "#7C5CFF";
}

/// <summary>Single source of truth for what the app can do. Order here is the order shown in the UI.</summary>
public static class TweakCatalog
{
    private static readonly Lazy<IReadOnlyList<Tweak>> LazyTweaks = new(() =>
        PerformanceTweaks.All().Concat(PrivacyTweaks.All()).ToList());

    public static IReadOnlyList<Tweak> All => LazyTweaks.Value;

    public static IReadOnlyList<Tweak> ForModule(TweakModule module) =>
        All.Where(t => t.Module == module).ToList();

    public static Tweak? Find(string id) => All.FirstOrDefault(t => t.Id == id);

    public static IReadOnlyList<Preset> Presets { get; } = new[]
    {
        new Preset
        {
            Id = "balanced",
            Name = "Balanced",
            Summary = "Everyday responsiveness without touching services or hardware settings.",
            Accent = "#4CC38A",
            TweakIds = new[]
            {
                "perf.gamemode", "perf.gamedvr", "perf.bgapps", "perf.startupdelay", "perf.menudelay",
                "perf.mousehover", "perf.registrybackup"
            }
        },
        new Preset
        {
            Id = "competitive",
            Name = "Competitive",
            Summary = "Lowest latency: full clocks, foreground priority, no compositor effects.",
            Accent = "#7C5CFF",
            TweakIds = new[]
            {
                "perf.power.high", "perf.gamemode", "perf.gamedvr", "perf.priority", "perf.mmcss",
                "perf.netthrottle", "perf.visualfx", "perf.transparency", "perf.bgapps",
                "perf.startupdelay", "perf.menudelay", "perf.mouseaccel", "perf.edgebackground"
            }
        },
        new Preset
        {
            Id = "privacy",
            Name = "Maximum privacy",
            Summary = "Every telemetry, assistant and suggestion path closed.",
            Accent = "#E0B341",
            TweakIds = new[]
            {
                "priv.telemetry.policy", "priv.diagtrack", "priv.dmwappush", "priv.adid",
                "priv.tailored", "priv.cortana", "priv.bingsearch", "priv.copilot", "priv.recall",
                "priv.feedback", "priv.wer", "priv.location", "priv.activity",
                "priv.consumer", "priv.suggestions", "priv.edge", "priv.office",
                "priv.inking", "priv.speech", "priv.apptracking", "priv.autoplay",
                "priv.remotehelp", "priv.sync", "priv.searchhighlights", "priv.spotlight",
                "priv.remoteregistry", "priv.quickaccess", "priv.smb1"
            }
        },
        new Preset
        {
            Id = "quiet",
            Name = "Quiet machine",
            Summary = "Fewer background services and no Windows telemetry upload.",
            Accent = "#4C9BC3",
            TweakIds = new[]
            {
                "perf.sysmain", "perf.wsearch", "perf.deliveryopt", "perf.edgebackground",
                "perf.mediasharing", "perf.xboxnet",
                "priv.diagtrack", "priv.wer", "priv.activity", "priv.searchhighlights",
                "priv.spotlight"
            }
        }
    };

    public static Preset? FindPreset(string id) => Presets.FirstOrDefault(p => p.Id == id);
}
