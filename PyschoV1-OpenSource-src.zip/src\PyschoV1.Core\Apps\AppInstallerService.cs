using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.Win32;

namespace PyschoV1.Core.Apps;

/// <summary>An app found in the Windows uninstall registry.</summary>
public sealed record InstalledApp(string Name, string Version, string? LaunchPath);

public enum InstallMethod
{
    /// <summary>Installed silently through winget.</summary>
    Winget,
    /// <summary>Installer downloaded to the Downloads\PyschoV1 folder and started.</summary>
    Downloaded,
    /// <summary>No silent path was possible; the official page was opened in the browser.</summary>
    PageOpened
}

public sealed record InstallOutcome(bool Success, InstallMethod Method, string Message);

/// <summary>
/// Installs common applications through winget when it exists, falling back to downloading the
/// publisher's own installer, and finally to opening the official page. Nothing is ever bundled,
/// mirrored or repackaged: every byte comes from the publisher or the Microsoft package source.
/// </summary>
public sealed class AppInstallerService
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(15) };

    private static readonly string[] UninstallRoots =
    {
        @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    };

    private readonly object _wingetGate = new();
    private bool? _wingetAvailable;

    static AppInstallerService()
    {
        // Some CDNs refuse an empty user agent; identify the app honestly.
        Http.DefaultRequestHeaders.UserAgent.ParseAdd("PyschoV1/1.0");
    }

    public static string DownloadDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "PyschoV1");

    /// <summary>Cached probe: does the winget executable exist and start on this machine?</summary>
    public async Task<bool> CheckWingetAsync()
    {
        lock (_wingetGate)
        {
            if (_wingetAvailable is { } cached) return cached;
        }

        var found = await Task.Run(() =>
        {
            try
            {
                using var p = Process.Start(new ProcessStartInfo
                {
                    FileName = "winget",
                    Arguments = "--version",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                });
                if (p is null) return false;
                p.StandardOutput.ReadToEnd();
                p.StandardError.ReadToEnd();
                return p.WaitForExit(6000) && p.ExitCode == 0;
            }
            catch
            {
                // winget is optional: App Installer can be missing on a stripped-down image.
                return false;
            }
        }).ConfigureAwait(false);

        lock (_wingetGate)
        {
            _wingetAvailable = found;
        }
        return found;
    }

    /// <summary>
    /// Reads the per-machine and per-user uninstall keys. Returns every entry that has a display
    /// name; system components without one are skipped.
    /// </summary>
    public IReadOnlyList<InstalledApp> ScanInstalled()
    {
        var found = new List<InstalledApp>(96);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var root in UninstallRoots)
            Collect(Registry.LocalMachine, root, found, seen);
        Collect(Registry.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Uninstall", found, seen);

        return found;
    }

    private static void Collect(RegistryKey hive, string path, List<InstalledApp> into, HashSet<string> seen)
    {
        try
        {
            using var key = hive.OpenSubKey(path);
            if (key is null) return;

            foreach (var subName in key.GetSubKeyNames())
            {
                try
                {
                    using var sub = key.OpenSubKey(subName);
                    if (sub is null) continue;

                    var name = sub.GetValue("DisplayName") as string;
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    var systemComponent = sub.GetValue("SystemComponent");
                    if (systemComponent is int flag && flag == 1) continue;
                    if (!seen.Add(name.Trim())) continue;

                    var version = (sub.GetValue("DisplayVersion") as string)?.Trim() ?? "";
                    var icon = sub.GetValue("DisplayIcon") as string;
                    var location = sub.GetValue("InstallLocation") as string;
                    into.Add(new InstalledApp(name.Trim(), version, ResolveLaunchPath(icon, location)));
                }
                catch
                {
                    // One locked or malformed entry must not hide the rest of the inventory.
                }
            }
        }
        catch
        {
            // Access to an uninstall hive can be denied; treat it as empty.
        }
    }

    /// <summary>Best-effort main executable from a DisplayIcon/InstallLocation pair.</summary>
    private static string? ResolveLaunchPath(string? icon, string? location)
    {
        string? candidate = null;
        var raw = icon?.Trim();
        if (!string.IsNullOrEmpty(raw))
        {
            if (raw.StartsWith('"'))
            {
                var end = raw.IndexOf('"', 1);
                if (end > 1) candidate = raw[1..end];
            }
            else
            {
                // Unquoted values may carry a ",0" icon index after the path.
                var comma = raw.LastIndexOf(',');
                candidate = comma >= 0 && int.TryParse(raw[(comma + 1)..].Trim(), out _)
                    ? raw[..comma]
                    : raw;
            }
        }

        if (candidate is not null)
        {
            candidate = candidate.Trim().Trim('"');
            if (File.Exists(candidate)) return candidate;

            var file = Path.GetFileName(candidate);
            if (!string.IsNullOrEmpty(file) && !string.IsNullOrWhiteSpace(location))
            {
                var joined = Path.Combine(location.Trim(), file);
                if (File.Exists(joined)) return joined;
            }
        }

        if (!string.IsNullOrWhiteSpace(location))
        {
            var trimmed = location.Trim().Trim('"');
            if (File.Exists(trimmed)) return trimmed;
        }

        return null;
    }

    /// <summary>
    /// Installed-name match with word boundaries, so "Git" matches "Git" and "Git 2.45" but never
    /// "GitHub Desktop".
    /// </summary>
    public static InstalledApp? FindInstalled(AppEntry entry, IReadOnlyList<InstalledApp> installed)
    {
        InstalledApp? prefixHit = null;
        foreach (var app in installed)
        {
            foreach (var hint in entry.InstalledNameHints)
            {
                var name = app.Name.Trim();
                var h = hint.Trim();
                if (h.Length == 0) continue;

                if (name.Equals(h, StringComparison.OrdinalIgnoreCase))
                    return app; // exact beats everything
                if (name.StartsWith(h + " ", StringComparison.OrdinalIgnoreCase) ||
                    name.StartsWith(h + " (", StringComparison.OrdinalIgnoreCase) ||
                    name.EndsWith(" " + h, StringComparison.OrdinalIgnoreCase) ||
                    name.Contains(" " + h + " ", StringComparison.OrdinalIgnoreCase))
                {
                    prefixHit ??= app;
                }
            }
        }
        return prefixHit;
    }

    /// <summary>
    /// Installs one catalog entry. Progress values below zero mean "indeterminate".
    /// Cancellation kills the winget process or stops the download mid-stream.
    /// </summary>
    public async Task<InstallOutcome> InstallAsync(
        AppEntry entry,
        IProgress<double>? progress,
        IProgress<string>? status,
        CancellationToken cancellationToken)
    {
        string? wingetError = null;
        string? downloadError = null;

        // 1. winget: latest verified package, silent, no download kept on disk by us.
        if (entry.WingetId is not null && await CheckWingetAsync())
        {
            status?.Report($"Installing {entry.Name} through winget…");
            var (exit, tail) = await RunWingetAsync(entry.WingetId, progress, status, cancellationToken);
            if (exit == 0)
                return new InstallOutcome(true, InstallMethod.Winget, $"{entry.Name} installed through winget.");

            if (cancellationToken.IsCancellationRequested)
                return new InstallOutcome(false, InstallMethod.Winget, "Install cancelled.");

            wingetError = string.IsNullOrWhiteSpace(tail) ? $"winget exited with code {exit}." : tail;
        }

        // 2. The publisher's own installer, downloaded into Downloads\PyschoV1.
        if (entry.DirectUrl is not null)
        {
            try
            {
                status?.Report($"Downloading the {entry.Name} installer…");
                var file = await DownloadAsync(entry, progress, status, cancellationToken);
                Process.Start(new ProcessStartInfo
                {
                    FileName = file,
                    WorkingDirectory = Path.GetDirectoryName(file) ?? DownloadDirectory,
                    UseShellExecute = true
                });
                return new InstallOutcome(true, InstallMethod.Downloaded,
                    $"Installer downloaded to {file} and started.");
            }
            catch (OperationCanceledException)
            {
                return new InstallOutcome(false, InstallMethod.Downloaded, "Download cancelled.");
            }
            catch (Exception ex)
            {
                downloadError = ex.Message;
            }
        }

        // 3. Nothing silent worked (or nothing silent exists): the official page opens.
        OpenUrl(entry.Homepage);

        var silentTried = entry.WingetId is not null || entry.DirectUrl is not null;
        if (!silentTried)
        {
            return new InstallOutcome(true, InstallMethod.PageOpened,
                "No silent installer is published for this app, so the official download page was opened.");
        }

        var reasons = new List<string>();
        if (wingetError is not null) reasons.Add("winget: " + wingetError);
        if (downloadError is not null) reasons.Add("download: " + downloadError);
        if (reasons.Count == 0) reasons.Add("no silent installer path was available.");

        return new InstallOutcome(false, InstallMethod.PageOpened,
            "Silent install did not complete — " + string.Join(" ", reasons) +
            " The official page was opened instead.");
    }

    private async Task<(int Exit, string Tail)> RunWingetAsync(
        string wingetId, IProgress<double>? progress, IProgress<string>? status, CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromMinutes(12));

        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "winget",
                Arguments =
                    $"install --id {wingetId} --exact --source winget --silent " +
                    "--accept-package-agreements --accept-source-agreements --disable-interactivity",
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            }
        };

        if (!process.Start())
            return (-1, "winget could not be started.");

        progress?.Report(-1);
        var lastLine = "";

        var pump = Task.Run(async () =>
        {
            string? line;
            while ((line = await process.StandardOutput.ReadLineAsync(timeout.Token)) is not null)
            {
                var trimmed = line.Trim();
                if (trimmed.Length == 0) continue;
                lastLine = trimmed;
                status?.Report(trimmed);
            }
        }, CancellationToken.None);

        try
        {
            await process.WaitForExitAsync(timeout.Token);
            await pump;
        }
        catch (OperationCanceledException)
        {
            try
            {
                process.Kill(entireProcessTree: true);
            }
            catch
            {
                // Already gone, or a race with exit — either way the cancel is honoured.
            }
            try { await pump; } catch { /* stdout died with the process */ }

            if (cancellationToken.IsCancellationRequested)
                throw new OperationCanceledException(cancellationToken);
            return (-1, "winget timed out after 12 minutes; trying the next method.");
        }

        var stderr = await process.StandardError.ReadToEndAsync(CancellationToken.None);
        var tail = string.IsNullOrWhiteSpace(stderr) ? lastLine : stderr.Trim();
        return (process.ExitCode, tail.Length > 240 ? tail[..240] : tail);
    }

    private async Task<string> DownloadAsync(
        AppEntry entry, IProgress<double>? progress, IProgress<string>? status, CancellationToken cancellationToken)
    {
        if (!entry.DirectUrl!.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Only https download links are allowed.");

        using var response = await Http.GetAsync(entry.DirectUrl,
            HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        response.EnsureSuccessStatusCode();

        var total = response.Content.Headers.ContentLength;
        var fileName = ResolveFileName(response, entry);

        Directory.CreateDirectory(DownloadDirectory);
        var target = UniquePath(Path.Combine(DownloadDirectory, fileName));

        var buffer = new byte[81920];
        long received = 0;
        var lastPercent = -1;

        await using (var source = await response.Content.ReadAsStreamAsync(cancellationToken))
        await using (var destination = File.Create(target))
        {
            while (true)
            {
                var read = await source.ReadAsync(buffer.AsMemory(0, buffer.Length), cancellationToken);
                if (read == 0) break;

                await destination.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
                received += read;

                if (total is > 0)
                {
                    var percent = (int)(received * 100.0 / total.Value);
                    if (percent != lastPercent)
                    {
                        lastPercent = percent;
                        progress?.Report(percent);
                        status?.Report($"{entry.Name}: {percent}% of {total.Value / 1024 / 1024:0} MB");
                    }
                }
            }
        }

        // The delete must happen after both streams are disposed or Windows refuses it.
        if (received == 0)
        {
            File.Delete(target);
            throw new InvalidOperationException("The download finished with zero bytes.");
        }

        progress?.Report(100);
        return target;
    }

    private static string ResolveFileName(HttpResponseMessage response, AppEntry entry)
    {
        var disposition = response.Content.Headers.ContentDisposition;
        var fromHeader = disposition?.FileNameStar ?? disposition?.FileName;
        var name = fromHeader?.Trim('"');

        if (string.IsNullOrWhiteSpace(name))
        {
            var local = new Uri(entry.DirectUrl!).LocalPath;
            name = Path.GetFileName(local);
            name = Uri.UnescapeDataString(name);
        }

        if (string.IsNullOrWhiteSpace(name) || name.Contains('?') || name.Contains('='))
            name = entry.Name;

        foreach (var c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');

        name = name.Trim();
        var hasExtension = Path.HasExtension(name);
        if (!hasExtension) name += ".exe";
        return name;
    }

    private static string UniquePath(string path)
    {
        if (!File.Exists(path)) return path;
        var dir = Path.GetDirectoryName(path)!;
        var stem = Path.GetFileNameWithoutExtension(path);
        var ext = Path.GetExtension(path);
        for (var i = 2; i < 100; i++)
        {
            var candidate = Path.Combine(dir, $"{stem} ({i}){ext}");
            if (!File.Exists(candidate)) return candidate;
        }
        return Path.Combine(dir, $"{stem}-{Guid.NewGuid():N}{Path.GetExtension(path)}");
    }

    public static void OpenUrl(string url)
    {
        Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
    }

    public static void LaunchInstalled(InstalledApp app)
    {
        if (string.IsNullOrWhiteSpace(app.LaunchPath)) return;
        Process.Start(new ProcessStartInfo
        {
            FileName = app.LaunchPath,
            UseShellExecute = true
        });
    }

    public static void OpenDownloadFolder()
    {
        Directory.CreateDirectory(DownloadDirectory);
        Process.Start(new ProcessStartInfo { FileName = DownloadDirectory, UseShellExecute = true });
    }
}
