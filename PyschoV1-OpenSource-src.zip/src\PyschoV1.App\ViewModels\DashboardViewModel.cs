using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using PyschoV1.App.Mvvm;
using PyschoV1.App.Runtime;
using PyschoV1.Core.Catalog;
using PyschoV1.Core.SysInfo;
using PyschoV1.Core.Tweaks;

namespace PyschoV1.App.ViewModels;

public sealed record SpecRow(string Label, string Value);
public sealed record SuggestionRow(string Title, string Summary, string ModuleKey);

public sealed class DashboardViewModel : ObservableObject, IDisposable
{
    private const int SeriesLength = 56;

    private double _cpu;
    private double _mem;
    private double _disk;
    private double _net;
    private string _cpuText = "—";
    private string _memText = "—";
    private string _memDetail = "";
    private string _diskText = "—";
    private string _netText = "—";
    private string _uptime = "—";
    private string _hardeningText = "";
    private double _hardeningPercent;
    private int _tick;
    private IReadOnlyList<double> _cpuSeries = Array.Empty<double>();
    private IReadOnlyList<double> _netSeries = Array.Empty<double>();

    private readonly List<double> _cpuHistory = new();
    private readonly List<double> _netHistory = new();

    public DashboardViewModel()
    {
        // The visible cards are filled by RefreshAll after the first frame, so machine inventory
        // never delays the window appearing.
        SpecRows = new ObservableCollection<SpecRow>();

        // Drive enumeration is local and cheap; doing it here avoids a one-frame "no drives"
        // message. The slower registry inventory is still deferred with the rest of RefreshAll.
        Drives = new ObservableCollection<DriveSample>(HardwareMonitor.ReadDrives());
        Presets = new ObservableCollection<Preset>(TweakCatalog.Presets);

        ApplyPresetCommand = new RelayCommand<Preset>(preset => _ = ApplyPresetAsync(preset));
        RefreshCommand = new RelayCommand(RefreshAll);
        OpenSuggestionCommand = new RelayCommand<SuggestionRow>(row =>
        {
            if (row is not null) AppServices.Shell?.Navigate(row.ModuleKey);
        });

        AppServices.Monitor.Sampled += OnSampled;

        // Deferred so the window paints before any registry reads or sampling happen, but queued at
        // Background so the first values land immediately after that paint, not on a later idle pass.
        Application.Current?.Dispatcher.BeginInvoke(new Action(() =>
        {
            AppServices.Monitor.Start();
            RefreshAll();
        }), System.Windows.Threading.DispatcherPriority.Background);
    }

    public ObservableCollection<SpecRow> SpecRows { get; }
    public ObservableCollection<DriveSample> Drives { get; }
    public ObservableCollection<Preset> Presets { get; }
    public ObservableCollection<SuggestionRow> Suggestions { get; } = new();

    public ICommand ApplyPresetCommand { get; }
    public ICommand RefreshCommand { get; }
    public ICommand OpenSuggestionCommand { get; }

    public string CpuText { get => _cpuText; private set => Set(ref _cpuText, value); }
    public string MemText { get => _memText; private set => Set(ref _memText, value); }
    public string MemDetail { get => _memDetail; private set => Set(ref _memDetail, value); }
    public string DiskText { get => _diskText; private set => Set(ref _diskText, value); }
    public string NetText { get => _netText; private set => Set(ref _netText, value); }
    public string UptimeText { get => _uptime; private set => Set(ref _uptime, value); }
    public string HardeningText { get => _hardeningText; private set => Set(ref _hardeningText, value); }
    public double HardeningPercent { get => _hardeningPercent; private set => Set(ref _hardeningPercent, value); }

    public double CpuPercent { get => _cpu; private set => Set(ref _cpu, value); }
    public double MemPercent { get => _mem; private set => Set(ref _mem, value); }
    public double DiskPercent { get => _disk; private set => Set(ref _disk, value); }
    public double NetPercent => Math.Clamp(_net / 10.0 * 100, 0, 100);

    public IReadOnlyList<double> CpuSeries { get => _cpuSeries; private set => Set(ref _cpuSeries, value); }
    public IReadOnlyList<double> NetSeries { get => _netSeries; private set => Set(ref _netSeries, value); }

    public string ElevationNote => AppServices.IsElevated
        ? "Running as administrator"
        : "Standard user — some changes need elevation";

    public bool IsElevated => AppServices.IsElevated;

    private void OnSampled(object? sender, HardwareSample sample)
    {
        var app = Application.Current;
        if (app is null) return;
        app.Dispatcher.BeginInvoke(new Action(() => Apply(sample)));
    }

    private void Apply(HardwareSample sample)
    {
        CpuPercent = sample.CpuPercent;
        CpuText = $"{sample.CpuPercent:0}%";
        MemPercent = sample.RamPercent;
        MemText = $"{sample.RamPercent:0}%";
        MemDetail = $"{sample.RamUsedGb:0.#} of {sample.RamTotalGb:0.#} GB";
        DiskPercent = sample.DiskBusyPercent;
        DiskText = $"{sample.DiskBusyPercent:0}%";
        NetPercentRaise(sample.NetworkMbps);
        NetText = sample.NetworkMbps >= 1
            ? $"{sample.NetworkMbps:0.0} Mb/s"
            : $"{sample.NetworkMbps * 1000:0} Kb/s";
        UptimeText = sample.UptimeHours >= 24
            ? $"{sample.UptimeHours / 24:0.0} days"
            : $"{sample.UptimeHours:0.0} h";

        Push(_cpuHistory, sample.CpuPercent);
        Push(_netHistory, Math.Min(sample.NetworkMbps * 10, 100));
        CpuSeries = _cpuHistory.ToArray();
        NetSeries = _netHistory.ToArray();

        if (++_tick % 45 == 0) RefreshDrives();
    }

    private void NetPercentRaise(double value)
    {
        _net = value;
        Raise(nameof(NetPercent));
    }

    private static void Push(List<double> series, double value)
    {
        series.Add(double.IsFinite(value) ? value : 0);
        while (series.Count > SeriesLength) series.RemoveAt(0);
    }

    private void EnsureMachineInfo()
    {
        if (SpecRows.Count > 0) return;

        var specs = AppServices.Specs;
        SpecRows.Add(new SpecRow("Processor", specs.CpuName));
        SpecRows.Add(new SpecRow("Graphics", specs.GpuName));
        SpecRows.Add(new SpecRow("Memory", $"{specs.TotalRamGb:0.#} GB"));
        SpecRows.Add(new SpecRow("Operating system", specs.OsName));
        SpecRows.Add(new SpecRow("Build", specs.OsBuild));
        SpecRows.Add(new SpecRow("Machine", specs.MachineName));
    }

    private void RefreshDrives()
    {
        var fresh = HardwareMonitor.ReadDrives();
        if (fresh.Count == Drives.Count) return;
        Drives.Clear();
        foreach (var drive in fresh) Drives.Add(drive);
    }

    public void RefreshAll()
    {
        EnsureMachineInfo();
        RefreshDrives();

        var all = TweakCatalog.All.Where(t => Core.Engine.TweakEngine.SupportsPlatform(t, AppServices.WindowsBuild)).ToList();
        var on = all.Count(t => AppServices.Engine.GetState(t) == Core.Engine.TweakState.On);
        HardeningPercent = all.Count == 0 ? 0 : on * 100.0 / all.Count;
        HardeningText = $"{on} of {all.Count} on this PC";

        Suggestions.Clear();

        var candidates = new (string Id, string ModuleKey)[]
        {
            ("priv.telemetry.policy", "privacy"),
            ("priv.activity", "privacy"),
            ("priv.adid", "privacy"),
            ("perf.gamemode", "performance"),
            ("perf.bgapps", "performance"),
            ("priv.suggestions", "privacy")
        };

        foreach (var (id, module) in candidates)
        {
            var tweak = TweakCatalog.Find(id);
            if (tweak is null) continue;
            if (!Core.Engine.TweakEngine.SupportsPlatform(tweak, AppServices.WindowsBuild)) continue;
            if (AppServices.Engine.GetState(tweak) == Core.Engine.TweakState.On) continue;

            Suggestions.Add(new SuggestionRow(tweak.Title, tweak.Summary, module));
            if (Suggestions.Count == 3) break;
        }
    }

    private async Task ApplyPresetAsync(Preset? preset)
    {
        if (preset is null) return;
        var outcome = await PresetRunner.ApplyAsync(preset);
        AppServices.Shell?.ShowToast(outcome.Message, outcome.Success ? "success" : "error");
        RefreshAll();
    }

    public void Dispose()
    {
        AppServices.Monitor.Sampled -= OnSampled;
    }
}
