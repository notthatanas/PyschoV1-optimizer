using System.Windows.Controls;

namespace PyschoV1.App.Views;

public partial class StartupView : UserControl
{
    public StartupView() => InitializeComponent();
}
