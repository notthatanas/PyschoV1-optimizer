using System.Diagnostics;
using System.Text;

namespace PyschoV1.App.Runtime;

/// <summary>Collects WPF binding warnings so a render pass can prove the XAML paths are valid.</summary>
internal sealed class BindingErrorListener : TraceListener
{
    private readonly StringBuilder _buffer = new();

    public IReadOnlyList<string> Messages => _buffer
        .ToString()
        .Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries)
        .Select(line => line.Trim())
        .Where(line => line.Length > 0)
        .Distinct()
        .ToList();

    public override void Write(string? message) => _buffer.Append(message);

    public override void WriteLine(string? message)
    {
        _buffer.Append(message);
        _buffer.Append(Environment.NewLine);
    }

    public static BindingErrorListener Attach()
    {
        var listener = new BindingErrorListener();
        PresentationTraceSources.Refresh();
        PresentationTraceSources.DataBindingSource.Listeners.Add(listener);
        PresentationTraceSources.DataBindingSource.Switch.Level = SourceLevels.Warning;
        return listener;
    }
}
